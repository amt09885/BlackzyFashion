import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function NewsletterSection() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [subscribed, setSubscribed] = useState(false);
  const { toast } = useToast();

  const handleSubscribe = async (e) => {
    e.preventDefault();
    
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast({
        title: "Please enter a valid email",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      // Check if already subscribed
      const existing = await base44.entities.Subscriber.filter({ email: email.toLowerCase() });
      if (existing.length > 0) {
        toast({
          title: "Already subscribed!",
          description: "This email is already in our mailing list."
        });
        setLoading(false);
        return;
      }

      // Create subscriber
      await base44.entities.Subscriber.create({
        email: email.toLowerCase(),
        is_active: true,
        subscribed_date: new Date().toISOString()
      });

      setSubscribed(true);
      toast({
        title: "Successfully subscribed!",
        description: "Thank you for joining our family."
      });
      setEmail("");
    } catch (e) {
      toast({
        title: "Error subscribing",
        variant: "destructive"
      });
    }
    setLoading(false);
  };

  return (
    <div className="border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center max-w-xl mx-auto">
          <h3 className="font-display text-3xl mb-3">Join Our Family</h3>
          <p className="text-gray-400 mb-6 font-body text-sm">
            Subscribe for exclusive offers, new arrivals, and styling tips
          </p>
          {subscribed ? (
            <div className="flex items-center justify-center gap-2 text-[#d4a853]">
              <CheckCircle className="w-5 h-5" />
              <span className="font-body">Thank you for subscribing!</span>
            </div>
          ) : (
            <form onSubmit={handleSubscribe} className="flex gap-2">
              <input 
                type="email" 
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 bg-white/10 border border-white/20 px-4 py-3 text-sm focus:outline-none focus:border-[#d4a853] text-white"
              />
              <Button 
                type="submit"
                disabled={loading}
                className="bg-[#d4a853] hover:bg-[#c49743] text-black px-8 rounded-none"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Subscribe"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}