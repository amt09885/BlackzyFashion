import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import ProductCard from "../products/ProductCard";
import { Sparkles, TrendingUp, ShoppingCart } from "lucide-react";

export default function AIRecommendations({ 
  currentProduct = null, 
  location = "product_page",
  title = "You May Also Like"
}) {
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);

  const { data: strategies = [] } = useQuery({
    queryKey: ['recommendation-strategies', location],
    queryFn: () => base44.entities.RecommendationStrategy.filter({ 
      is_active: true,
      display_location: location 
    }),
    staleTime: 10 * 60 * 1000,
  });

  const { data: allProducts = [] } = useQuery({
    queryKey: ['all-products'],
    queryFn: () => base44.entities.Product.filter({ is_active: true }),
    staleTime: 5 * 60 * 1000,
  });

  useEffect(() => {
    if (allProducts.length > 0) {
      generateRecommendations();
    }
  }, [allProducts, currentProduct, strategies]);

  const getSessionId = () => localStorage.getItem('guest_session_id');

  const generateRecommendations = async () => {
    try {
      let isAuth = await base44.auth.isAuthenticated();
      let userEmail = null;
      let sessionId = getSessionId();

      if (isAuth) {
        const user = await base44.auth.me();
        userEmail = user.email;
      }

      // Get user's browsing history
      const viewsQuery = userEmail 
        ? { user_email: userEmail }
        : sessionId ? { session_id: sessionId } : null;
      
      const recentViews = viewsQuery 
        ? await base44.entities.ProductView.filter(viewsQuery, "-created_date", 20)
        : [];

      // Get cart items
      const cartQuery = userEmail 
        ? { user_email: userEmail }
        : sessionId ? { session_id: sessionId } : null;
      
      const cartItems = cartQuery
        ? await base44.entities.CartItem.filter(cartQuery)
        : [];

      // Get past orders
      const orders = userEmail
        ? await base44.entities.Order.filter({ customer_email: userEmail })
        : [];

      let scoredProducts = [];

      // Apply strategies
      strategies.forEach(strategy => {
        const strategyProducts = applyStrategy(
          strategy, 
          currentProduct, 
          allProducts, 
          recentViews, 
          cartItems, 
          orders
        );
        
        strategyProducts.forEach(product => {
          const existing = scoredProducts.find(p => p.id === product.id);
          if (existing) {
            existing.score += product.score * strategy.weight;
          } else {
            scoredProducts.push({
              ...product,
              score: product.score * strategy.weight
            });
          }
        });
      });

      // Exclude current product and already purchased
      scoredProducts = scoredProducts.filter(p => 
        p.id !== currentProduct?.id &&
        p.stock_quantity > 0
      );

      // Sort by score and take top items
      scoredProducts.sort((a, b) => b.score - a.score);
      const maxItems = strategies[0]?.max_items || 4;
      setRecommendations(scoredProducts.slice(0, maxItems));
    } catch (e) {
      console.error("Error generating recommendations:", e);
    }
    setLoading(false);
  };

  const applyStrategy = (strategy, currentProduct, allProducts, views, cart, orders) => {
    let products = [...allProducts];
    
    switch (strategy.type) {
      case "similar_products":
        // Same category or fabric type
        if (currentProduct) {
          products = products.filter(p => 
            p.category_id === currentProduct.category_id ||
            p.fabric_type === currentProduct.fabric_type
          );
        }
        return products.map(p => ({ ...p, score: 5 }));

      case "trending":
        // Products with high views and sales
        products.sort((a, b) => 
          ((b.sold_count || 0) + (b.views || 0)) - 
          ((a.sold_count || 0) + (a.views || 0))
        );
        return products.slice(0, 10).map(p => ({ ...p, score: 4 }));

      case "frequently_bought_together":
        // Products in same orders
        const purchasedProductIds = orders
          .flatMap(o => o.items?.map(i => i.product_id) || []);
        
        products = products.filter(p => 
          purchasedProductIds.includes(p.id)
        );
        return products.map(p => ({ ...p, score: 6 }));

      case "category_based":
        // Based on viewed categories
        const viewedCategories = [...new Set(views.map(v => v.category_id))];
        products = products.filter(p => viewedCategories.includes(p.category_id));
        return products.map(p => ({ ...p, score: 3 }));

      case "price_range":
        // Similar price range
        if (currentProduct) {
          const priceRange = currentProduct.price * 0.3;
          products = products.filter(p => 
            Math.abs(p.price - currentProduct.price) <= priceRange
          );
        }
        return products.map(p => ({ ...p, score: 2 }));

      default:
        return products.map(p => ({ ...p, score: 1 }));
    }
  };

  const trackClick = async (productId) => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      const user = isAuth ? await base44.auth.me() : null;
      
      await base44.entities.RecommendationClick.create({
        user_email: user?.email || null,
        session_id: getSessionId(),
        recommended_product_id: productId,
        source_product_id: currentProduct?.id || null,
        strategy_type: strategies[0]?.type || "mixed",
        location: location
      });
    } catch (e) {
      console.error("Error tracking click:", e);
    }
  };

  if (loading || recommendations.length === 0) return null;

  return (
    <section className="py-12 bg-[#fafafa]">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center gap-3 mb-8">
          <Sparkles className="w-6 h-6 text-[#d4a853]" />
          <h2 className="font-display text-3xl">{title}</h2>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {recommendations.map(product => (
            <div key={product.id} onClick={() => trackClick(product.id)}>
              <ProductCard product={product} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}