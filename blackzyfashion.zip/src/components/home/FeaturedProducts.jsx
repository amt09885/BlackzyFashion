import React, { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";
import { base44 } from "@/api/base44Client";
import ProductCard from "../products/ProductCard";
import { Button } from "@/components/ui/button";
import { ArrowRight, Loader2 } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";

export default React.memo(function FeaturedProducts() {
  const [activeTab, setActiveTab] = useState("new");

  const { data: allProducts = [], isLoading: loading } = useQuery({
    queryKey: ['all-products'],
    queryFn: () => base44.entities.Product.filter({ is_active: true }),
    staleTime: 10 * 60 * 1000,
    cacheTime: 30 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const products = allProducts.slice(0, 10);

  return (
    <section className="py-20 px-4 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center mb-12">
          <div>
            <span className="text-[#d4a853] text-sm tracking-[0.3em] uppercase font-body">
              Our Products
            </span>
            <h2 className="font-display text-4xl md:text-5xl mt-3 text-[#0a0a0a]">
              Featured Collection
            </h2>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-6 md:mt-0">
            <TabsList className="bg-gray-100 rounded-none p-1">
              <TabsTrigger value="new" className="rounded-none data-[state=active]:bg-[#0a0a0a] data-[state=active]:text-white px-6">
                New Arrivals
              </TabsTrigger>
              <TabsTrigger value="bestseller" className="rounded-none data-[state=active]:bg-[#0a0a0a] data-[state=active]:text-white px-6">
                Bestsellers
              </TabsTrigger>
              <TabsTrigger value="featured" className="rounded-none data-[state=active]:bg-[#0a0a0a] data-[state=active]:text-white px-6">
                Featured
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-96">
            <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
          </div>
        ) : products.length > 0 ? (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
            <div className="text-center mt-12">
              <Link to={createPageUrl("Shop")}>
                <Button 
                  variant="outline" 
                  size="lg"
                  className="border-[#0a0a0a] text-[#0a0a0a] hover:bg-[#0a0a0a] hover:text-white rounded-none px-10"
                >
                  View All Products
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          </>
        ) : (
          <div className="text-center py-20 bg-gray-50">
            <p className="text-gray-500 font-body">No products available yet. Check back soon!</p>
          </div>
        )}
      </div>
    </section>
  );
});