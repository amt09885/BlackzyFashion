import React, { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Facebook, ChevronLeft, ChevronRight } from "lucide-react";

export default React.memo(function InstagramFeed() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [itemsPerView, setItemsPerView] = useState(6);

  const { data: siteSettings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const settings = await base44.entities.SiteSettings.filter({ key: "main" });
      return settings[0] || null;
    },
    staleTime: 24 * 60 * 60 * 1000,
    cacheTime: 7 * 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['instagram-posts'],
    queryFn: () => base44.entities.InstagramPost.filter({ is_active: true }, "sort_order"),
    staleTime: 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
  });

  const s = siteSettings || {};

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 480) setItemsPerView(2);
      else if (window.innerWidth < 640) setItemsPerView(3);
      else if (window.innerWidth < 768) setItemsPerView(4);
      else if (window.innerWidth < 1024) setItemsPerView(5);
      else setItemsPerView(6);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const maxIndex = Math.max(0, posts.length - itemsPerView);

  const nextSlide = useCallback(() => {
    setCurrentIndex(prev => (prev >= maxIndex ? 0 : prev + 1));
  }, [maxIndex]);

  const prevSlide = () => {
    setCurrentIndex(prev => (prev <= 0 ? maxIndex : prev - 1));
  };

  // Auto-slide
  useEffect(() => {
    if (posts.length <= itemsPerView) return;
    const interval = setInterval(nextSlide, 2500);
    return () => clearInterval(interval);
  }, [nextSlide, posts.length, itemsPerView]);

  if (posts.length === 0) return null;

  return (
    <section className="py-16 sm:py-20">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-8 sm:mb-12">
          <Facebook className="w-8 h-8 sm:w-10 sm:h-10 mx-auto mb-3 sm:mb-4 text-[#d4a853]" />
          <h2 className="font-display text-2xl sm:text-3xl mb-2">
            {s.instagram_handle || "@blackzyfashion"}
          </h2>
          <p className="text-gray-500 font-body text-sm sm:text-base">
            {s.instagram_tagline || "Join 20K+ followers for daily fashion inspiration"}
          </p>
        </div>

        <div className="relative">
          {/* Navigation Buttons */}
          {posts.length > itemsPerView && (
            <>
              <button
                onClick={prevSlide}
                className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-2 sm:-translate-x-4 z-10 w-8 h-8 sm:w-10 sm:h-10 bg-white shadow-lg flex items-center justify-center hover:bg-[#0a0a0a] hover:text-white transition-colors"
              >
                <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
              <button
                onClick={nextSlide}
                className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-2 sm:translate-x-4 z-10 w-8 h-8 sm:w-10 sm:h-10 bg-white shadow-lg flex items-center justify-center hover:bg-[#0a0a0a] hover:text-white transition-colors"
              >
                <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
            </>
          )}

          {/* Carousel Container */}
          <div className="overflow-hidden mx-2 sm:mx-6">
            <div 
              className="flex transition-transform duration-500 ease-out"
              style={{ transform: `translateX(-${currentIndex * (100 / itemsPerView)}%)` }}
            >
              {posts.map((post) => (
                <div 
                  key={post.id}
                  className="flex-shrink-0 px-1"
                  style={{ width: `${100 / itemsPerView}%` }}
                >
                  <a
                    href={post.link_url || s.facebook_url || "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block aspect-square overflow-hidden group"
                  >
                    <img
                      src={post.image_url}
                      alt="Facebook"
                      loading="lazy"
                      decoding="async"
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* Dots Indicator */}
          {posts.length > itemsPerView && (
            <div className="flex justify-center gap-1.5 mt-4 sm:mt-6">
              {Array.from({ length: maxIndex + 1 }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentIndex(i)}
                  className={`w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full transition-all ${
                    i === currentIndex ? "bg-[#d4a853] w-4 sm:w-6" : "bg-gray-300"
                  }`}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
});