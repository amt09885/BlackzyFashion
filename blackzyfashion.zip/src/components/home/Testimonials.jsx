import React, { useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Star, Quote, ChevronLeft, ChevronRight } from "lucide-react";

export default React.memo(function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [perView, setPerView] = useState(3);

  const getItemsPerView = () => {
    if (typeof window === 'undefined') return 3;
    if (window.innerWidth < 640) return 1;
    if (window.innerWidth < 1024) return 2;
    return 3;
  };

  const { data: siteSettings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const settings = await base44.entities.SiteSettings.filter({ key: "main" });
      return settings[0] || null;
    },
    staleTime: 24 * 60 * 60 * 1000,
    cacheTime: 7 * 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
  });

  const { data: testimonials = [] } = useQuery({
    queryKey: ['testimonials'],
    queryFn: () => base44.entities.Testimonial.filter({ is_active: true }, "sort_order"),
    staleTime: 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
  });

  const s = siteSettings || {};

  React.useEffect(() => {
    const handleResize = () => {
      setPerView(getItemsPerView());
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Auto-slide every 4 seconds
  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex(prev => prev + 1);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Reset position when reaching end/start for seamless loop
  React.useEffect(() => {
    if (testimonials.length === 0) return;
    
    if (currentIndex >= testimonials.length * 2) {
      setTimeout(() => {
        setCurrentIndex(testimonials.length);
      }, 500);
    } else if (currentIndex <= 0) {
      setTimeout(() => {
        setCurrentIndex(testimonials.length);
      }, 500);
    }
  }, [currentIndex, testimonials.length]);

  if (testimonials.length === 0) return null;

  // Triple testimonials for seamless loop
  const loopedTestimonials = [...testimonials, ...testimonials, ...testimonials];

  const handlePrev = () => {
    setCurrentIndex(prev => prev - 1);
  };

  const handleNext = () => {
    setCurrentIndex(prev => prev + 1);
  };

  return (
    <section className="py-16 sm:py-20 bg-[#faf8f5] overflow-hidden">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-10 sm:mb-12">
          <span className="text-[#d4a853] text-xs sm:text-sm tracking-[0.3em] uppercase font-body">
            {s.testimonial_section_subtitle || "Customer Love"}
          </span>
          <h2 className="font-display text-3xl sm:text-4xl mt-3">
            {s.testimonial_section_title || "What Our Customers Say"}
          </h2>
          <p className="text-gray-500 font-body mt-2 text-sm sm:text-base">
            {s.testimonial_rating_text || "100% Rating • 1,020+ Reviews"}
          </p>
        </div>
      </div>

      {/* Carousel Container */}
      <div className="relative max-w-7xl mx-auto px-4">
        {/* Navigation Arrows - Always visible */}
        <button
          onClick={handlePrev}
          className="absolute -left-4 sm:-left-6 top-1/2 -translate-y-1/2 z-20 bg-white hover:bg-[#d4a853] text-[#0a0a0a] hover:text-white shadow-lg rounded-full w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center"
        >
          <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
        </button>

        <button
          onClick={handleNext}
          className="absolute -right-4 sm:-right-6 top-1/2 -translate-y-1/2 z-20 bg-white hover:bg-[#d4a853] text-[#0a0a0a] hover:text-white shadow-lg rounded-full w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center"
        >
          <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6" />
        </button>

        {/* Testimonials Slider */}
        <div className="overflow-hidden px-1">
          <div 
            className="flex duration-300 ease-out gap-3 sm:gap-4"
            style={{ 
              transform: `translateX(-${currentIndex * (100 / perView)}%)`,
            }}
          >
            {loopedTestimonials.map((testimonial, index) => (
            <div 
              key={`${testimonial.id}-${index}`} 
              className="flex-shrink-0 bg-white shadow-sm hover:shadow-md transition-shadow overflow-hidden rounded-lg"
              style={{ 
                width: `calc(${100 / perView}% - ${((perView - 1) * 12) / perView}px)`
              }}
            >
              {testimonial.screenshot ? (
                <img 
                  src={testimonial.screenshot} 
                  alt={`${testimonial.name}'s review`}
                  loading="lazy"
                  decoding="async"
                  className="w-full h-auto object-cover"
                />
              ) : (
                <div className="p-5 sm:p-6">
                  <Quote className="w-6 h-6 sm:w-8 sm:h-8 text-[#d4a853]/20 mb-3 sm:mb-4" />
                  <p className="text-gray-600 font-body text-xs sm:text-sm mb-4 sm:mb-6 line-clamp-4">
                    "{testimonial.comment}"
                  </p>
                  <div className="flex items-center gap-3">
                    <img 
                      src={testimonial.image || "https://via.placeholder.com/50"} 
                      alt={testimonial.name}
                      loading="lazy"
                      decoding="async"
                      className="w-10 h-10 sm:w-12 sm:h-12 rounded-full object-cover"
                    />
                    <div>
                      <p className="font-display text-xs sm:text-sm">{testimonial.name}</p>
                      <p className="text-gray-500 text-[10px] sm:text-xs font-body">{testimonial.location}</p>
                    </div>
                  </div>
                  <div className="flex mt-2 sm:mt-3">
                    {[...Array(testimonial.rating || 5)].map((_, i) => (
                      <Star key={i} className="w-3 h-3 sm:w-4 sm:h-4 fill-[#d4a853] text-[#d4a853]" />
                    ))}
                  </div>
                  {testimonial.product && (
                    <p className="text-[10px] sm:text-xs text-[#d4a853] mt-2">Purchased: {testimonial.product}</p>
                  )}
                </div>
              )}
            </div>
          ))}
          </div>
          </div>

          {/* Dot Indicators */}
          <div className="flex justify-center gap-2 mt-6">
          {testimonials.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(testimonials.length + index)}
            className={`w-2 h-2 rounded-full transition-all duration-300 ${
              Math.floor(currentIndex % testimonials.length) === index
                ? "bg-[#d4a853] w-6"
                : "bg-gray-300 hover:bg-gray-400"
            }`}
          />
          ))}
          </div>
          </div>
          </section>
          );
          });