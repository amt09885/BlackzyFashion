import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Truck, Shield, RotateCcw, Headphones } from "lucide-react";

const icons = [Truck, Shield, RotateCcw, Headphones];

export default React.memo(function Features() {


  const features = [
    { title: "Free Delivery", description: "On orders above ৳2000 across Bangladesh" },
    { title: "100% Authentic", description: "Guaranteed original fabrics and materials" },
    { title: "Easy Returns", description: "7-day hassle-free return policy" },
    { title: "24/7 Support", description: "WhatsApp & phone support available" },
  ];

  return (
    <section className="py-12 bg-white border-y border-gray-100">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = icons[index];
            return (
              <div key={index} className="text-center">
                <div className="w-14 h-14 bg-[#faf8f5] rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon className="w-6 h-6 text-[#d4a853]" />
                </div>
                <h3 className="font-display text-lg mb-1">{feature.title}</h3>
                <p className="text-gray-500 text-sm font-body">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
});