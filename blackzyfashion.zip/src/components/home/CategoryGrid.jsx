import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";
import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default React.memo(function CategoryGrid() {
  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: () => base44.entities.Category.filter({ is_active: true }),
    staleTime: 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
  });

  const itemsPerView = {
    mobile: 1,
    tablet: 2,
    desktop: 3,
    large: 4
  };

  const getItemsPerView = () => {
    if (typeof window === 'undefined') return itemsPerView.desktop;
    if (window.innerWidth < 640) return itemsPerView.mobile;
    if (window.innerWidth < 768) return itemsPerView.tablet;
    if (window.innerWidth < 1280) return itemsPerView.desktop;
    return itemsPerView.large;
  };

  const [currentIndex, setCurrentIndex] = useState(0);
  const [perView, setPerView] = useState(getItemsPerView());

  React.useEffect(() => {
    const handleResize = () => {
      setPerView(getItemsPerView());
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Auto-slide every 4 seconds
  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex(prev => prev + 1);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Reset position when reaching end/start for seamless loop
  React.useEffect(() => {
    if (categories.length === 0) return;
    
    if (currentIndex >= categories.length * 2) {
      setTimeout(() => {
        setCurrentIndex(categories.length);
      }, 500);
    } else if (currentIndex <= 0) {
      setTimeout(() => {
        setCurrentIndex(categories.length);
      }, 500);
    }
  }, [currentIndex, categories.length]);

  if (categories.length === 0) {
    return null;
  }

  // Create seamless loop by tripling the categories
  const loopedCategories = [...categories, ...categories, ...categories];
  const totalItems = loopedCategories.length;

  const handlePrev = () => {
    setCurrentIndex(prev => prev - 1);
  };

  const handleNext = () => {
    setCurrentIndex(prev => prev + 1);
  };

  const handleDotClick = (index) => {
    setCurrentIndex(Math.min(index, maxIndex));
  };

  const totalDots = Math.ceil(categories.length / perView);

  return (
    <section className="py-16 sm:py-20">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-10 sm:mb-14">
          <span className="text-[#d4a853] text-xs sm:text-sm tracking-[0.3em] uppercase font-body">
            Curated Collections
          </span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl mt-3 text-[#0a0a0a]">
            Shop by Category
          </h2>
        </div>

        {/* Carousel Container */}
        <div className="relative">
          {/* Navigation Arrows - Always visible */}
          <button
            onClick={handlePrev}
            className="absolute -left-4 sm:-left-6 top-1/2 -translate-y-1/2 z-20 bg-white hover:bg-[#d4a853] text-[#0a0a0a] hover:text-white shadow-lg rounded-full w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center"
          >
            <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>

          <button
            onClick={handleNext}
            className="absolute -right-4 sm:-right-6 top-1/2 -translate-y-1/2 z-20 bg-white hover:bg-[#d4a853] text-[#0a0a0a] hover:text-white shadow-lg rounded-full w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center"
          >
            <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>

          {/* Categories Slider */}
          <div className="overflow-hidden px-1">
            <div 
              className="flex duration-300 ease-out gap-3 sm:gap-4"
              style={{ 
                transform: `translateX(-${currentIndex * (100 / perView)}%)`,
              }}
            >
              {loopedCategories.map((category, index) => (
                <Link 
                  key={`${category.id}-${index}`}
                  to={createPageUrl("Shop") + `?category=${category.id}`}
                  className="group block relative flex-shrink-0 overflow-hidden rounded-lg"
                  style={{ 
                    width: `calc(${100 / perView}% - ${((perView - 1) * 12) / perView}px)`
                  }}
                >
                  <div className="relative w-full" style={{ paddingBottom: '125%' }}>
                    {/* Image */}
                    <img 
                      src={category.image_url || "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=800&auto=format"}
                      alt={category.name}
                      loading={index < 4 ? "eager" : "lazy"}
                      decoding="async"
                      width="400"
                      height="500"
                      fetchpriority={index < 2 ? "high" : "low"}
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                    
                    {/* Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    
                    {/* Content */}
                    <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6 text-white">
                      <h3 className="font-display text-xl sm:text-2xl mt-1 mb-1 sm:mb-2">
                        {category.name}
                      </h3>
                      {category.name_bn && (
                        <p className="text-xs sm:text-sm text-gray-300 font-body mb-2 sm:mb-4">
                          {category.name_bn}
                        </p>
                      )}
                      <div className="flex items-center gap-2 text-xs sm:text-sm font-body opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        <span>Explore</span>
                        <ArrowRight className="w-3 h-3 sm:w-4 sm:h-4" />
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Dots Navigation */}
          <div className="flex justify-center gap-2 mt-6">
            {Array.from({ length: totalDots }).map((_, index) => {
              const dotIndex = index * perView;
              const isActive = currentIndex >= dotIndex && currentIndex < dotIndex + perView;
              return (
                <button
                  key={index}
                  onClick={() => handleDotClick(dotIndex)}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    isActive 
                      ? 'w-8 bg-[#d4a853]' 
                      : 'w-2 bg-gray-300 hover:bg-gray-400'
                  }`}
                  aria-label={`Go to slide ${index + 1}`}
                />
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
});