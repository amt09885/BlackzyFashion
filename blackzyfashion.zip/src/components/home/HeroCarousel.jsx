import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Loader2, Clock } from "lucide-react";


function CountdownTimer({ endDate, label }) {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const [isExpired, setIsExpired] = useState(false);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = new Date(endDate) - new Date();
      if (difference <= 0) {
        setIsExpired(true);
        return;
      }
      setTimeLeft({
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60)
      });
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);
    return () => clearInterval(timer);
  }, [endDate]);

  if (isExpired) return null;

  return (
    <div className="mt-2 sm:mt-3 mb-2">
      <div className="inline-flex flex-col items-start w-full max-w-full overflow-hidden">
        <div className="flex items-center gap-1.5 mb-2">
          <Clock className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-[#d4a853] animate-pulse" />
          <span className="text-[#d4a853] text-[10px] sm:text-xs font-body tracking-wider uppercase">
            {label || "Sale Ends In"}
          </span>
        </div>
        <div className="flex gap-1.5 sm:gap-2 flex-wrap">
          {[
            { value: timeLeft.days, label: "Days" },
            { value: timeLeft.hours, label: "Hours" },
            { value: timeLeft.minutes, label: "Mins" },
            { value: timeLeft.seconds, label: "Secs" }
          ].map((item, idx) => (
            <div key={idx} className="text-center flex-shrink-0">
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 flex items-center justify-center">
                <span className="text-sm sm:text-base md:text-lg font-bold text-white font-display">
                  {String(item.value).padStart(2, '0')}
                </span>
              </div>
              <span className="text-[8px] sm:text-[9px] text-gray-400 mt-0.5 block font-body">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default React.memo(function HeroCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const { data: banners = [], isLoading } = useQuery({
    queryKey: ['banners'],
    queryFn: async () => {
      const data = await base44.entities.Banner.filter({ position: "hero", is_active: true });
      return data.sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
    },
    staleTime: 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
  });

  // Preload next slide image
  useEffect(() => {
    if (banners.length > 1) {
      const nextIndex = (currentSlide + 1) % banners.length;
      const img = new Image();
      img.src = banners[nextIndex]?.image_url;
    }
  }, [currentSlide, banners]);

  const heroSlides = banners;

  useEffect(() => {
    if (heroSlides.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 8000);
    return () => clearInterval(timer);
  }, [heroSlides.length]);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + heroSlides.length) % heroSlides.length);

  if (heroSlides.length === 0 && !isLoading) {
    return null;
  }

  return (
    <div className="relative w-full bg-[#0a0a0a] overflow-hidden" style={{ aspectRatio: '16/9' }}>
        {heroSlides.map((slide, index) => (
          index === currentSlide && (
            <div
              key={slide.id}
              className="absolute inset-0 animate-fadeIn"
            >
              {/* Background Image - Fixed 16:9 */}
              <div className="absolute inset-0">
                <picture>
                  <source 
                    media="(min-width: 768px)" 
                    srcSet={slide.image_url} 
                  />
                  <img 
                    src={slide.mobile_image_url || slide.image_url}
                    alt={slide.title}
                    width="1920"
                    height="1080"
                    className="w-full h-full object-cover"
                    loading={index === 0 ? "eager" : "lazy"}
                    fetchpriority={index === 0 ? "high" : "auto"}
                    decoding="async"
                  />
                </picture>
              </div>
              <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent" />

              {/* Content - Responsive within 16:9 */}
              <div className="relative h-full max-w-7xl mx-auto px-3 sm:px-4 md:px-6 flex items-center py-4 sm:py-6 md:py-8">
                <div className="max-w-md text-white overflow-hidden">
                  {slide.subtitle && (
                    <span className="inline-block text-[#d4a853] text-[10px] sm:text-xs tracking-wider uppercase mb-1 sm:mb-2 font-body">
                      {slide.subtitle}
                    </span>
                  )}
                  <h1 className="font-display text-xl sm:text-2xl md:text-3xl lg:text-4xl font-light mb-1 sm:mb-2 md:mb-3 leading-tight break-words">
                    {slide.title}
                  </h1>
                  {slide.description && (
                    <p className="text-gray-300 text-[11px] sm:text-xs md:text-sm mb-2 sm:mb-3 font-body font-light leading-snug line-clamp-2">
                      {slide.description}
                    </p>
                  )}
                  
                  {slide.timer_enabled && slide.timer_end_date && (
                    <CountdownTimer endDate={slide.timer_end_date} label={slide.timer_label} />
                  )}
                  
                  {slide.link_url && (
                    <Link to={slide.link_url.startsWith("/") ? createPageUrl("Shop") + slide.link_url.replace("/Shop", "") : slide.link_url}>
                      <Button 
                        className="bg-[#d4a853] hover:bg-[#c49743] text-black px-3 sm:px-4 md:px-6 py-1.5 sm:py-2 md:py-2.5 text-[10px] sm:text-xs tracking-wider rounded-none h-auto"
                      >
                        {slide.button_text || "Shop Now"}
                      </Button>
                    </Link>
                  )}
                </div>
              </div>
            </div>
          )
        ))}

      {/* Navigation Arrows */}
      <button 
        onClick={prevSlide}
        className="absolute left-2 md:left-4 lg:left-8 top-1/2 -translate-y-1/2 w-8 h-8 md:w-10 md:h-10 lg:w-12 lg:h-12 bg-white/10 flex items-center justify-center hover:bg-white/20 z-10"
      >
        <ChevronLeft className="w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6 text-white" />
      </button>
      <button 
        onClick={nextSlide}
        className="absolute right-2 md:right-4 lg:right-8 top-1/2 -translate-y-1/2 w-8 h-8 md:w-10 md:h-10 lg:w-12 lg:h-12 bg-white/10 flex items-center justify-center hover:bg-white/20 z-10"
      >
        <ChevronRight className="w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6 text-white" />
      </button>

      {/* Dots */}
      <div className="absolute bottom-4 md:bottom-8 left-1/2 -translate-x-1/2 flex gap-2 md:gap-3 z-10">
        {heroSlides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-8 md:w-12 h-1 transition-all duration-300 ${
              index === currentSlide ? "bg-[#d4a853]" : "bg-white/30"
            }`}
          />
        ))}
      </div>


    </div>
    );
    });