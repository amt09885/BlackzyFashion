import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";
import { Heart, ShoppingBag, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { useQueryClient } from "@tanstack/react-query";

export default React.memo(function ProductCard({ product, onQuickView }) {
  const [isHovered, setIsHovered] = useState(false);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [imgLoaded, setImgLoaded] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const discount = React.useMemo(() => 
    product.sale_price ? Math.round((1 - product.sale_price / product.price) * 100) : 0,
    [product.sale_price, product.price]
  );

  const getSessionId = () => {
    let sessionId = localStorage.getItem('guest_session_id');
    if (!sessionId) {
      sessionId = 'guest_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
      localStorage.setItem('guest_session_id', sessionId);
    }
    return sessionId;
  };

  const handleAddToCart = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    try {
      const isAuth = await base44.auth.isAuthenticated();
      let cartData = {
        product_id: product.id,
        product_name: product.name,
        product_image: product.images?.[0] || "",
        price: product.sale_price || product.price,
        quantity: 1
      };

      if (isAuth) {
        const user = await base44.auth.me();
        cartData.user_email = user.email;
      } else {
        cartData.session_id = getSessionId();
      }

      await base44.entities.CartItem.create(cartData);
      
      toast({
        title: "Added to Cart",
        description: `${product.name} has been added to your cart.`,
      });
      
      queryClient.invalidateQueries({ queryKey: ['cart-items'] });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to add item to cart.",
        variant: "destructive"
      });
    }
  };

  const handleWishlist = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      
      const user = await base44.auth.me();
      
      if (isWishlisted) {
        const wishlist = await base44.entities.Wishlist.filter({
          user_email: user.email,
          product_id: product.id
        });
        if (wishlist.length > 0) {
          await base44.entities.Wishlist.delete(wishlist[0].id);
        }
        setIsWishlisted(false);
        toast({ title: "Removed from Wishlist" });
      } else {
        await base44.entities.Wishlist.create({
          user_email: user.email,
          product_id: product.id,
          product_name: product.name,
          product_image: product.images?.[0] || "",
          product_price: product.sale_price || product.price
        });
        setIsWishlisted(true);
        toast({ title: "Added to Wishlist" });
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div
      className="group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Link to={createPageUrl("ProductDetail") + `?id=${product.id}`}>
        <div className="relative overflow-hidden bg-gray-100 aspect-[3/4]">
          {/* Loading Skeleton */}
          {!imgLoaded && (
            <div className="absolute inset-0 bg-gray-200" />
          )}
          
          {/* Product Image */}
          <img
            src={product.images?.[0] || "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=600"}
            alt={product.name}
            loading="lazy"
            decoding="async"
            width="400"
            height="533"
            onLoad={() => setImgLoaded(true)}
            className={`w-full h-full object-cover ${
              isHovered && product.images?.[1] ? "hidden" : "block"
            } ${imgLoaded ? "opacity-100" : "opacity-0"}`}
          />
          {product.images?.[1] && isHovered && (
            <img
              src={product.images[1]}
              alt={product.name}
              loading="lazy"
              decoding="async"
              width="400"
              height="533"
              className="absolute inset-0 w-full h-full object-cover block"
            />
          )}
          
          {/* Badges */}
          <div className="absolute top-2 left-2 sm:top-3 sm:left-3 flex flex-col gap-1 sm:gap-2">
            {discount > 0 && (
              <Badge className="bg-red-500 text-white rounded-none px-1.5 sm:px-2 py-0.5 sm:py-1 text-[10px] sm:text-xs">
                -{discount}%
              </Badge>
            )}
            {product.is_new_arrival && (
              <Badge className="bg-[#d4a853] text-black rounded-none px-1.5 sm:px-2 py-0.5 sm:py-1 text-[10px] sm:text-xs">
                NEW
              </Badge>
            )}
            {product.is_bestseller && (
              <Badge className="bg-[#0a0a0a] text-white rounded-none px-1.5 sm:px-2 py-0.5 sm:py-1 text-[10px] sm:text-xs">
                BESTSELLER
              </Badge>
            )}
          </div>

          {/* Quick Actions - Always Visible */}
          <div className="absolute top-2 right-2 sm:top-3 sm:right-3 flex flex-col gap-1.5 sm:gap-2">
            <button 
              onClick={handleWishlist}
              className={`w-8 h-8 sm:w-10 sm:h-10 bg-white shadow-md flex items-center justify-center hover:bg-[#0a0a0a] hover:text-white ${
                isWishlisted ? "text-red-500" : ""
              }`}
            >
              <Heart className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${isWishlisted ? "fill-current" : ""}`} />
            </button>
            {onQuickView && (
              <button 
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onQuickView(product);
                }}
                className="w-8 h-8 sm:w-10 sm:h-10 bg-white shadow-md flex items-center justify-center hover:bg-[#0a0a0a] hover:text-white"
              >
                <Eye className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              </button>
            )}
          </div>

          {/* Action Buttons - Always Visible */}
          <div className="absolute bottom-0 left-0 right-0 p-2 sm:p-3 flex gap-1.5 sm:gap-2">
            <Button 
              onClick={handleAddToCart}
              className="flex-1 bg-[#0a0a0a] hover:bg-[#d4a853] hover:text-black text-white rounded-none py-2 sm:py-2.5 text-[10px] sm:text-xs tracking-wider px-1 sm:px-3"
            >
              <ShoppingBag className="w-3 h-3 sm:w-3.5 sm:h-3.5 mr-1 sm:mr-1.5" />
              <span className="hidden xs:inline">ADD TO </span>CART
            </Button>
            <Button 
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                // Direct buy without login
                const params = new URLSearchParams({
                  product: product.id,
                  qty: "1"
                });
                window.location.href = createPageUrl("QuickCheckout") + "?" + params.toString();
              }}
              className="flex-1 bg-[#d4a853] hover:bg-[#c49743] text-black rounded-none py-2 sm:py-2.5 text-[10px] sm:text-xs tracking-wider px-1 sm:px-3"
            >
              BUY NOW
            </Button>
          </div>

          {/* Out of Stock Overlay */}
          {product.stock_quantity === 0 && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <span className="text-white font-body text-sm tracking-wider">OUT OF STOCK</span>
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="pt-4 pb-2">
          <span className="text-xs text-gray-500 uppercase tracking-wider font-body">
            {product.fabric_type?.replace(/_/g, " ")}
          </span>
          <h3 className="font-display text-lg mt-1 text-[#0a0a0a] group-hover:text-[#d4a853] transition-colors line-clamp-1">
            {product.name}
          </h3>
          <div className="flex items-center gap-3 mt-2">
            {product.sale_price ? (
              <>
                <span className="font-body text-lg font-bold text-[#0a0a0a]">
                  ৳{product.sale_price.toLocaleString()}
                </span>
                <span className="font-body text-gray-400 line-through text-sm">
                  ৳{product.price.toLocaleString()}
                </span>
              </>
            ) : (
              <span className="font-body text-lg font-bold text-[#0a0a0a]">
                ৳{product.price?.toLocaleString()}
              </span>
            )}
          </div>
          
          {/* Color Options Preview */}
          {product.colors && product.colors.length > 0 && (
            <div className="flex gap-1 mt-3">
              {product.colors.slice(0, 4).map((color, i) => (
                <span 
                  key={i}
                  className="w-4 h-4 rounded-full border border-gray-200"
                  style={{ backgroundColor: color }}
                />
              ))}
              {product.colors.length > 4 && (
                <span className="text-xs text-gray-400 ml-1">
                  +{product.colors.length - 4}
                </span>
              )}
            </div>
          )}
        </div>
        </Link>
        </div>
        );
        });