import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";
import { 
  LayoutDashboard, Package, ShoppingCart, Users, Tag, 
  Image, Settings, LogOut, MessageSquare, Percent, FileText,
  HelpCircle, Facebook, Mail, Shield
} from "lucide-react";

const LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69258a473b6708fb6e444528/948bca0ec_Blackzyfashion.png";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", page: "AdminDashboard" },
  { icon: Package, label: "Products", page: "AdminProducts" },
  { icon: ShoppingCart, label: "Orders", page: "AdminOrders" },
  { icon: Users, label: "Customers", page: "AdminCustomers" },
  { icon: Tag, label: "Categories", page: "AdminCategories" },
  { icon: Percent, label: "Coupons", page: "AdminCoupons" },
  { icon: Image, label: "Banners", page: "AdminBanners" },
  { icon: MessageSquare, label: "Testimonials", page: "AdminTestimonials" },
  { icon: Facebook, label: "Facebook Feed", page: "AdminInstagram" },
  { icon: Mail, label: "Marketing", page: "AdminMarketing" },
  { icon: HelpCircle, label: "FAQ", page: "AdminFAQ" },
  { icon: FileText, label: "Pages", page: "AdminPages" },
  { icon: Settings, label: "Settings", page: "AdminSettings" },
  { icon: Shield, label: "Manage Admins", page: "AdminManageAdmins" },
];

export default function AdminSidebar({ mobile = false, currentPage }) {
  return (
    <div className={`${mobile ? "" : "hidden md:flex"} flex-col w-64 bg-[#0a0a0a] text-white h-screen`}>
      <div className="p-6 border-b border-white/10">
        <img src={LOGO_URL} alt="Blackzy" loading="lazy" decoding="async" className="h-10" />
        <p className="text-xs text-gray-500 mt-2">Admin Panel</p>
      </div>
      
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = currentPage === item.page || window.location.pathname.includes(item.page);
          return (
            <Link
              key={item.page}
              to={createPageUrl(item.page)}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg ${
                isActive 
                  ? "bg-[#d4a853] text-black" 
                  : "text-gray-400 hover:bg-white/10 hover:text-white"
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-sm font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>
      
      <div className="p-4 border-t border-white/10">
        <Link to={createPageUrl("Home")} className="flex items-center gap-3 px-4 py-3 text-gray-400 hover:text-white">
          <LogOut className="w-5 h-5" />
          <span className="text-sm">Back to Store</span>
        </Link>
      </div>
    </div>
  );
}