/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import About from './pages/About';
import Account from './pages/Account';
import AdminBanners from './pages/AdminBanners';
import AdminCategories from './pages/AdminCategories';
import AdminCoupons from './pages/AdminCoupons';
import AdminCustomers from './pages/AdminCustomers';
import AdminDashboard from './pages/AdminDashboard';
import AdminFAQ from './pages/AdminFAQ';
import AdminInstagram from './pages/AdminInstagram';
import AdminManageAdmins from './pages/AdminManageAdmins';
import AdminMarketing from './pages/AdminMarketing';
import AdminOrders from './pages/AdminOrders';
import AdminPages from './pages/AdminPages';
import AdminProducts from './pages/AdminProducts';
import AdminSettings from './pages/AdminSettings';
import AdminTestimonials from './pages/AdminTestimonials';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Contact from './pages/Contact';
import FAQ from './pages/FAQ';
import Home from './pages/Home';
import OrderSuccess from './pages/OrderSuccess';
import Orders from './pages/Orders';
import PrivacyPolicy from './pages/PrivacyPolicy';
import ProductDetail from './pages/ProductDetail';
import QuickCheckout from './pages/QuickCheckout';
import ReturnPolicy from './pages/ReturnPolicy';
import ShippingPolicy from './pages/ShippingPolicy';
import Shop from './pages/Shop';
import SizeGuide from './pages/SizeGuide';
import Terms from './pages/Terms';
import TrackOrder from './pages/TrackOrder';
import Wishlist from './pages/Wishlist';
import __Layout from './Layout.jsx';


export const PAGES = {
    "About": About,
    "Account": Account,
    "AdminBanners": AdminBanners,
    "AdminCategories": AdminCategories,
    "AdminCoupons": AdminCoupons,
    "AdminCustomers": AdminCustomers,
    "AdminDashboard": AdminDashboard,
    "AdminFAQ": AdminFAQ,
    "AdminInstagram": AdminInstagram,
    "AdminManageAdmins": AdminManageAdmins,
    "AdminMarketing": AdminMarketing,
    "AdminOrders": AdminOrders,
    "AdminPages": AdminPages,
    "AdminProducts": AdminProducts,
    "AdminSettings": AdminSettings,
    "AdminTestimonials": AdminTestimonials,
    "Cart": Cart,
    "Checkout": Checkout,
    "Contact": Contact,
    "FAQ": FAQ,
    "Home": Home,
    "OrderSuccess": OrderSuccess,
    "Orders": Orders,
    "PrivacyPolicy": PrivacyPolicy,
    "ProductDetail": ProductDetail,
    "QuickCheckout": QuickCheckout,
    "ReturnPolicy": ReturnPolicy,
    "ShippingPolicy": ShippingPolicy,
    "Shop": Shop,
    "SizeGuide": SizeGuide,
    "Terms": Terms,
    "TrackOrder": TrackOrder,
    "Wishlist": Wishlist,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};