import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Store, Truck, CreditCard, Bell,
  Loader2, Save, Globe, Mail, Phone,
  Facebook, Instagram, MapPin, Menu, Wallet, Upload, X, Plus, Layers
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useToast } from "@/components/ui/use-toast";
import AdminSidebar from "../components/admin/AdminSidebar";

export default function AdminSettings() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settingsId, setSettingsId] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [newFabricType, setNewFabricType] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [allFabricTypes, setAllFabricTypes] = useState([
    { id: "ac_cotton", label: "AC Cotton" },
    { id: "block_print", label: "Block Print" },
    { id: "gojkapor", label: "Gojkapor" },
    { id: "silk", label: "Silk" },
    { id: "muslin", label: "Muslin" },
    { id: "cotton", label: "Cotton" },
    { id: "jamdani", label: "Jamdani" },
    { id: "tant", label: "Tant" },
    { id: "katan", label: "Katan" },
    { id: "other", label: "Other" }
  ]);

  const addFabricType = () => {
    if (!newFabricType.trim()) return;
    const fabricExists = allFabricTypes.some(f => 
      f.label.toLowerCase() === newFabricType.trim().toLowerCase()
    );
    if (fabricExists) {
      toast({ title: "Fabric type already exists!", variant: "destructive" });
      return;
    }
    const newId = newFabricType.toLowerCase().replace(/\s+/g, '_');
    setAllFabricTypes([...allFabricTypes, { id: newId, label: newFabricType.trim() }]);
    toast({ title: "Fabric type added!" });
    setNewFabricType("");
  };

  const removeFabricType = (fabricId) => {
    setAllFabricTypes(allFabricTypes.filter(f => f.id !== fabricId));
    toast({ title: "Fabric type removed" });
  };

  const handleImageUpload = async (e, settingKey) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      updateSetting(settingKey, file_url);
      toast({ title: "Image uploaded successfully!" });
    } catch (error) {
      toast({ title: "Error uploading image", variant: "destructive" });
    }
    setUploading(false);
  };

  const [settings, setSettings] = useState({
    key: "main",
    phone: "+880 1XXX-XXXXXX",
    email: "info@blackzy.com",
    address: "Dhaka, Bangladesh",
    working_hours: "Sat-Thu: 10AM - 8PM",
    whatsapp_number: "8801XXXXXXXXX",
    facebook_url: "https://facebook.com/blackzyfashion",
    instagram_url: "https://instagram.com/blackzyfashion",
    instagram_handle: "@blackzyfashion",
    instagram_followers: "20K+",
    instagram_tagline: "Follow us on Facebook for daily style inspiration",
    footer_description: "Premium Bengali traditional fabrics and clothing. Authentic AC Cotton, Block Prints, and Gojkapor sarees.",
    free_shipping_threshold: 2000,
    copyright_text: "© 2024 Blackzy Fashion. All rights reserved.",
    feature_1_title: "Premium Quality",
    feature_1_description: "Handpicked fabrics from trusted artisans",
    feature_2_title: "Fast Delivery",
    feature_2_description: "Quick delivery across Bangladesh",
    feature_3_title: "Easy Returns",
    feature_3_description: "7-day hassle-free return policy",
    feature_4_title: "Secure Payment",
    feature_4_description: "Multiple secure payment options",
    testimonial_section_subtitle: "What Our Customers Say",
    testimonial_section_title: "Customer Reviews",
    testimonial_rating_text: "4.8 out of 5 based on 500+ reviews",
    promo_banner_subtitle: "Limited Time Offer",
    promo_banner_title: "Summer Collection 2024",
    promo_banner_description: "Discover our new collection of breathable AC Cotton fabrics.",
    promo_banner_button_text: "Shop Now",
    promo_banner_link: "/Shop?collection=summer",
    promo_banner_image: "",
    about_hero_subtitle: "Our Story",
    about_hero_title: "Blackzy Fashion",
    about_hero_description: "Bringing the finest Bengali traditional fabrics to your doorstep.",
    about_established_year: "2020",
    about_story_paragraph1: "",
    about_story_paragraph2: "",
    about_story_paragraph3: "",
    about_stat_followers: "20K+",
    about_stat_reviews: "500+",
    about_stat_rating: "4.8",
    about_stat_orders: "5000+",
    size_guide_saree_note: "Standard saree length",
    size_guide_fabric_note: "Available in various lengths",
    size_guide_help_text: "Need help? Contact us on WhatsApp",
    faq_page_title: "Frequently Asked Questions",
    faq_page_subtitle: "Find answers to common questions",
    faq_cta_title: "Still have questions?",
    faq_cta_text: "Contact our support team",
    shipping_inside_dhaka_days: "1-2",
    shipping_inside_dhaka_cost: "60",
    shipping_outside_dhaka_days: "3-5",
    shipping_outside_dhaka_cost: "120",
    shipping_remote_days: "5-7",
    shipping_remote_cost: "150",
    return_days: "7",
    bkash_number: "",
    nagad_number: "",
    bkash_enabled: true,
    nagad_enabled: true,
    cod_enabled: true,
    custom_fabric_types: []
  });

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      
      const userData = await base44.auth.me();
      if (userData.role !== "admin") {
        window.location.href = createPageUrl("Home");
        return;
      }
      
      // Load saved settings from SiteSettings entity
      const existingSettings = await base44.entities.SiteSettings.filter({ key: "main" });
      if (existingSettings.length > 0) {
        const saved = existingSettings[0];
        setSettingsId(saved.id);
        setSettings(prev => ({ ...prev, ...saved }));
      }
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      if (settingsId) {
        await base44.entities.SiteSettings.update(settingsId, settings);
      } else {
        const created = await base44.entities.SiteSettings.create(settings);
        setSettingsId(created.id);
      }
      // Invalidate site-settings cache to update frontend immediately
      queryClient.invalidateQueries({ queryKey: ['site-settings'] });
      toast({ title: "Settings saved successfully!" });
    } catch (e) {
      toast({ title: "Error saving settings", variant: "destructive" });
    }
    setSaving(false);
  };

  const updateSetting = (key, value) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar currentPage="AdminSettings" />
      
      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b px-4 md:px-8 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <AdminSidebar mobile currentPage="AdminSettings" />
                </SheetContent>
              </Sheet>
              <h1 className="text-xl font-bold">Site Settings</h1>
            </div>
            
            <Button 
              onClick={handleSave}
              disabled={saving}
              className="bg-[#d4a853] hover:bg-[#c49743] text-black"
            >
              {saving ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <Save className="w-4 h-4 mr-2" />
              )}
              Save Changes
            </Button>
          </div>
        </header>

        <main className="p-4 md:p-8">
          <Tabs defaultValue="store" className="space-y-6">
            <TabsList className="bg-white p-1 shadow-sm flex-wrap">
              <TabsTrigger value="store" className="gap-2">
                <Store className="w-4 h-4" />
                <span className="hidden sm:inline">Store Info</span>
              </TabsTrigger>
              <TabsTrigger value="shipping" className="gap-2">
                <Truck className="w-4 h-4" />
                <span className="hidden sm:inline">Shipping</span>
              </TabsTrigger>
              <TabsTrigger value="payment" className="gap-2">
                <Wallet className="w-4 h-4" />
                <span className="hidden sm:inline">Payment</span>
              </TabsTrigger>
              <TabsTrigger value="homepage" className="gap-2">
                <Globe className="w-4 h-4" />
                <span className="hidden sm:inline">Homepage</span>
              </TabsTrigger>
              <TabsTrigger value="about" className="gap-2">
                <Bell className="w-4 h-4" />
                <span className="hidden sm:inline">About Page</span>
              </TabsTrigger>
              <TabsTrigger value="products" className="gap-2">
                <Layers className="w-4 h-4" />
                <span className="hidden sm:inline">Products</span>
              </TabsTrigger>
              <TabsTrigger value="pixel" className="gap-2">
                <Facebook className="w-4 h-4" />
                <span className="hidden sm:inline">Meta Pixel</span>
              </TabsTrigger>
            </TabsList>

            {/* Store Info */}
            <TabsContent value="store" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Store className="w-5 h-5 text-[#d4a853]" />
                    Contact Information
                  </CardTitle>
                  <CardDescription>
                    Basic contact information shown across the site
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="flex items-center gap-2">
                        <Phone className="w-4 h-4" /> Phone
                      </Label>
                      <Input
                        value={settings.phone}
                        onChange={(e) => updateSetting("phone", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label className="flex items-center gap-2">
                        <Mail className="w-4 h-4" /> Email
                      </Label>
                      <Input
                        type="email"
                        value={settings.email}
                        onChange={(e) => updateSetting("email", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" /> Address
                      </Label>
                      <Input
                        value={settings.address}
                        onChange={(e) => updateSetting("address", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Working Hours</Label>
                      <Input
                        value={settings.working_hours}
                        onChange={(e) => updateSetting("working_hours", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label>WhatsApp Number (without +)</Label>
                    <Input
                      value={settings.whatsapp_number}
                      onChange={(e) => updateSetting("whatsapp_number", e.target.value)}
                      className="mt-1"
                      placeholder="8801XXXXXXXXX"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="w-5 h-5 text-[#d4a853]" />
                    Social Media
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="flex items-center gap-2">
                        <Facebook className="w-4 h-4" /> Facebook URL
                      </Label>
                      <Input
                        value={settings.facebook_url}
                        onChange={(e) => updateSetting("facebook_url", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label className="flex items-center gap-2">
                        <Instagram className="w-4 h-4" /> Instagram URL
                      </Label>
                      <Input
                        value={settings.instagram_url}
                        onChange={(e) => updateSetting("instagram_url", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Facebook Handle</Label>
                      <Input
                        value={settings.instagram_handle}
                        onChange={(e) => updateSetting("instagram_handle", e.target.value)}
                        className="mt-1"
                        placeholder="@blackzyfashion"
                      />
                    </div>
                    <div>
                      <Label>Facebook Followers</Label>
                      <Input
                        value={settings.instagram_followers}
                        onChange={(e) => updateSetting("instagram_followers", e.target.value)}
                        className="mt-1"
                        placeholder="20K+"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Footer Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Footer Description</Label>
                    <Textarea
                      value={settings.footer_description}
                      onChange={(e) => updateSetting("footer_description", e.target.value)}
                      className="mt-1"
                      rows={2}
                    />
                  </div>
                  <div>
                    <Label>Copyright Text</Label>
                    <Input
                      value={settings.copyright_text}
                      onChange={(e) => updateSetting("copyright_text", e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Shipping */}
            <TabsContent value="shipping" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Truck className="w-5 h-5 text-[#d4a853]" />
                    Shipping Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Free Shipping Threshold (৳)</Label>
                    <Input
                      type="number"
                      value={settings.free_shipping_threshold}
                      onChange={(e) => updateSetting("free_shipping_threshold", Number(e.target.value))}
                      className="mt-1"
                    />
                    <p className="text-xs text-gray-500 mt-1">Orders above this amount get free shipping</p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Inside Dhaka - Days</Label>
                      <Input
                        value={settings.shipping_inside_dhaka_days}
                        onChange={(e) => updateSetting("shipping_inside_dhaka_days", e.target.value)}
                        className="mt-1"
                        placeholder="1-2"
                      />
                    </div>
                    <div>
                      <Label>Inside Dhaka - Cost (৳)</Label>
                      <Input
                        value={settings.shipping_inside_dhaka_cost}
                        onChange={(e) => updateSetting("shipping_inside_dhaka_cost", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Outside Dhaka - Days</Label>
                      <Input
                        value={settings.shipping_outside_dhaka_days}
                        onChange={(e) => updateSetting("shipping_outside_dhaka_days", e.target.value)}
                        className="mt-1"
                        placeholder="3-5"
                      />
                    </div>
                    <div>
                      <Label>Outside Dhaka - Cost (৳)</Label>
                      <Input
                        value={settings.shipping_outside_dhaka_cost}
                        onChange={(e) => updateSetting("shipping_outside_dhaka_cost", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Remote Areas - Days</Label>
                      <Input
                        value={settings.shipping_remote_days}
                        onChange={(e) => updateSetting("shipping_remote_days", e.target.value)}
                        className="mt-1"
                        placeholder="5-7"
                      />
                    </div>
                    <div>
                      <Label>Remote Areas - Cost (৳)</Label>
                      <Input
                        value={settings.shipping_remote_cost}
                        onChange={(e) => updateSetting("shipping_remote_cost", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <div>
                    <Label>Return Days</Label>
                    <Input
                      value={settings.return_days}
                      onChange={(e) => updateSetting("return_days", e.target.value)}
                      className="mt-1"
                      placeholder="7"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Payment */}
            <TabsContent value="payment" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Wallet className="w-5 h-5 text-[#d4a853]" />
                    Payment Methods
                  </CardTitle>
                  <CardDescription>
                    Configure mobile payment numbers and enable/disable payment options
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* bKash */}
                  <div className="p-4 border rounded-lg bg-[#E2136E]/5 border-[#E2136E]/20">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <img 
                          src="https://www.logo.wine/a/logo/BKash/BKash-Icon-Logo.wine.svg" 
                          alt="bKash" 
                          className="h-10 object-contain"
                        />
                        <div>
                          <p className="font-medium">bKash Payment</p>
                          <p className="text-xs text-gray-500">Accept payments via bKash</p>
                        </div>
                      </div>
                      <Switch
                        checked={settings.bkash_enabled}
                        onCheckedChange={(v) => updateSetting("bkash_enabled", v)}
                      />
                    </div>
                    <div>
                      <Label>bKash Number</Label>
                      <Input
                        value={settings.bkash_number}
                        onChange={(e) => updateSetting("bkash_number", e.target.value)}
                        className="mt-1"
                        placeholder="01XXXXXXXXX"
                      />
                      <p className="text-xs text-gray-500 mt-1">Customers will send money to this number</p>
                    </div>
                  </div>

                  {/* Nagad */}
                  <div className="p-4 border rounded-lg bg-[#F6921E]/5 border-[#F6921E]/20">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <img 
                          src="https://download.logo.wine/logo/Nagad/Nagad-Logo.wine.png" 
                          alt="Nagad" 
                          className="h-10 object-contain"
                        />
                        <div>
                          <p className="font-medium">Nagad Payment</p>
                          <p className="text-xs text-gray-500">Accept payments via Nagad</p>
                        </div>
                      </div>
                      <Switch
                        checked={settings.nagad_enabled}
                        onCheckedChange={(v) => updateSetting("nagad_enabled", v)}
                      />
                    </div>
                    <div>
                      <Label>Nagad Number</Label>
                      <Input
                        value={settings.nagad_number}
                        onChange={(e) => updateSetting("nagad_number", e.target.value)}
                        className="mt-1"
                        placeholder="01XXXXXXXXX"
                      />
                      <p className="text-xs text-gray-500 mt-1">Customers will send money to this number</p>
                    </div>
                  </div>

                  {/* COD */}
                  <div className="p-4 border rounded-lg bg-gray-50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                          <Wallet className="w-5 h-5 text-gray-600" />
                        </div>
                        <div>
                          <p className="font-medium">Cash on Delivery</p>
                          <p className="text-xs text-gray-500">Accept payment upon delivery</p>
                        </div>
                      </div>
                      <Switch
                        checked={settings.cod_enabled}
                        onCheckedChange={(v) => updateSetting("cod_enabled", v)}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Homepage */}
            <TabsContent value="homepage" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Feature Highlights</CardTitle>
                  <CardDescription>The 4 feature cards shown on the homepage</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[1, 2, 3, 4].map(num => (
                    <div key={num} className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                      <div>
                        <Label>Feature {num} Title</Label>
                        <Input
                          value={settings[`feature_${num}_title`]}
                          onChange={(e) => updateSetting(`feature_${num}_title`, e.target.value)}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label>Feature {num} Description</Label>
                        <Input
                          value={settings[`feature_${num}_description`]}
                          onChange={(e) => updateSetting(`feature_${num}_description`, e.target.value)}
                          className="mt-1"
                        />
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Promo Banner</CardTitle>
                  <CardDescription>The promotional banner section on homepage</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Subtitle</Label>
                      <Input
                        value={settings.promo_banner_subtitle}
                        onChange={(e) => updateSetting("promo_banner_subtitle", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Title</Label>
                      <Input
                        value={settings.promo_banner_title}
                        onChange={(e) => updateSetting("promo_banner_title", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Description</Label>
                    <Textarea
                      value={settings.promo_banner_description}
                      onChange={(e) => updateSetting("promo_banner_description", e.target.value)}
                      className="mt-1"
                      rows={2}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Button Text</Label>
                      <Input
                        value={settings.promo_banner_button_text}
                        onChange={(e) => updateSetting("promo_banner_button_text", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Button Link</Label>
                      <Input
                        value={settings.promo_banner_link}
                        onChange={(e) => updateSetting("promo_banner_link", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Background Image</Label>
                    <div className="mt-2 space-y-3">
                      {settings.promo_banner_image ? (
                        <div className="relative inline-block">
                          <img 
                            src={settings.promo_banner_image} 
                            alt="Promo Banner" 
                            className="h-32 object-cover rounded-lg border"
                          />
                          <button
                            onClick={() => updateSetting("promo_banner_image", "")}
                            className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : null}
                      <div className="flex gap-2">
                        <Input
                          value={settings.promo_banner_image}
                          onChange={(e) => updateSetting("promo_banner_image", e.target.value)}
                          placeholder="https://... or upload an image"
                          className="flex-1"
                        />
                        <label className="cursor-pointer">
                          <div className="h-10 px-4 border rounded-md flex items-center gap-2 hover:bg-gray-50 transition-colors">
                            {uploading ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <Upload className="w-4 h-4" />
                            )}
                            <span className="text-sm">Upload</span>
                          </div>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleImageUpload(e, "promo_banner_image")}
                            className="hidden"
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Testimonials Section</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Section Subtitle</Label>
                      <Input
                        value={settings.testimonial_section_subtitle}
                        onChange={(e) => updateSetting("testimonial_section_subtitle", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Section Title</Label>
                      <Input
                        value={settings.testimonial_section_title}
                        onChange={(e) => updateSetting("testimonial_section_title", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Rating Text</Label>
                    <Input
                      value={settings.testimonial_rating_text}
                      onChange={(e) => updateSetting("testimonial_rating_text", e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* About Page */}
            <TabsContent value="about" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>About Page Hero</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Subtitle</Label>
                      <Input
                        value={settings.about_hero_subtitle}
                        onChange={(e) => updateSetting("about_hero_subtitle", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Title</Label>
                      <Input
                        value={settings.about_hero_title}
                        onChange={(e) => updateSetting("about_hero_title", e.target.value)}
                        className="mt-1"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Description</Label>
                    <Textarea
                      value={settings.about_hero_description}
                      onChange={(e) => updateSetting("about_hero_description", e.target.value)}
                      className="mt-1"
                      rows={2}
                    />
                  </div>
                  <div>
                    <Label>Established Year</Label>
                    <Input
                      value={settings.about_established_year}
                      onChange={(e) => updateSetting("about_established_year", e.target.value)}
                      className="mt-1"
                      placeholder="2020"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>About Statistics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <Label>Followers</Label>
                      <Input
                        value={settings.about_stat_followers}
                        onChange={(e) => updateSetting("about_stat_followers", e.target.value)}
                        className="mt-1"
                        placeholder="20K+"
                      />
                    </div>
                    <div>
                      <Label>Reviews</Label>
                      <Input
                        value={settings.about_stat_reviews}
                        onChange={(e) => updateSetting("about_stat_reviews", e.target.value)}
                        className="mt-1"
                        placeholder="500+"
                      />
                    </div>
                    <div>
                      <Label>Rating</Label>
                      <Input
                        value={settings.about_stat_rating}
                        onChange={(e) => updateSetting("about_stat_rating", e.target.value)}
                        className="mt-1"
                        placeholder="4.8"
                      />
                    </div>
                    <div>
                      <Label>Orders</Label>
                      <Input
                        value={settings.about_stat_orders}
                        onChange={(e) => updateSetting("about_stat_orders", e.target.value)}
                        className="mt-1"
                        placeholder="5000+"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Products Settings */}
            <TabsContent value="products" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Layers className="w-5 h-5 text-[#d4a853]" />
                    Manage Fabric Types
                  </CardTitle>
                  <CardDescription>
                    Add or remove fabric types for your products. Hover over a type to see the delete option.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Add New Fabric Type */}
                  <div className="flex gap-2">
                    <Input
                      value={newFabricType}
                      onChange={(e) => setNewFabricType(e.target.value)}
                      placeholder="Enter new fabric type name..."
                      className="flex-1"
                      onKeyPress={(e) => e.key === 'Enter' && addFabricType()}
                    />
                    <Button 
                      onClick={addFabricType}
                      className="bg-[#d4a853] hover:bg-[#c49743] text-black"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add
                    </Button>
                  </div>

                  {/* All Fabric Types */}
                  <div>
                    <Label className="text-sm font-medium mb-3 block">All Fabric Types</Label>
                    <div className="flex flex-wrap gap-2">
                      {allFabricTypes.map(fabric => (
                        <div 
                          key={fabric.id}
                          className="px-3 py-1.5 bg-[#d4a853]/10 text-[#0a0a0a] text-sm rounded-full flex items-center gap-2 group"
                        >
                          {fabric.label}
                          <button
                            onClick={() => removeFabricType(fabric.id)}
                            className="hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Meta Pixel Tab */}
            <TabsContent value="pixel" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Facebook className="w-5 h-5 text-[#1877F2]" />
                        Meta Pixel Configuration
                      </CardTitle>
                      <CardDescription className="mt-2">
                        Track conversions and optimize your Facebook/Instagram ads
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Label htmlFor="pixel-enabled" className="text-sm">Enable Pixel</Label>
                      <Switch
                        id="pixel-enabled"
                        checked={settings.meta_pixel_enabled || false}
                        onCheckedChange={(v) => updateSetting("meta_pixel_enabled", v)}
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <Label>Meta Pixel ID *</Label>
                    <Input
                      value={settings.meta_pixel_id || ""}
                      onChange={(e) => updateSetting("meta_pixel_id", e.target.value)}
                      placeholder="1234567890123456"
                      className="mt-1"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Find this in your Facebook Events Manager
                    </p>
                  </div>

                  <div>
                    <Label>Pixel Access Token (Optional)</Label>
                    <Input
                      value={settings.meta_pixel_access_token || ""}
                      onChange={(e) => updateSetting("meta_pixel_access_token", e.target.value)}
                      placeholder="EAAxxxxxxxxxx"
                      type="password"
                      className="mt-1"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Required for Conversions API (server-side tracking)
                    </p>
                  </div>

                  <div>
                    <Label>Test Event Code (Testing Only)</Label>
                    <Input
                      value={settings.meta_pixel_test_id || ""}
                      onChange={(e) => updateSetting("meta_pixel_test_id", e.target.value)}
                      placeholder="TEST12345"
                      className="mt-1"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Use this to test events without affecting your data. Remove before going live.
                    </p>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                    <h4 className="font-semibold text-sm mb-2">📋 Setup Instructions:</h4>
                    <ol className="text-sm text-gray-600 space-y-1 list-decimal list-inside">
                      <li>Go to <a href="https://business.facebook.com/events_manager" target="_blank" className="text-blue-600 underline">Facebook Events Manager</a></li>
                      <li>Select your Pixel and copy the Pixel ID from the top</li>
                      <li>Paste the Pixel ID above</li>
                      <li>Enable the pixel using the toggle</li>
                      <li>Click "Save Changes" at the top</li>
                      <li>Test using <a href="https://chrome.google.com/webstore/detail/meta-pixel-helper/fdgfkebogiimcoedlicjlajpkdmockpc" target="_blank" className="text-blue-600 underline">Meta Pixel Helper</a> Chrome extension</li>
                    </ol>
                  </div>

                  <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                    <h4 className="font-semibold text-sm mb-2 flex items-center gap-2">
                      ✅ Tracked Events
                    </h4>
                    <ul className="text-sm text-gray-600 space-y-1.5">
                      <li><strong>PageView</strong> - Every page visit</li>
                      <li><strong>ViewContent</strong> - Product detail page views</li>
                      <li><strong>AddToCart</strong> - Items added to cart</li>
                      <li><strong>InitiateCheckout</strong> - Checkout process started</li>
                      <li><strong>Purchase</strong> - Completed orders with transaction details</li>
                    </ul>
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                    <h4 className="font-semibold text-sm mb-2">⚠️ Important Notes:</h4>
                    <ul className="text-sm text-gray-600 space-y-1 list-disc list-inside">
                      <li>Pixel must be enabled for tracking to work</li>
                      <li>Test Event Code is optional and should only be used during testing</li>
                      <li>Access Token is optional but recommended for advanced tracking</li>
                      <li>Make sure to verify events in Facebook Events Manager after setup</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}