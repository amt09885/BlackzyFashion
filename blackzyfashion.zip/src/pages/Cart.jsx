import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Minus, Plus, X, ShoppingBag, ArrowRight, 
  Truck, Tag, Loader2, ChevronLeft
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";


export default function Cart() {
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState(null);
  const [applyingCoupon, setApplyingCoupon] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadCart();
  }, []);

  const getSessionId = () => {
    return localStorage.getItem('guest_session_id');
  };

  const loadCart = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      let items = [];
      
      if (isAuth) {
        const user = await base44.auth.me();
        items = await base44.entities.CartItem.filter({ user_email: user.email });
      } else {
        const sessionId = getSessionId();
        if (sessionId) {
          items = await base44.entities.CartItem.filter({ session_id: sessionId });
        }
      }
      
      setCartItems(items);
    } catch (e) {
      console.error("Error loading cart:", e);
    }
    setLoading(false);
  };

  const updateQuantity = async (item, newQuantity) => {
    if (newQuantity < 1) return;
    
    try {
      await base44.entities.CartItem.update(item.id, { quantity: newQuantity });
      setCartItems(prev => prev.map(i => 
        i.id === item.id ? { ...i, quantity: newQuantity } : i
      ));
    } catch (e) {
      toast({ title: "Error updating quantity", variant: "destructive" });
    }
  };

  const removeItem = async (itemId) => {
    try {
      await base44.entities.CartItem.delete(itemId);
      setCartItems(prev => prev.filter(i => i.id !== itemId));
      toast({ title: "Item removed from cart" });
    } catch (e) {
      toast({ title: "Error removing item", variant: "destructive" });
    }
  };

  const applyCoupon = async () => {
    if (!couponCode.trim()) return;
    
    setApplyingCoupon(true);
    try {
      const coupons = await base44.entities.Coupon.filter({ 
        code: couponCode.toUpperCase(),
        is_active: true 
      });
      
      if (coupons.length === 0) {
        toast({ title: "Invalid coupon code", variant: "destructive" });
        setApplyingCoupon(false);
        return;
      }
      
      const coupon = coupons[0];
      const now = new Date();
      
      if (coupon.valid_from && new Date(coupon.valid_from) > now) {
        toast({ title: "Coupon is not yet valid", variant: "destructive" });
        setApplyingCoupon(false);
        return;
      }
      
      if (coupon.valid_until && new Date(coupon.valid_until) < now) {
        toast({ title: "Coupon has expired", variant: "destructive" });
        setApplyingCoupon(false);
        return;
      }
      
      if (coupon.minimum_order_amount && subtotal < coupon.minimum_order_amount) {
        toast({ 
          title: `Minimum order amount is ৳${coupon.minimum_order_amount.toLocaleString()}`, 
          variant: "destructive" 
        });
        setApplyingCoupon(false);
        return;
      }
      
      setAppliedCoupon(coupon);
      toast({ title: "Coupon applied successfully!" });
    } catch (e) {
      toast({ title: "Error applying coupon", variant: "destructive" });
    }
    setApplyingCoupon(false);
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode("");
  };

  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  let discountAmount = 0;
  if (appliedCoupon) {
    if (appliedCoupon.discount_type === "percentage") {
      discountAmount = (subtotal * appliedCoupon.discount_value) / 100;
      if (appliedCoupon.max_discount_amount && discountAmount > appliedCoupon.max_discount_amount) {
        discountAmount = appliedCoupon.max_discount_amount;
      }
    } else {
      discountAmount = appliedCoupon.discount_value;
    }
  }
  
  const shippingCost = subtotal >= 2000 ? 0 : 80;
  const total = subtotal - discountAmount + shippingCost;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#fafafa]">
      {/* Header */}
      <div className="bg-[#0a0a0a] py-16 px-4">
        <div className="max-w-7xl mx-auto text-center text-white">
          <h1 className="font-display text-4xl md:text-5xl mb-4">Shopping Cart</h1>
          <p className="text-gray-400 font-body">
            {cartItems.length} {cartItems.length === 1 ? "item" : "items"} in your cart
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {cartItems.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
                {cartItems.map((item) => (
                  <div
                    key={item.id}
                    className="bg-white p-4 md:p-6 flex gap-4 md:gap-6"
                  >
                    {/* Image */}
                    <Link 
                      to={createPageUrl("ProductDetail") + `?id=${item.product_id}`}
                      className="w-24 h-24 md:w-32 md:h-32 bg-gray-100 flex-shrink-0"
                    >
                      <img 
                        src={item.product_image || "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=200"}
                        alt={item.product_name}
                        loading="lazy"
                        decoding="async"
                        className="w-full h-full object-cover"
                      />
                    </Link>
                    
                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <Link 
                        to={createPageUrl("ProductDetail") + `?id=${item.product_id}`}
                        className="font-display text-lg hover:text-[#d4a853] line-clamp-1"
                      >
                        {item.product_name}
                      </Link>
                      
                      <div className="flex flex-wrap gap-2 mt-2 text-sm text-gray-500 font-body">
                        {item.size && <span>Size: {item.size}</span>}
                        {item.color && <span>• Color: {item.color}</span>}
                      </div>
                      
                      <p className="font-body text-lg font-bold mt-2">
                        ৳{item.price.toLocaleString()}
                      </p>
                      
                      {/* Quantity & Remove */}
                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center border border-gray-200">
                          <button 
                            onClick={() => updateQuantity(item, item.quantity - 1)}
                            className="w-8 h-8 flex items-center justify-center hover:bg-gray-100"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-10 text-center font-body text-sm">
                            {item.quantity}
                          </span>
                          <button 
                            onClick={() => updateQuantity(item, item.quantity + 1)}
                            className="w-8 h-8 flex items-center justify-center hover:bg-gray-100"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                        
                        <button 
                          onClick={() => removeItem(item.id)}
                          className="text-gray-400 hover:text-red-500"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                    
                    {/* Item Total */}
                    <div className="hidden md:block text-right">
                      <p className="font-body text-lg font-bold">
                        ৳{(item.price * item.quantity).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              
              {/* Continue Shopping */}
              <Link 
                to={createPageUrl("Shop")}
                className="inline-flex items-center gap-2 text-sm text-gray-600 hover:text-[#d4a853] font-body mt-4"
              >
                <ChevronLeft className="w-4 h-4" />
                Continue Shopping
              </Link>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white p-6 sticky top-24">
                <h2 className="font-display text-xl mb-6">Order Summary</h2>
                
                {/* Coupon */}
                <div className="mb-6">
                  {appliedCoupon ? (
                    <div className="flex items-center justify-between bg-green-50 p-3 border border-green-200">
                      <div className="flex items-center gap-2">
                        <Tag className="w-4 h-4 text-green-600" />
                        <span className="text-sm font-body text-green-700">
                          {appliedCoupon.code}
                        </span>
                      </div>
                      <button 
                        onClick={removeCoupon}
                        className="text-green-600 hover:text-green-700"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <Input
                        placeholder="Enter coupon code"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                        className="rounded-none flex-1"
                      />
                      <Button 
                        onClick={applyCoupon}
                        disabled={applyingCoupon}
                        variant="outline"
                        className="rounded-none border-[#0a0a0a]"
                      >
                        {applyingCoupon ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          "Apply"
                        )}
                      </Button>
                    </div>
                  )}
                </div>
                
                {/* Summary */}
                <div className="space-y-3 border-t pt-4">
                  <div className="flex justify-between text-sm font-body">
                    <span className="text-gray-600">Subtotal</span>
                    <span className="font-bold">৳{subtotal.toLocaleString()}</span>
                  </div>
                  
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-sm font-body text-green-600">
                      <span>Discount</span>
                      <span>-৳{discountAmount.toLocaleString()}</span>
                    </div>
                  )}
                  
                  <div className="flex justify-between text-sm font-body">
                    <span className="text-gray-600">Shipping</span>
                    <span className="font-bold">
                      {shippingCost === 0 ? (
                        <span className="text-green-600">FREE</span>
                      ) : (
                        `৳${shippingCost}`
                      )}
                    </span>
                  </div>
                  
                  <div className="flex justify-between text-lg font-body border-t pt-3 mt-3">
                    <span className="font-medium">Total</span>
                    <span className="font-bold">৳{total.toLocaleString()}</span>
                  </div>
                </div>
                
                {/* Free Shipping Progress */}
                {subtotal < 2000 && (
                  <div className="mt-4 p-3 bg-[#faf8f5]">
                    <div className="flex items-center gap-2 text-sm font-body">
                      <Truck className="w-4 h-4 text-[#d4a853]" />
                      <span>
                        Add ৳{(2000 - subtotal).toLocaleString()} more for free delivery!
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 h-1 mt-2">
                    <div 
                      className="bg-[#d4a853] h-1"
                      style={{ width: `${Math.min((subtotal / 2000) * 100, 100)}%` }}
                    />
                    </div>
                  </div>
                )}
                
                {/* Checkout Button */}
                <Link to={createPageUrl("Checkout")}>
                  <Button 
                    className="w-full mt-6 bg-[#d4a853] hover:bg-[#c49743] text-black rounded-none py-6 text-sm tracking-wider"
                  >
                    PROCEED TO CHECKOUT
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
                
                {/* Payment Methods */}
                <div className="mt-6 pt-6 border-t">
                  <p className="text-xs text-gray-500 font-body text-center mb-3">
                    Secure Payment Options
                  </p>
                  <div className="flex justify-center gap-4">
                    <img 
                      src="https://www.logo.wine/a/logo/BKash/BKash-Icon-Logo.wine.svg" 
                      alt="bKash" 
                      loading="lazy"
                      decoding="async"
                      className="h-8 object-contain opacity-60"
                    />
                    <img 
                      src="https://download.logo.wine/logo/Nagad/Nagad-Logo.wine.png" 
                      alt="Nagad" 
                      loading="lazy"
                      decoding="async"
                      className="h-8 object-contain opacity-60"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-20">
            <ShoppingBag className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h2 className="font-display text-2xl mb-2">Your cart is empty</h2>
            <p className="text-gray-500 font-body mb-8">
              Looks like you haven't added anything to your cart yet.
            </p>
            <Link to={createPageUrl("Shop")}>
              <Button className="bg-[#0a0a0a] hover:bg-[#d4a853] hover:text-black rounded-none px-8">
                Start Shopping
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}