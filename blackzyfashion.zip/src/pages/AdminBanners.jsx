import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  Image, Plus, Pencil, Trash2,
  Menu, Loader2, Upload, GripVertical, Eye, Timer
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useToast } from "@/components/ui/use-toast";

import AdminSidebar from "../components/admin/AdminSidebar";

const positionLabels = {
  hero: "Hero Slider",
  category: "Category Banner",
  promo: "Promotional Banner"
};

export default function AdminBanners() {
  const [banners, setBanners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    title: "",
    subtitle: "",
    image_url: "",
    mobile_image_url: "",
    link_url: "",
    button_text: "",
    position: "hero",
    sort_order: 0,
    is_active: true,
    timer_enabled: false,
    timer_end_date: "",
    timer_label: "Sale Ends In"
  });

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      
      const userData = await base44.auth.me();
      if (userData.role !== "admin") {
        window.location.href = createPageUrl("Home");
        return;
      }
      
      loadBanners();
    } catch (e) {
      console.error(e);
    }
  };

  const loadBanners = async () => {
    setLoading(true);
    try {
      const data = await base44.entities.Banner.list("sort_order");
      setBanners(data);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const handleImageUpload = async (e, field) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({ ...prev, [field]: file_url }));
      toast({ title: "Image uploaded successfully" });
    } catch (err) {
      toast({ title: "Upload failed", variant: "destructive" });
    }
    setUploading(false);
  };

  const openCreateDialog = () => {
    setEditingBanner(null);
    setFormData({
      title: "",
      subtitle: "",
      image_url: "",
      mobile_image_url: "",
      link_url: "",
      button_text: "Shop Now",
      position: "hero",
      sort_order: banners.length,
      is_active: true,
      timer_enabled: false,
      timer_end_date: "",
      timer_label: "Sale Ends In"
    });
    setDialogOpen(true);
  };

  const openEditDialog = (banner) => {
    setEditingBanner(banner);
    setFormData({
      title: banner.title || "",
      subtitle: banner.subtitle || "",
      image_url: banner.image_url || "",
      mobile_image_url: banner.mobile_image_url || "",
      link_url: banner.link_url || "",
      button_text: banner.button_text || "",
      position: banner.position || "hero",
      sort_order: banner.sort_order || 0,
      is_active: banner.is_active !== false,
      timer_enabled: banner.timer_enabled || false,
      timer_end_date: banner.timer_end_date || "",
      timer_label: banner.timer_label || "Sale Ends In"
    });
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.title || !formData.image_url) {
      toast({ title: "Title and image are required", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      if (editingBanner) {
        await base44.entities.Banner.update(editingBanner.id, formData);
        toast({ title: "Banner updated successfully" });
      } else {
        await base44.entities.Banner.create(formData);
        toast({ title: "Banner created successfully" });
      }
      // Invalidate banners cache to update frontend immediately
      queryClient.invalidateQueries({ queryKey: ['banners'] });
      setDialogOpen(false);
      loadBanners();
    } catch (e) {
      toast({ title: "Error saving banner", variant: "destructive" });
    }
    setSaving(false);
  };

  const handleDelete = async (banner) => {
    if (!confirm("Are you sure you want to delete this banner?")) return;
    
    try {
      await base44.entities.Banner.delete(banner.id);
      toast({ title: "Banner deleted" });
      queryClient.invalidateQueries({ queryKey: ['banners'] });
      loadBanners();
    } catch (e) {
      toast({ title: "Error deleting banner", variant: "destructive" });
    }
  };

  const toggleActive = async (banner) => {
    try {
      await base44.entities.Banner.update(banner.id, { is_active: !banner.is_active });
      queryClient.invalidateQueries({ queryKey: ['banners'] });
      loadBanners();
    } catch (e) {
      toast({ title: "Error updating banner", variant: "destructive" });
    }
  };



  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar currentPage="AdminBanners" />
      
      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b px-4 md:px-8 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <AdminSidebar mobile currentPage="AdminBanners" />
                </SheetContent>
              </Sheet>
              <h1 className="text-xl font-bold">Banners</h1>
            </div>
            
            <Button 
              onClick={openCreateDialog}
              className="bg-[#d4a853] hover:bg-[#c49743] text-black"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Banner
            </Button>
          </div>
        </header>

        <main className="p-4 md:p-8">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Total Banners</p>
                    <p className="text-2xl font-bold">{banners.length}</p>
                  </div>
                  <Image className="w-8 h-8 text-[#d4a853]" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Active</p>
                    <p className="text-2xl font-bold">{banners.filter(b => b.is_active).length}</p>
                  </div>
                  <Eye className="w-8 h-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Hero Banners</p>
                    <p className="text-2xl font-bold">{banners.filter(b => b.position === "hero").length}</p>
                  </div>
                  <GripVertical className="w-8 h-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Banners Table */}
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-20">Image</TableHead>
                    <TableHead>Title</TableHead>
                    <TableHead>Position</TableHead>
                    <TableHead>Link</TableHead>
                    <TableHead>Order</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {banners.map((banner) => (
                    <TableRow key={banner.id}>
                      <TableCell>
                        <div className="w-16 h-10 bg-gray-100 rounded overflow-hidden">
                          <img 
                            src={banner.image_url} 
                            alt={banner.title}
                            loading="lazy"
                            decoding="async"
                            className="w-full h-full object-cover"
                          />
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{banner.title}</p>
                          {banner.subtitle && (
                            <p className="text-sm text-gray-500">{banner.subtitle}</p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {positionLabels[banner.position] || banner.position}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-500 max-w-[150px] truncate">
                        {banner.link_url || "-"}
                      </TableCell>
                      <TableCell>{banner.sort_order}</TableCell>
                      <TableCell>
                        <Switch
                          checked={banner.is_active}
                          onCheckedChange={() => toggleActive(banner)}
                        />
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openEditDialog(banner)}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(banner)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                  {banners.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-10 text-gray-500">
                        No banners yet. Create your first banner!
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </main>
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingBanner ? "Edit Banner" : "Add New Banner"}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Title *</Label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  className="mt-1"
                  placeholder="Summer Collection"
                />
              </div>
              <div>
                <Label>Subtitle</Label>
                <Input
                  value={formData.subtitle}
                  onChange={(e) => setFormData(prev => ({ ...prev, subtitle: e.target.value }))}
                  className="mt-1"
                  placeholder="New Arrivals"
                />
              </div>
            </div>

            <div>
              <Label>Banner Image *</Label>
              <div className="mt-1 flex gap-4">
                {formData.image_url && (
                  <div className="w-32 h-20 bg-gray-100 rounded overflow-hidden">
                    <img src={formData.image_url} alt="Banner" loading="lazy" decoding="async" className="w-full h-full object-cover" />
                  </div>
                )}
                <div className="flex-1">
                  <Input
                    value={formData.image_url}
                    onChange={(e) => setFormData(prev => ({ ...prev, image_url: e.target.value }))}
                    placeholder="Image URL"
                    className="mb-2"
                  />
                  <label className="cursor-pointer">
                    <div className="flex items-center gap-2 text-sm text-[#d4a853] hover:underline">
                      <Upload className="w-4 h-4" />
                      {uploading ? "Uploading..." : "Upload image"}
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleImageUpload(e, "image_url")}
                      disabled={uploading}
                    />
                  </label>
                </div>
              </div>
            </div>

            <div>
              <Label>Mobile Image (optional)</Label>
              <div className="mt-1 flex gap-4">
                {formData.mobile_image_url && (
                  <div className="w-20 h-20 bg-gray-100 rounded overflow-hidden">
                    <img src={formData.mobile_image_url} alt="Mobile" loading="lazy" decoding="async" className="w-full h-full object-cover" />
                  </div>
                )}
                <div className="flex-1">
                  <Input
                    value={formData.mobile_image_url}
                    onChange={(e) => setFormData(prev => ({ ...prev, mobile_image_url: e.target.value }))}
                    placeholder="Mobile Image URL"
                    className="mb-2"
                  />
                  <label className="cursor-pointer">
                    <div className="flex items-center gap-2 text-sm text-[#d4a853] hover:underline">
                      <Upload className="w-4 h-4" />
                      {uploading ? "Uploading..." : "Upload mobile image"}
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleImageUpload(e, "mobile_image_url")}
                      disabled={uploading}
                    />
                  </label>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Link URL</Label>
                <Input
                  value={formData.link_url}
                  onChange={(e) => setFormData(prev => ({ ...prev, link_url: e.target.value }))}
                  className="mt-1"
                  placeholder="/Shop?collection=summer"
                />
              </div>
              <div>
                <Label>Button Text</Label>
                <Input
                  value={formData.button_text}
                  onChange={(e) => setFormData(prev => ({ ...prev, button_text: e.target.value }))}
                  className="mt-1"
                  placeholder="Shop Now"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Position</Label>
                <Select
                  value={formData.position}
                  onValueChange={(v) => setFormData(prev => ({ ...prev, position: v }))}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hero">Hero Slider</SelectItem>
                    <SelectItem value="category">Category Banner</SelectItem>
                    <SelectItem value="promo">Promotional Banner</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Sort Order</Label>
                <Input
                  type="number"
                  value={formData.sort_order}
                  onChange={(e) => setFormData(prev => ({ ...prev, sort_order: Number(e.target.value) }))}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Switch
                checked={formData.is_active}
                onCheckedChange={(v) => setFormData(prev => ({ ...prev, is_active: v }))}
              />
              <Label>Active</Label>
            </div>

            {/* FOMO Timer Section */}
            {formData.position === "hero" && (
              <div className="p-4 border rounded-lg bg-orange-50 border-orange-200">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Timer className="w-5 h-5 text-orange-600" />
                    <Label className="font-medium text-orange-800">FOMO Countdown Timer</Label>
                  </div>
                  <Switch
                    checked={formData.timer_enabled}
                    onCheckedChange={(v) => setFormData(prev => ({ ...prev, timer_enabled: v }))}
                  />
                </div>
                
                {formData.timer_enabled && (
                  <div className="space-y-4">
                    <div>
                      <Label>Timer Label</Label>
                      <Input
                        value={formData.timer_label}
                        onChange={(e) => setFormData(prev => ({ ...prev, timer_label: e.target.value }))}
                        className="mt-1"
                        placeholder="Sale Ends In"
                      />
                    </div>
                    <div>
                      <Label>End Date & Time</Label>
                      <Input
                        type="datetime-local"
                        value={formData.timer_end_date ? formData.timer_end_date.slice(0, 16) : ""}
                        onChange={(e) => setFormData(prev => ({ ...prev, timer_end_date: e.target.value }))}
                        className="mt-1"
                      />
                      <p className="text-xs text-orange-600 mt-1">Timer will automatically hide when expired</p>
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="flex justify-end gap-3 pt-4">
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleSave}
                disabled={saving}
                className="bg-[#d4a853] hover:bg-[#c49743] text-black"
              >
                {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {editingBanner ? "Update" : "Create"} Banner
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}