import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Loader2, RotateCcw, CheckCircle, XCircle } from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function ReturnPolicy() {
  const { data: siteSettings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const settings = await base44.entities.SiteSettings.filter({ key: "main" });
      return settings[0] || null;
    },
    staleTime: 2 * 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const { data: pageContent, isLoading } = useQuery({
    queryKey: ['page-content', 'return_policy'],
    queryFn: async () => {
      const pages = await base44.entities.PageContent.filter({ page_key: "return_policy" });
      return pages[0] || null;
    },
    staleTime: 24 * 60 * 60 * 1000,
    cacheTime: 7 * 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const s = siteSettings || {};

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <section className="bg-[#0a0a0a] py-16 px-4">
        <div className="max-w-7xl mx-auto text-center text-white">
          <h1 className="font-display text-4xl md:text-5xl mb-4">
            {pageContent?.title || "Return & Refund Policy"}
          </h1>
          <p className="text-gray-400 font-body">
            {pageContent?.subtitle || "Hassle-free returns within " + (s.return_days || "7") + " days"}
          </p>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Return Window */}
          <div className="bg-[#d4a853]/10 border border-[#d4a853] rounded-lg p-6 mb-10 text-center">
            <RotateCcw className="w-12 h-12 text-[#d4a853] mx-auto mb-4" />
            <h2 className="font-display text-2xl mb-2">{s.return_days || "7"} Day Return Policy</h2>
            <p className="text-gray-600 font-body">Return your purchase within {s.return_days || "7"} days for a full refund or exchange</p>
          </div>

          {/* Custom Content or Default */}
          {pageContent?.content ? (
            <div className="prose prose-lg max-w-none font-body">
              <ReactMarkdown>{pageContent.content}</ReactMarkdown>
            </div>
          ) : (
            <div className="space-y-8">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-green-50 p-6 rounded-lg">
                  <h3 className="font-display text-lg mb-4 flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600" /> Eligible for Return
                  </h3>
                  <ul className="space-y-2 text-sm font-body text-gray-600">
                    <li>• Unused and unwashed items</li>
                    <li>• Original packaging intact</li>
                    <li>• All tags attached</li>
                    <li>• Within {s.return_days || "7"} days of delivery</li>
                    <li>• Manufacturing defects</li>
                  </ul>
                </div>
                <div className="bg-red-50 p-6 rounded-lg">
                  <h3 className="font-display text-lg mb-4 flex items-center gap-2">
                    <XCircle className="w-5 h-5 text-red-600" /> Not Eligible
                  </h3>
                  <ul className="space-y-2 text-sm font-body text-gray-600">
                    <li>• Used or washed items</li>
                    <li>• Items without tags</li>
                    <li>• Damaged by customer</li>
                    <li>• Sale/clearance items</li>
                    <li>• After {s.return_days || "7"} days</li>
                  </ul>
                </div>
              </div>

              <div className="font-body text-gray-600 space-y-6">
                <div>
                  <h3 className="font-display text-xl mb-3">How to Return</h3>
                  <ol className="list-decimal list-inside space-y-2">
                    <li>Contact us via WhatsApp or call within {s.return_days || "7"} days of delivery</li>
                    <li>Share your order number and reason for return</li>
                    <li>Our team will arrange a pickup from your address</li>
                    <li>Refund will be processed within 3-5 business days after receiving the item</li>
                  </ol>
                </div>
                <div>
                  <h3 className="font-display text-xl mb-3">Refund Methods</h3>
                  <p>Refunds are processed via the original payment method. For COD orders, refunds will be sent via bKash/Nagad.</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}