import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { CheckCircle, Package, ArrowRight, Home, FileText, Loader2 } from "lucide-react";

import { format } from "date-fns";

export default function OrderSuccess() {
  const params = new URLSearchParams(window.location.search);
  const orderNumber = params.get("order");
  const phone = params.get("phone");
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (orderNumber) {
      loadOrder();
    } else {
      setLoading(false);
    }
  }, [orderNumber]);

  useEffect(() => {
    if (!order) return;
    
    // Track Purchase event
    if (window.fbq) {
      window.fbq('track', 'Purchase', {
        content_ids: order.items?.map(item => item.product_id) || [],
        contents: order.items?.map(item => ({
          id: item.product_id,
          quantity: item.quantity
        })) || [],
        value: order.total,
        currency: 'BDT',
        num_items: order.items?.reduce((sum, item) => sum + item.quantity, 0) || 0
      });
    }
  }, [order]);

  const loadOrder = async () => {
    try {
      const orders = await base44.entities.Order.filter({ order_number: orderNumber });
      if (orders.length > 0) {
        setOrder(orders[0]);
      }
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const downloadInvoice = () => {
    if (!order) return;

    const LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69258a473b6708fb6e444528/864e69bb5_Blackzyfashion.png";
    
    const invoiceHTML = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Invoice - ${order.order_number}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@400;500;600&display=swap');
    
    * { margin: 0; padding: 0; box-sizing: border-box; }
    @page { size: A4; margin: 0; }
    
    body {
      font-family: 'Inter', sans-serif;
      background: #f5f5f5;
      color: #1a1a1a;
      font-size: 12px;
      line-height: 1.5;
    }
    
    .invoice-container {
      width: 210mm;
      min-height: 297mm;
      margin: 0 auto;
      background: white;
      padding: 40px;
      position: relative;
    }
    
    .header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      padding-bottom: 30px;
      border-bottom: 3px solid #d4a853;
      margin-bottom: 30px;
    }
    
    .logo-section img { height: 60px; margin-bottom: 10px; }
    .company-info { font-size: 11px; color: #666; }
    .invoice-title { text-align: right; }
    .invoice-title h1 {
      font-family: 'Cormorant Garamond', serif;
      font-size: 42px;
      font-weight: 600;
      color: #0a0a0a;
      letter-spacing: 4px;
    }
    .invoice-meta { margin-top: 10px; font-size: 12px; }
    .invoice-meta p { margin: 4px 0; }
    .invoice-meta strong { color: #d4a853; }
    
    .addresses { display: flex; justify-content: space-between; margin-bottom: 40px; }
    .address-box { width: 48%; }
    .address-box h3 {
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 2px;
      color: #d4a853;
      margin-bottom: 12px;
      font-weight: 600;
    }
    .address-box p { margin: 4px 0; color: #333; }
    
    .items-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
    .items-table th {
      background: #0a0a0a;
      color: white;
      padding: 14px 16px;
      text-align: left;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 1px;
      font-weight: 600;
    }
    .items-table th:last-child, .items-table td:last-child { text-align: right; }
    .items-table td { padding: 16px; border-bottom: 1px solid #eee; vertical-align: top; }
    .items-table tr:nth-child(even) { background: #fafafa; }
    .product-name { font-weight: 600; color: #0a0a0a; }
    .product-details { font-size: 11px; color: #888; margin-top: 4px; }
    
    .summary-section { display: flex; justify-content: flex-end; }
    .summary-box { width: 300px; background: #fafafa; padding: 24px; border-radius: 4px; }
    .summary-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }
    .summary-row:last-child { border-bottom: none; }
    .summary-row.total {
      border-top: 2px solid #0a0a0a;
      border-bottom: none;
      margin-top: 10px;
      padding-top: 16px;
      font-size: 18px;
      font-weight: 700;
    }
    .summary-row.total .amount { color: #d4a853; }
    
    .payment-info {
      display: flex;
      gap: 40px;
      margin-top: 40px;
      padding: 20px;
      background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
      color: white;
      border-radius: 4px;
    }
    .payment-info-item h4 {
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: #d4a853;
      margin-bottom: 6px;
    }
    .payment-info-item p { font-weight: 600; text-transform: capitalize; }
    
    .footer {
      position: absolute;
      bottom: 40px;
      left: 40px;
      right: 40px;
      text-align: center;
      padding-top: 20px;
      border-top: 1px solid #eee;
    }
    .footer p { color: #888; font-size: 11px; margin: 4px 0; }
    .footer .thank-you {
      font-family: 'Cormorant Garamond', serif;
      font-size: 20px;
      color: #0a0a0a;
      margin-bottom: 10px;
    }
    .gold-accent { color: #d4a853; }
    
    @media print { body { background: white; } .invoice-container { box-shadow: none; } }
  </style>
</head>
<body>
  <div class="invoice-container">
    <div class="header">
      <div class="logo-section">
        <img src="${LOGO_URL}" alt="Blackzy Fashion" />
        <div class="company-info">
          <p>Premium Bengali Traditional Fabrics</p>
          <p>Dhaka, Bangladesh</p>
        </div>
      </div>
      <div class="invoice-title">
        <h1>INVOICE</h1>
        <div class="invoice-meta">
          <p><strong>Invoice #:</strong> ${order.order_number}</p>
          <p><strong>Date:</strong> ${format(new Date(order.created_date), "MMMM d, yyyy")}</p>
          <p><strong>Time:</strong> ${format(new Date(order.created_date), "h:mm a")}</p>
        </div>
      </div>
    </div>
    
    <div class="addresses">
      <div class="address-box">
        <h3>Bill To</h3>
        <p><strong>${order.customer_name}</strong></p>
        <p>${order.customer_phone}</p>
        ${order.customer_email ? `<p>${order.customer_email}</p>` : ""}
      </div>
      <div class="address-box">
        <h3>Ship To</h3>
        <p><strong>${order.shipping_address?.full_name || order.customer_name}</strong></p>
        <p>${order.shipping_address?.address_line1 || ""}</p>
        ${order.shipping_address?.address_line2 ? `<p>${order.shipping_address.address_line2}</p>` : ""}
        <p>${order.shipping_address?.city || ""}, ${order.shipping_address?.district || ""}</p>
      </div>
    </div>
    
    <table class="items-table">
      <thead>
        <tr>
          <th style="width: 50%">Product</th>
          <th style="width: 15%">Price</th>
          <th style="width: 15%">Qty</th>
          <th style="width: 20%">Total</th>
        </tr>
      </thead>
      <tbody>
        ${order.items?.map(item => `
          <tr>
            <td>
              <div class="product-name">${item.product_name}</div>
              <div class="product-details">
                ${item.size ? `Size: ${item.size}` : ""} 
                ${item.color ? `${item.size ? " • " : ""}Color: ${item.color}` : ""}
              </div>
            </td>
            <td>৳${item.price?.toLocaleString()}</td>
            <td>${item.quantity}</td>
            <td>৳${(item.price * item.quantity).toLocaleString()}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
    
    <div class="summary-section">
      <div class="summary-box">
        <div class="summary-row">
          <span>Subtotal</span>
          <span>৳${order.subtotal?.toLocaleString()}</span>
        </div>
        <div class="summary-row">
          <span>Shipping</span>
          <span>${order.shipping_cost === 0 ? "FREE" : `৳${order.shipping_cost?.toLocaleString()}`}</span>
        </div>
        ${order.discount_amount > 0 ? `
          <div class="summary-row">
            <span>Discount</span>
            <span style="color: #22c55e;">-৳${order.discount_amount?.toLocaleString()}</span>
          </div>
        ` : ""}
        <div class="summary-row total">
          <span>Total</span>
          <span class="amount">৳${order.total?.toLocaleString()}</span>
        </div>
      </div>
    </div>
    
    <div class="payment-info">
      <div class="payment-info-item">
        <h4>Payment Method</h4>
        <p>${order.payment_method}</p>
      </div>
      <div class="payment-info-item">
        <h4>Payment Status</h4>
        <p>${order.payment_status}</p>
      </div>
      <div class="payment-info-item">
        <h4>Order Status</h4>
        <p>${order.order_status}</p>
      </div>
    </div>
    
    <div class="footer">
      <p class="thank-you">Thank you for shopping with <span class="gold-accent">Blackzy Fashion!</span></p>
      <p>For any queries, please contact us at support@blackzy.com</p>
      <p>© ${new Date().getFullYear()} Blackzy Fashion. All rights reserved.</p>
    </div>
  </div>
  
  <script>window.onload = function() { window.print(); }</script>
</body>
</html>
    `;

    const printWindow = window.open("", "_blank");
    printWindow.document.write(invoiceHTML);
    printWindow.document.close();
  };

  return (
    <div className="min-h-screen bg-[#fafafa] flex items-center justify-center px-4 py-16">
      <div className="bg-white p-8 md:p-12 max-w-lg w-full text-center">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-10 h-10 text-green-600" />
        </div>
        
        <h1 className="font-display text-3xl md:text-4xl mb-4">Order Confirmed!</h1>
        <p className="text-gray-600 font-body mb-6">
          Thank you for your order. We've received your order and will begin processing it soon.
        </p>
        
        {orderNumber && (
          <div className="bg-[#faf8f5] p-4 mb-6">
            <p className="text-sm text-gray-500 font-body mb-1">Order Number</p>
            <p className="font-display text-xl text-[#d4a853]">{orderNumber}</p>
          </div>
        )}

        {phone && (
          <p className="text-sm text-gray-500 font-body mb-6">
            Use your phone number <strong>{phone}</strong> or order number to track your order anytime.
          </p>
        )}
        
        <div className="flex items-center justify-center gap-2 text-sm text-gray-500 font-body mb-8">
          <Package className="w-4 h-4" />
          <span>Estimated delivery: 3-5 business days</span>
        </div>
        
        <div className="space-y-3">
          {order && (
            <Button 
              onClick={downloadInvoice}
              className="w-full bg-[#0a0a0a] hover:bg-gray-800 text-white rounded-none py-5"
            >
              <FileText className="w-4 h-4 mr-2" />
              Download Invoice
            </Button>
          )}
          <Link to={createPageUrl("TrackOrder") + (orderNumber ? `?search=${orderNumber}` : "")}>
            <Button className="w-full bg-[#d4a853] hover:bg-[#c49743] text-black rounded-none py-5">
              Track Your Order
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
          <Link to={createPageUrl("Home")}>
            <Button variant="outline" className="w-full rounded-none py-5 border-[#0a0a0a]">
              <Home className="w-4 h-4 mr-2" />
              Continue Shopping
            </Button>
          </Link>
        </div>
        
        <p className="text-xs text-gray-400 font-body mt-8">
          Save your order number to track your delivery status.
        </p>
      </div>
    </div>
  );
}