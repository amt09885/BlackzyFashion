import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Ruler, Info } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function SizeGuide() {
  const [activeTab, setActiveTab] = useState("saree");

  const { data: siteSettings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const settings = await base44.entities.SiteSettings.filter({ key: "main" });
      return settings[0] || null;
    },
    staleTime: 2 * 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const settings = siteSettings || {
    whatsapp_number: "8801XXXXXXXXX",
    size_guide_saree_note: "All our sarees come with an unstitched blouse piece. Please visit a local tailor for blouse stitching.",
    size_guide_fabric_note: "Fabric width is typically 44 inches (112 cm) unless otherwise specified in the product description.",
    size_guide_help_text: "Not sure about your size? Our team is here to help you find the perfect fit."
  };

  return (
    <div className="min-h-screen bg-[#fafafa]">
      <div className="bg-[#0a0a0a] py-16 px-4">
        <div className="max-w-4xl mx-auto text-center text-white">
          <Ruler className="w-12 h-12 mx-auto mb-4 text-[#d4a853]" />
          <h1 className="font-display text-4xl md:text-5xl mb-4">Size Guide</h1>
          <p className="text-gray-400 font-body">Find your perfect fit</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full bg-white mb-8 p-1 h-auto flex-wrap">
            <TabsTrigger value="saree" className="flex-1 py-3 rounded-none data-[state=active]:bg-[#0a0a0a] data-[state=active]:text-white">
              Saree
            </TabsTrigger>
            <TabsTrigger value="threepiece" className="flex-1 py-3 rounded-none data-[state=active]:bg-[#0a0a0a] data-[state=active]:text-white">
              Three Piece
            </TabsTrigger>
            <TabsTrigger value="kurti" className="flex-1 py-3 rounded-none data-[state=active]:bg-[#0a0a0a] data-[state=active]:text-white">
              Kurti
            </TabsTrigger>
            <TabsTrigger value="fabric" className="flex-1 py-3 rounded-none data-[state=active]:bg-[#0a0a0a] data-[state=active]:text-white">
              Fabric
            </TabsTrigger>
          </TabsList>

          <TabsContent value="saree" className="bg-white p-8">
            <h2 className="font-display text-2xl mb-6">Saree Length Guide</h2>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse font-body">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="border p-3 text-left">Size</th>
                    <th className="border p-3 text-left">Length</th>
                    <th className="border p-3 text-left">Blouse Piece</th>
                    <th className="border p-3 text-left">Best For</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border p-3">Standard</td>
                    <td className="border p-3">5.5 meters</td>
                    <td className="border p-3">0.8 meters</td>
                    <td className="border p-3">Regular height (5'2" - 5'6")</td>
                  </tr>
                  <tr>
                    <td className="border p-3">Long</td>
                    <td className="border p-3">6 meters</td>
                    <td className="border p-3">0.8 meters</td>
                    <td className="border p-3">Taller women (5'7"+)</td>
                  </tr>
                  <tr>
                    <td className="border p-3">Half Saree</td>
                    <td className="border p-3">4.5 meters</td>
                    <td className="border p-3">Not included</td>
                    <td className="border p-3">Petite women, pre-draped</td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <div className="mt-6 p-4 bg-amber-50 border border-amber-200 flex gap-3">
              <Info className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <p className="text-amber-800 font-body text-sm">
                {settings.size_guide_saree_note}
              </p>
            </div>
          </TabsContent>

          <TabsContent value="threepiece" className="bg-white p-8">
            <h2 className="font-display text-2xl mb-6">Three Piece Size Chart</h2>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse font-body">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="border p-3 text-left">Size</th>
                    <th className="border p-3 text-left">Bust (inches)</th>
                    <th className="border p-3 text-left">Waist (inches)</th>
                    <th className="border p-3 text-left">Hip (inches)</th>
                    <th className="border p-3 text-left">Length (inches)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border p-3">S</td>
                    <td className="border p-3">32-34</td>
                    <td className="border p-3">26-28</td>
                    <td className="border p-3">34-36</td>
                    <td className="border p-3">38</td>
                  </tr>
                  <tr>
                    <td className="border p-3">M</td>
                    <td className="border p-3">34-36</td>
                    <td className="border p-3">28-30</td>
                    <td className="border p-3">36-38</td>
                    <td className="border p-3">40</td>
                  </tr>
                  <tr>
                    <td className="border p-3">L</td>
                    <td className="border p-3">36-38</td>
                    <td className="border p-3">30-32</td>
                    <td className="border p-3">38-40</td>
                    <td className="border p-3">42</td>
                  </tr>
                  <tr>
                    <td className="border p-3">XL</td>
                    <td className="border p-3">38-40</td>
                    <td className="border p-3">32-34</td>
                    <td className="border p-3">40-42</td>
                    <td className="border p-3">44</td>
                  </tr>
                  <tr>
                    <td className="border p-3">XXL</td>
                    <td className="border p-3">40-42</td>
                    <td className="border p-3">34-36</td>
                    <td className="border p-3">42-44</td>
                    <td className="border p-3">46</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </TabsContent>

          <TabsContent value="kurti" className="bg-white p-8">
            <h2 className="font-display text-2xl mb-6">Kurti Size Chart</h2>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse font-body">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="border p-3 text-left">Size</th>
                    <th className="border p-3 text-left">Bust (inches)</th>
                    <th className="border p-3 text-left">Shoulder (inches)</th>
                    <th className="border p-3 text-left">Length (inches)</th>
                    <th className="border p-3 text-left">Sleeve (inches)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border p-3">S</td>
                    <td className="border p-3">34</td>
                    <td className="border p-3">14</td>
                    <td className="border p-3">42</td>
                    <td className="border p-3">18</td>
                  </tr>
                  <tr>
                    <td className="border p-3">M</td>
                    <td className="border p-3">36</td>
                    <td className="border p-3">14.5</td>
                    <td className="border p-3">43</td>
                    <td className="border p-3">18.5</td>
                  </tr>
                  <tr>
                    <td className="border p-3">L</td>
                    <td className="border p-3">38</td>
                    <td className="border p-3">15</td>
                    <td className="border p-3">44</td>
                    <td className="border p-3">19</td>
                  </tr>
                  <tr>
                    <td className="border p-3">XL</td>
                    <td className="border p-3">40</td>
                    <td className="border p-3">15.5</td>
                    <td className="border p-3">45</td>
                    <td className="border p-3">19.5</td>
                  </tr>
                  <tr>
                    <td className="border p-3">XXL</td>
                    <td className="border p-3">42</td>
                    <td className="border p-3">16</td>
                    <td className="border p-3">46</td>
                    <td className="border p-3">20</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </TabsContent>

          <TabsContent value="fabric" className="bg-white p-8">
            <h2 className="font-display text-2xl mb-6">Fabric Length Guide</h2>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse font-body">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="border p-3 text-left">Size</th>
                    <th className="border p-3 text-left">Length</th>
                    <th className="border p-3 text-left">Width</th>
                    <th className="border p-3 text-left">Ideal For</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border p-3">2.5 Meters</td>
                    <td className="border p-3">2.5m</td>
                    <td className="border p-3">44 inches</td>
                    <td className="border p-3">Kurti, Short Tops</td>
                  </tr>
                  <tr>
                    <td className="border p-3">3 Meters</td>
                    <td className="border p-3">3m</td>
                    <td className="border p-3">44 inches</td>
                    <td className="border p-3">Long Kurti, Kameez</td>
                  </tr>
                  <tr>
                    <td className="border p-3">4.5 Meters</td>
                    <td className="border p-3">4.5m</td>
                    <td className="border p-3">44 inches</td>
                    <td className="border p-3">Salwar Kameez Set</td>
                  </tr>
                  <tr>
                    <td className="border p-3">5.5 Meters</td>
                    <td className="border p-3">5.5m</td>
                    <td className="border p-3">44 inches</td>
                    <td className="border p-3">Saree</td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <div className="mt-6 p-4 bg-blue-50 border border-blue-200 flex gap-3">
              <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <p className="text-blue-800 font-body text-sm">
                {settings.size_guide_fabric_note}
              </p>
            </div>
          </TabsContent>
        </Tabs>

        {/* How to Measure */}
        <div className="bg-white p-8 mt-8">
          <h2 className="font-display text-2xl mb-6">How to Measure</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-body">
            <div>
              <h3 className="font-semibold mb-2">Bust</h3>
              <p className="text-gray-600 text-sm">Measure around the fullest part of your bust, keeping the tape parallel to the ground.</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Waist</h3>
              <p className="text-gray-600 text-sm">Measure around your natural waistline, which is the narrowest part of your torso.</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Hip</h3>
              <p className="text-gray-600 text-sm">Measure around the fullest part of your hips, usually about 8 inches below your waist.</p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Length</h3>
              <p className="text-gray-600 text-sm">Measure from the highest point of your shoulder down to where you want the garment to end.</p>
            </div>
          </div>
        </div>

        {/* Help Section */}
        <div className="bg-[#0a0a0a] p-8 mt-8 text-center text-white">
          <h3 className="font-display text-2xl mb-3">Need Help?</h3>
          <p className="text-gray-400 font-body mb-6">
            {settings.size_guide_help_text}
          </p>
          <a 
            href={`https://wa.me/${settings.whatsapp_number}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-[#d4a853] text-black px-8 py-3 font-body font-medium hover:bg-[#c49743]"
          >
            Chat with us on WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
}