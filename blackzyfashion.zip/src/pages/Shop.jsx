import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "react-router-dom";
import ProductCard from "../components/products/ProductCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { 
  Search, SlidersHorizontal, Grid3X3, LayoutList, 
  X, Loader2
} from "lucide-react";

const fabricTypes = [
  { id: "ac_cotton", label: "AC Cotton" },
  { id: "block_print", label: "Block Print" },
  { id: "gojkapor", label: "Gojkapor" },
  { id: "silk", label: "Silk" },
  { id: "muslin", label: "Muslin" },
  { id: "cotton", label: "Cotton" },
  { id: "jamdani", label: "Jamdani" },
  { id: "tant", label: "Tant" },
  { id: "katan", label: "Katan" }
];

const collections = [
  { id: "summer", label: "Summer Collection" },
  { id: "eid", label: "Eid Collection" },
  { id: "puja", label: "Puja Collection" },
  { id: "new", label: "New Arrivals" }
];

export default function Shop() {
  const location = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("latest");
  const [viewMode, setViewMode] = useState("grid");
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);
  
  // Filters
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedFabrics, setSelectedFabrics] = useState([]);
  const [selectedCollections, setSelectedCollections] = useState([]);
  const [priceRange, setPriceRange] = useState([0, 10000]);
  const [inStock, setInStock] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const categoryParam = params.get("category");
    const fabricParam = params.get("fabric");
    const collectionParam = params.get("collection");
    
    // Reset filters first when URL changes
    setSelectedCategory(categoryParam || "");
    setSelectedFabrics(fabricParam ? [fabricParam] : []);
    setSelectedCollections(collectionParam ? [collectionParam] : []);
  }, [location.search]);

  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: () => base44.entities.Category.filter({ is_active: true }),
    staleTime: 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
  });

  const { data: allProducts = [], isLoading: loading } = useQuery({
    queryKey: ['all-products'],
    queryFn: () => base44.entities.Product.filter({ is_active: true }),
    staleTime: 2 * 60 * 60 * 1000,
    cacheTime: 4 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
  });

  const products = useMemo(() => {
    let filtered = [...allProducts];
    
    if (selectedCategory) {
      filtered = filtered.filter(p => p.category_id === selectedCategory);
    }
    
    if (selectedFabrics.length > 0) {
      filtered = filtered.filter(p => selectedFabrics.includes(p.fabric_type));
    }
    
    if (selectedCollections.length > 0) {
      filtered = filtered.filter(p => {
        if (selectedCollections.includes("new") && p.is_new_arrival) return true;
        if (p.collection && selectedCollections.includes(p.collection.toLowerCase())) return true;
        return false;
      });
    }
    
    filtered = filtered.filter(p => {
      const price = p.sale_price || p.price;
      return price >= priceRange[0] && price <= priceRange[1];
    });
    
    if (inStock) {
      filtered = filtered.filter(p => p.stock_quantity > 0);
    }
    
    // Apply search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(p => 
        p.name?.toLowerCase().includes(query) ||
        p.description?.toLowerCase().includes(query) ||
        p.fabric_type?.toLowerCase().includes(query)
      );
    }
    
    // Apply sorting
    switch (sortBy) {
      case "price_low":
        filtered.sort((a, b) => (a.sale_price || a.price) - (b.sale_price || b.price));
        break;
      case "price_high":
        filtered.sort((a, b) => (b.sale_price || b.price) - (a.sale_price || a.price));
        break;
      case "popular":
        filtered.sort((a, b) => (b.sold_count || 0) - (a.sold_count || 0));
        break;
      case "rating":
        filtered.sort((a, b) => (b.average_rating || 0) - (a.average_rating || 0));
        break;
      default:
        filtered.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    }
    
    return filtered;
  }, [allProducts, selectedCategory, selectedFabrics, selectedCollections, priceRange, inStock, searchQuery, sortBy]);

  const toggleFabric = (fabricId) => {
    setSelectedFabrics(prev => 
      prev.includes(fabricId)
        ? prev.filter(f => f !== fabricId)
        : [...prev, fabricId]
    );
  };

  const toggleCollection = (collectionId) => {
    setSelectedCollections(prev => 
      prev.includes(collectionId)
        ? prev.filter(c => c !== collectionId)
        : [...prev, collectionId]
    );
  };

  const clearFilters = () => {
    setSelectedCategory("");
    setSelectedFabrics([]);
    setSelectedCollections([]);
    setPriceRange([0, 10000]);
    setInStock(false);
    setSearchQuery("");
  };

  const activeFilterCount = 
    (selectedCategory ? 1 : 0) + 
    selectedFabrics.length + 
    selectedCollections.length +
    (inStock ? 1 : 0);

  const FilterSidebar = () => (
    <div className="space-y-8">
      {/* Categories */}
      <div>
        <h3 className="font-display text-lg mb-4">Categories</h3>
        <div className="space-y-2">
          <button
            onClick={() => setSelectedCategory("")}
            className={`block w-full text-left py-2 px-3 text-sm font-body transition-colors ${
              !selectedCategory ? "bg-[#0a0a0a] text-white" : "hover:bg-gray-100"
            }`}
          >
            All Categories
          </button>
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`block w-full text-left py-2 px-3 text-sm font-body transition-colors ${
                selectedCategory === cat.id ? "bg-[#0a0a0a] text-white" : "hover:bg-gray-100"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Fabric Type */}
      <div>
        <h3 className="font-display text-lg mb-4">Fabric Type</h3>
        <div className="space-y-3">
          {fabricTypes.map(fabric => (
            <div key={fabric.id} className="flex items-center gap-3">
              <Checkbox
                id={fabric.id}
                checked={selectedFabrics.includes(fabric.id)}
                onCheckedChange={() => toggleFabric(fabric.id)}
              />
              <Label 
                htmlFor={fabric.id} 
                className="text-sm font-body cursor-pointer"
              >
                {fabric.label}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {/* Collections */}
      <div>
        <h3 className="font-display text-lg mb-4">Collections</h3>
        <div className="space-y-3">
          {collections.map(col => (
            <div key={col.id} className="flex items-center gap-3">
              <Checkbox
                id={col.id}
                checked={selectedCollections.includes(col.id)}
                onCheckedChange={() => toggleCollection(col.id)}
              />
              <Label 
                htmlFor={col.id} 
                className="text-sm font-body cursor-pointer"
              >
                {col.label}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {/* Price Range */}
      <div>
        <h3 className="font-display text-lg mb-4">Price Range</h3>
        <div className="px-2">
          <Slider
            value={priceRange}
            onValueChange={setPriceRange}
            max={10000}
            step={100}
            className="mb-4"
          />
          <div className="flex justify-between text-sm font-body text-gray-600">
            <span>৳{priceRange[0].toLocaleString()}</span>
            <span>৳{priceRange[1].toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* In Stock */}
      <div className="flex items-center gap-3">
        <Checkbox
          id="in-stock"
          checked={inStock}
          onCheckedChange={setInStock}
        />
        <Label htmlFor="in-stock" className="text-sm font-body cursor-pointer">
          In Stock Only
        </Label>
      </div>

      {/* Clear Filters */}
      {activeFilterCount > 0 && (
        <Button
          variant="outline"
          onClick={clearFilters}
          className="w-full rounded-none border-[#0a0a0a]"
        >
          Clear All Filters ({activeFilterCount})
        </Button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-[#fafafa]">
      {/* Page Header */}
      <div className="bg-[#0a0a0a] py-16 px-4">
        <div className="max-w-7xl mx-auto text-center text-white">
          <h1 className="font-display text-4xl md:text-5xl mb-4">Shop</h1>
          <p className="text-gray-400 font-body">
            Discover our curated collection of premium Bengali fabrics
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Search and Controls */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 h-12 rounded-none border-gray-200 focus:border-[#d4a853]"
            />
          </div>

          {/* Mobile Filter Button */}
          <Sheet open={mobileFilterOpen} onOpenChange={setMobileFilterOpen}>
            <SheetTrigger asChild>
              <Button 
                variant="outline" 
                className="md:hidden rounded-none border-[#0a0a0a] gap-2"
              >
                <SlidersHorizontal className="w-4 h-4" />
                Filters
                {activeFilterCount > 0 && (
                  <span className="ml-1 bg-[#d4a853] text-black w-5 h-5 rounded-full text-xs flex items-center justify-center">
                    {activeFilterCount}
                  </span>
                )}
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80 overflow-y-auto">
              <SheetHeader>
                <SheetTitle>Filters</SheetTitle>
              </SheetHeader>
              <div className="mt-6">
                <FilterSidebar />
              </div>
            </SheetContent>
          </Sheet>

          {/* Sort */}
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-full md:w-48 h-12 rounded-none">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="latest">Latest</SelectItem>
              <SelectItem value="price_low">Price: Low to High</SelectItem>
              <SelectItem value="price_high">Price: High to Low</SelectItem>
              <SelectItem value="popular">Most Popular</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
            </SelectContent>
          </Select>

          {/* View Mode */}
          <div className="hidden md:flex border border-gray-200">
            <button
              onClick={() => setViewMode("grid")}
              className={`p-3 ${viewMode === "grid" ? "bg-[#0a0a0a] text-white" : "bg-white"}`}
            >
              <Grid3X3 className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`p-3 ${viewMode === "list" ? "bg-[#0a0a0a] text-white" : "bg-white"}`}
            >
              <LayoutList className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex gap-8">
          {/* Desktop Sidebar */}
          <aside className="hidden md:block w-64 flex-shrink-0">
            <FilterSidebar />
          </aside>

          {/* Products Grid */}
          <main className="flex-1">
            {/* Active Filters */}
            {activeFilterCount > 0 && (
              <div className="flex flex-wrap gap-2 mb-6">
                {selectedFabrics.map(f => (
                  <span 
                    key={f}
                    className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 text-sm font-body"
                  >
                    {fabricTypes.find(ft => ft.id === f)?.label}
                    <button onClick={() => toggleFabric(f)}>
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
                {selectedCollections.map(c => (
                  <span 
                    key={c}
                    className="inline-flex items-center gap-1 px-3 py-1 bg-gray-100 text-sm font-body"
                  >
                    {collections.find(col => col.id === c)?.label}
                    <button onClick={() => toggleCollection(c)}>
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}

            {/* Results Count */}
            <p className="text-sm text-gray-500 font-body mb-6">
              Showing {products.length} products
            </p>

            {loading ? (
              <div className="flex items-center justify-center h-96">
                <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
              </div>
            ) : products.length > 0 ? (
              <div className={`grid gap-6 ${
                viewMode === "grid" 
                  ? "grid-cols-2 lg:grid-cols-3" 
                  : "grid-cols-1"
              }`}>
                {products.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 bg-white">
                <p className="text-gray-500 font-body mb-4">
                  No products found matching your criteria.
                </p>
                <Button
                  variant="outline"
                  onClick={clearFilters}
                  className="rounded-none"
                >
                  Clear Filters
                </Button>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}