import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { 
  ArrowLeft, Loader2, Truck, Shield, CreditCard, Wallet, Copy
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { useQuery } from "@tanstack/react-query";

export default function QuickCheckout() {
  const [loading, setLoading] = useState(true);
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState("");
  const [selectedColor, setSelectedColor] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    full_name: "",
    phone: "",
    email: "",
    address_line1: "",
    address_line2: "",
    city: "",
    district: "",
    delivery_area: "inside_dhaka",
    payment_method: "cod",
    transaction_id: "",
    notes: ""
  });

  const { data: siteSettings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const settings = await base44.entities.SiteSettings.filter({ key: "main" });
      return settings[0] || null;
    },
    staleTime: 2 * 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const settings = siteSettings || {};
  
  const paymentSettings = {
    bkash_number: settings.bkash_number || "01923931102",
    nagad_number: settings.nagad_number || "01923931102",
    rocket_number: settings.rocket_number || "01923931102",
    upay_number: settings.upay_number || "01923931102",
    ific_bank_account: settings.ific_bank_account || "0210331357811",
    ific_bank_name: settings.ific_bank_name || "MD SIAM",
    ific_bank_branch: settings.ific_bank_branch || "Malibag Mur Uposhakha",
    dbbl_agent_account: settings.dbbl_agent_account || "7017341850529",
    dbbl_agent_name: settings.dbbl_agent_name || "Md Siam",
    dbbl_account: settings.dbbl_account || "1091580152138",
    dbbl_name: settings.dbbl_name || "MD SIAM",
    dbbl_branch: settings.dbbl_branch || "BaburHat Branch",
    ucb_account: settings.ucb_account || "1702113000003860",
    ucb_name: settings.ucb_name || "MD SIAM",
    ucb_branch: settings.ucb_branch || "Danga Bazar Branch",
    bkash_enabled: settings.bkash_enabled !== false,
    nagad_enabled: settings.nagad_enabled !== false,
    rocket_enabled: settings.rocket_enabled !== false,
    upay_enabled: settings.upay_enabled !== false,
    ific_enabled: settings.ific_enabled !== false,
    dbbl_agent_enabled: settings.dbbl_agent_enabled !== false,
    dbbl_enabled: settings.dbbl_enabled !== false,
    ucb_enabled: settings.ucb_enabled !== false,
    cod_enabled: settings.cod_enabled !== false
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Number copied!" });
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const productId = params.get("product");
    const qty = params.get("qty");
    const size = params.get("size");
    const color = params.get("color");

    if (qty) setQuantity(parseInt(qty) || 1);
    if (size) setSelectedSize(size);
    if (color) setSelectedColor(color);

    if (productId) {
      loadProduct(productId);
    } else {
      setLoading(false);
    }
  }, []);

  const loadProduct = async (id) => {
    try {
      const products = await base44.entities.Product.filter({ id });
      if (products.length > 0) {
        setProduct(products[0]);
        if (!selectedSize && products[0].sizes?.length > 0) {
          setSelectedSize(products[0].sizes[0]);
        }
        if (!selectedColor && products[0].colors?.length > 0) {
          setSelectedColor(products[0].colors[0]);
        }
      }
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    if (!formData.full_name || !formData.phone || !formData.address_line1 || !formData.city || !formData.district) {
      toast({ title: "Please fill all required fields", variant: "destructive" });
      return false;
    }
    if (!/^01[3-9]\d{8}$/.test(formData.phone)) {
      toast({ title: "Please enter a valid phone number", variant: "destructive" });
      return false;
    }
    const onlinePaymentMethods = ["bkash", "nagad", "rocket", "upay", "ific", "dbbl_agent", "dbbl", "ucb"];
    if (onlinePaymentMethods.includes(formData.payment_method) && !formData.transaction_id) {
      toast({ title: "Please enter transaction/reference ID", variant: "destructive" });
      return false;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setSubmitting(true);
    try {
      const price = product.sale_price || product.price;
      const subtotal = price * quantity;
      const freeShippingThreshold = settings.free_shipping_threshold || 2000;
      const isFreeShipping = subtotal >= freeShippingThreshold;
      const insideDhakaCost = parseInt(settings.shipping_inside_dhaka_cost) || 60;
      const outsideDhakaCost = parseInt(settings.shipping_outside_dhaka_cost) || 120;
      const shippingCost = isFreeShipping ? 0 : 
        (formData.delivery_area === "inside_dhaka" ? insideDhakaCost : outsideDhakaCost);
      const total = subtotal + shippingCost;

      const orderNumber = `BF${Date.now().toString().slice(-8)}`;

      const orderData = {
        order_number: orderNumber,
        customer_email: formData.email || "",
        customer_name: formData.full_name,
        customer_phone: formData.phone,
        shipping_address: {
          full_name: formData.full_name,
          phone: formData.phone,
          address_line1: formData.address_line1,
          address_line2: formData.address_line2,
          city: formData.city,
          district: formData.district
        },
        items: [{
          product_id: product.id,
          product_name: product.name,
          product_image: product.images?.[0] || "",
          quantity: quantity,
          price: price,
          size: selectedSize,
          color: selectedColor
        }],
        subtotal,
        shipping_cost: shippingCost,
        discount_amount: 0,
        total,
        payment_method: formData.payment_method,
        transaction_id: formData.transaction_id || "",
        payment_status: formData.payment_method === "cod" ? "pending" : "pending",
        order_status: "pending",
        notes: formData.notes
      };

      await base44.entities.Order.create(orderData);

      // Redirect to success page
      window.location.href = createPageUrl("OrderSuccess") + `?order=${orderNumber}&phone=${formData.phone}`;

    } catch (e) {
      toast({ title: "Error placing order", variant: "destructive" });
    }
    setSubmitting(false);
  };

  const price = product?.sale_price || product?.price || 0;
  const subtotal = price * quantity;
  const freeShippingThreshold = settings.free_shipping_threshold || 2000;
  const isFreeShipping = subtotal >= freeShippingThreshold;
  const insideDhakaCost = parseInt(settings.shipping_inside_dhaka_cost) || 60;
  const outsideDhakaCost = parseInt(settings.shipping_outside_dhaka_cost) || 120;
  const shippingCost = isFreeShipping ? 0 : 
    (formData.delivery_area === "inside_dhaka" ? insideDhakaCost : outsideDhakaCost);
  const total = subtotal + shippingCost;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h1 className="font-display text-2xl mb-4">Product Not Found</h1>
        <Link to={createPageUrl("Shop")}>
          <Button className="rounded-none bg-[#0a0a0a]">Back to Shop</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#fafafa]">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <Link 
            to={createPageUrl("ProductDetail") + `?id=${product.id}`}
            className="flex items-center gap-2 text-gray-600 hover:text-[#0a0a0a] font-body text-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Product
          </Link>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <h1 className="font-display text-3xl mb-8 text-center">Quick Checkout</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Shipping Info */}
            <div className="bg-white p-6 shadow-sm">
              <h2 className="font-body text-lg font-semibold mb-6 flex items-center gap-2">
                <Truck className="w-5 h-5 text-[#d4a853]" />
                Shipping Information
              </h2>

              {/* Order Notes - Moved under title */}
              <div className="mb-6">
                <Label className="font-body text-sm font-medium">How much fabric do you need? (Note)</Label>
                <Textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleInputChange}
                  className="mt-2 rounded-none"
                  placeholder="E.g., 5 meters, 3 pieces, etc."
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="font-body text-sm font-medium">Full Name *</Label>
                  <Input
                    name="full_name"
                    value={formData.full_name}
                    onChange={handleInputChange}
                    className="mt-1 rounded-none"
                    placeholder="Your full name"
                  />
                </div>
                <div>
                  <Label>Phone Number *</Label>
                  <Input
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="mt-1 rounded-none"
                    placeholder="01XXXXXXXXX"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label>Email (Optional - for order updates)</Label>
                  <Input
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="mt-1 rounded-none"
                    placeholder="your@email.com"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label>Address *</Label>
                  <Input
                    name="address_line1"
                    value={formData.address_line1}
                    onChange={handleInputChange}
                    className="mt-1 rounded-none"
                    placeholder="House no, Road, Area"
                  />
                </div>
                <div className="md:col-span-2">
                  <Label>Address Line 2 (Optional)</Label>
                  <Input
                    name="address_line2"
                    value={formData.address_line2}
                    onChange={handleInputChange}
                    className="mt-1 rounded-none"
                    placeholder="Landmark, etc."
                  />
                </div>
                <div>
                  <Label className="font-body text-sm font-medium">Upazila/City *</Label>
                  <Input
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                    className="mt-1 rounded-none"
                    placeholder="Upazila/City"
                  />
                </div>
                <div>
                  <Label>District *</Label>
                  <Input
                    name="district"
                    value={formData.district}
                    onChange={handleInputChange}
                    className="mt-1 rounded-none"
                    placeholder="Dhaka"
                  />
                </div>
              </div>

              {/* Delivery Area Selection */}
              <div className="mt-6 pt-6 border-t">
                <Label className="font-body text-sm font-medium mb-3 block">Delivery Area *</Label>
                <RadioGroup 
                  value={formData.delivery_area} 
                  onValueChange={(v) => setFormData(prev => ({ ...prev, delivery_area: v }))}
                  className="space-y-3"
                >
                  <label className={`flex items-center justify-between p-4 border-2 rounded cursor-pointer ${
                    formData.delivery_area === "inside_dhaka" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200 hover:border-gray-300"
                  }`}>
                    <div className="flex items-center gap-3">
                      <RadioGroupItem value="inside_dhaka" id="inside_dhaka" />
                      <div>
                        <p className="font-medium font-body">Inside Dhaka</p>
                        <p className="text-xs text-gray-500">Delivery within Dhaka city</p>
                      </div>
                    </div>
                    <span className={`font-body font-semibold ${isFreeShipping ? "text-green-600" : "text-gray-700"}`}>
                      {isFreeShipping ? "FREE" : `৳${insideDhakaCost}`}
                    </span>
                  </label>

                  <label className={`flex items-center justify-between p-4 border-2 rounded cursor-pointer ${
                    formData.delivery_area === "outside_dhaka" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200 hover:border-gray-300"
                  }`}>
                    <div className="flex items-center gap-3">
                      <RadioGroupItem value="outside_dhaka" id="outside_dhaka" />
                      <div>
                        <p className="font-medium font-body">Outside Dhaka</p>
                        <p className="text-xs text-gray-500">Delivery outside Dhaka city</p>
                      </div>
                    </div>
                    <span className={`font-body font-semibold ${isFreeShipping ? "text-green-600" : "text-gray-700"}`}>
                      {isFreeShipping ? "FREE" : `৳${outsideDhakaCost}`}
                    </span>
                  </label>
                </RadioGroup>
              </div>
            </div>

            {/* Payment */}
            <div className="bg-white p-6 shadow-sm">
              <h2 className="font-display text-xl mb-6 flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-[#d4a853]" />
                Payment Method
              </h2>

              <RadioGroup 
                value={formData.payment_method} 
                onValueChange={(v) => {
                  setFormData(prev => ({ ...prev, payment_method: v, transaction_id: "" }));
                }}
                className="space-y-3"
              >
                {paymentSettings.cod_enabled && (
                  <label className={`flex items-center justify-between p-4 border-2 cursor-pointer ${
                    formData.payment_method === "cod" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200 hover:border-gray-300"
                  }`}>
                    <div className="flex items-center gap-4">
                      <RadioGroupItem value="cod" id="cod-quick" />
                      <Wallet className="w-8 h-8 text-gray-600" />
                      <div>
                        <p className="font-medium font-body">Cash on Delivery</p>
                        <p className="text-xs text-gray-500">Pay when you receive</p>
                      </div>
                    </div>
                    <span className="font-bold text-lg">৳{total.toLocaleString()}</span>
                  </label>
                )}

                {paymentSettings.bkash_enabled && (
                  <div className={`border-2 ${
                    formData.payment_method === "bkash" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"
                  }`}>
                    <label className="flex items-center justify-between p-4 cursor-pointer">
                      <div className="flex items-center gap-4">
                        <RadioGroupItem value="bkash" id="bkash-quick" />
                        <img src="https://www.logo.wine/a/logo/BKash/BKash-Icon-Logo.wine.svg" alt="bKash" className="h-12 object-contain" />
                        <div>
                          <p className="font-medium font-body text-base">bKash</p>
                          <p className="text-xs text-gray-500">Personal/Agent</p>
                        </div>
                      </div>
                      <span className="font-bold text-xl text-[#E2136E]">৳{total.toLocaleString()}</span>
                    </label>
                    {formData.payment_method === "bkash" && (
                      <div className="px-4 pb-4 pt-2 border-t border-[#d4a853]/20 bg-[#E2136E]/5">
                        <div className="text-sm space-y-2 mb-4 text-gray-700">
                          <p className="font-semibold">📱 How to Pay:</p>
                          <ol className="list-decimal list-inside text-xs space-y-1 ml-2">
                            <li>Open bKash app</li>
                            <li>Select "Send Money"</li>
                            <li>Enter number: <strong className="text-[#E2136E]">{paymentSettings.bkash_number}</strong></li>
                            <li>Amount: <strong>৳{total.toLocaleString()}</strong></li>
                            <li>Complete payment & copy Transaction ID</li>
                          </ol>
                        </div>
                        <div className="p-3 bg-white rounded border border-[#E2136E]/20 mb-3">
                          <div className="flex items-center justify-between">
                            <span className="font-mono font-bold text-base text-[#E2136E]">{paymentSettings.bkash_number}</span>
                            <Button 
                              type="button"
                              variant="ghost" 
                              size="sm"
                              onClick={() => copyToClipboard(paymentSettings.bkash_number)}
                              className="text-[#E2136E] hover:bg-[#E2136E]/10"
                            >
                              <Copy className="w-4 h-4 mr-1" /> Copy
                            </Button>
                          </div>
                        </div>
                        <div>
                          <Label className="font-body text-sm">Transaction ID *</Label>
                          <Input
                            name="transaction_id"
                            value={formData.transaction_id}
                            onChange={handleInputChange}
                            className="rounded-none mt-1"
                            placeholder="e.g., 8AH9K9I6J2"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {paymentSettings.nagad_enabled && (
                  <div className={`border-2 ${
                    formData.payment_method === "nagad" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"
                  }`}>
                    <label className="flex items-center justify-between p-4 cursor-pointer">
                      <div className="flex items-center gap-4">
                        <RadioGroupItem value="nagad" id="nagad-quick" />
                        <img src="https://download.logo.wine/logo/Nagad/Nagad-Logo.wine.png" alt="Nagad" className="h-12 object-contain" />
                        <div>
                          <p className="font-medium font-body text-base">Nagad</p>
                          <p className="text-xs text-gray-500">Personal</p>
                        </div>
                      </div>
                      <span className="font-bold text-xl text-[#F6921E]">৳{total.toLocaleString()}</span>
                    </label>
                    {formData.payment_method === "nagad" && (
                      <div className="px-4 pb-4 pt-2 border-t border-[#d4a853]/20 bg-[#F6921E]/5">
                        <div className="text-sm space-y-2 mb-4 text-gray-700">
                          <p className="font-semibold">📱 How to Pay:</p>
                          <ol className="list-decimal list-inside text-xs space-y-1 ml-2">
                            <li>Open Nagad app</li>
                            <li>Select "Send Money"</li>
                            <li>Enter number: <strong className="text-[#F6921E]">{paymentSettings.nagad_number}</strong></li>
                            <li>Amount: <strong>৳{total.toLocaleString()}</strong></li>
                            <li>Complete payment & copy Transaction ID</li>
                          </ol>
                        </div>
                        <div className="p-3 bg-white rounded border border-[#F6921E]/20 mb-3">
                          <div className="flex items-center justify-between">
                            <span className="font-mono font-bold text-base text-[#F6921E]">{paymentSettings.nagad_number}</span>
                            <Button 
                              type="button"
                              variant="ghost" 
                              size="sm"
                              onClick={() => copyToClipboard(paymentSettings.nagad_number)}
                              className="text-[#F6921E] hover:bg-[#F6921E]/10"
                            >
                              <Copy className="w-4 h-4 mr-1" /> Copy
                            </Button>
                          </div>
                        </div>
                        <div>
                          <Label className="font-body text-sm">Transaction ID *</Label>
                          <Input
                            name="transaction_id"
                            value={formData.transaction_id}
                            onChange={handleInputChange}
                            className="rounded-none mt-1"
                            placeholder="e.g., 7NH123456789"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {paymentSettings.rocket_enabled && (
                  <div className={`border-2 ${formData.payment_method === "rocket" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"}`}>
                    <label className="flex items-center justify-between p-4 cursor-pointer">
                      <div className="flex items-center gap-4">
                        <RadioGroupItem value="rocket" id="rocket-quick" />
                        <div className="w-12 h-12 bg-purple-100 rounded flex items-center justify-center">
                          <Wallet className="w-7 h-7 text-purple-600" />
                        </div>
                        <div>
                          <p className="font-medium font-body text-base">Rocket</p>
                          <p className="text-xs text-gray-500">{paymentSettings.rocket_number}</p>
                        </div>
                      </div>
                      <span className="font-bold text-xl text-purple-600">৳{total.toLocaleString()}</span>
                    </label>
                    {formData.payment_method === "rocket" && (
                      <div className="px-4 pb-4 pt-2 border-t bg-purple-50">
                        <p className="text-xs mb-2">Send Money • Enter Transaction ID</p>
                        <Input name="transaction_id" value={formData.transaction_id} onChange={handleInputChange} placeholder="Transaction ID" className="rounded-none" />
                      </div>
                    )}
                  </div>
                )}

                {paymentSettings.upay_enabled && (
                  <div className={`border-2 ${formData.payment_method === "upay" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"}`}>
                    <label className="flex items-center justify-between p-4 cursor-pointer">
                      <div className="flex items-center gap-4">
                        <RadioGroupItem value="upay" id="upay-quick" />
                        <div className="w-12 h-12 bg-red-100 rounded flex items-center justify-center">
                          <Wallet className="w-7 h-7 text-red-600" />
                        </div>
                        <div>
                          <p className="font-medium font-body text-base">Upay</p>
                          <p className="text-xs text-gray-500">{paymentSettings.upay_number}</p>
                        </div>
                      </div>
                      <span className="font-bold text-xl text-red-600">৳{total.toLocaleString()}</span>
                    </label>
                    {formData.payment_method === "upay" && (
                      <div className="px-4 pb-4 pt-2 border-t bg-red-50">
                        <p className="text-xs mb-2">Send Money • Enter Transaction ID</p>
                        <Input name="transaction_id" value={formData.transaction_id} onChange={handleInputChange} placeholder="Transaction ID" className="rounded-none" />
                      </div>
                    )}
                  </div>
                )}

                {paymentSettings.ific_enabled && (
                  <div className={`border-2 ${formData.payment_method === "ific" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"}`}>
                    <label className="flex items-center justify-between p-4 cursor-pointer">
                      <div className="flex items-center gap-4">
                        <RadioGroupItem value="ific" id="ific-quick" />
                        <CreditCard className="w-10 h-10 text-blue-600" />
                        <div>
                          <p className="font-medium font-body text-base">IFIC Bank</p>
                          <p className="text-xs text-gray-500">{paymentSettings.ific_bank_branch}</p>
                        </div>
                      </div>
                      <span className="font-bold text-xl text-blue-600">৳{total.toLocaleString()}</span>
                    </label>
                    {formData.payment_method === "ific" && (
                      <div className="px-4 pb-4 pt-2 border-t bg-blue-50">
                        <p className="text-xs mb-2"><strong>A/C: {paymentSettings.ific_bank_account}</strong><br/>Name: {paymentSettings.ific_bank_name}<br/>Branch: {paymentSettings.ific_bank_branch}</p>
                        <Input name="transaction_id" value={formData.transaction_id} onChange={handleInputChange} placeholder="Reference No." className="rounded-none" />
                      </div>
                    )}
                  </div>
                )}

                {paymentSettings.dbbl_agent_enabled && (
                  <div className={`border-2 ${formData.payment_method === "dbbl_agent" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"}`}>
                    <label className="flex items-center justify-between p-4 cursor-pointer">
                      <div className="flex items-center gap-4">
                        <RadioGroupItem value="dbbl_agent" id="dbbl-agent-quick" />
                        <CreditCard className="w-10 h-10 text-green-600" />
                        <div>
                          <p className="font-medium font-body text-base">DBBL Agent Banking</p>
                          <p className="text-xs text-gray-500">{paymentSettings.dbbl_agent_name}</p>
                        </div>
                      </div>
                      <span className="font-bold text-xl text-green-600">৳{total.toLocaleString()}</span>
                    </label>
                    {formData.payment_method === "dbbl_agent" && (
                      <div className="px-4 pb-4 pt-2 border-t bg-green-50">
                        <p className="text-xs mb-2"><strong>A/C: {paymentSettings.dbbl_agent_account}</strong><br/>Name: {paymentSettings.dbbl_agent_name}</p>
                        <Input name="transaction_id" value={formData.transaction_id} onChange={handleInputChange} placeholder="Reference No." className="rounded-none" />
                      </div>
                    )}
                  </div>
                )}

                {paymentSettings.dbbl_enabled && (
                  <div className={`border-2 ${formData.payment_method === "dbbl" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"}`}>
                    <label className="flex items-center justify-between p-4 cursor-pointer">
                      <div className="flex items-center gap-4">
                        <RadioGroupItem value="dbbl" id="dbbl-quick" />
                        <CreditCard className="w-10 h-10 text-teal-600" />
                        <div>
                          <p className="font-medium font-body text-base">Dutch Bangla Bank</p>
                          <p className="text-xs text-gray-500">{paymentSettings.dbbl_branch}</p>
                        </div>
                      </div>
                      <span className="font-bold text-xl text-teal-600">৳{total.toLocaleString()}</span>
                    </label>
                    {formData.payment_method === "dbbl" && (
                      <div className="px-4 pb-4 pt-2 border-t bg-teal-50">
                        <p className="text-xs mb-2"><strong>A/C: {paymentSettings.dbbl_account}</strong><br/>Name: {paymentSettings.dbbl_name}<br/>Branch: {paymentSettings.dbbl_branch}</p>
                        <Input name="transaction_id" value={formData.transaction_id} onChange={handleInputChange} placeholder="Reference No." className="rounded-none" />
                      </div>
                    )}
                  </div>
                )}

                {paymentSettings.ucb_enabled && (
                  <div className={`border-2 ${formData.payment_method === "ucb" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"}`}>
                    <label className="flex items-center justify-between p-4 cursor-pointer">
                      <div className="flex items-center gap-4">
                        <RadioGroupItem value="ucb" id="ucb-quick" />
                        <CreditCard className="w-10 h-10 text-indigo-600" />
                        <div>
                          <p className="font-medium font-body text-base">United Commercial Bank</p>
                          <p className="text-xs text-gray-500">{paymentSettings.ucb_branch}</p>
                        </div>
                      </div>
                      <span className="font-bold text-xl text-indigo-600">৳{total.toLocaleString()}</span>
                    </label>
                    {formData.payment_method === "ucb" && (
                      <div className="px-4 pb-4 pt-2 border-t bg-indigo-50">
                        <p className="text-xs mb-2"><strong>A/C: {paymentSettings.ucb_account}</strong><br/>Name: {paymentSettings.ucb_name}<br/>Branch: {paymentSettings.ucb_branch}</p>
                        <Input name="transaction_id" value={formData.transaction_id} onChange={handleInputChange} placeholder="Reference No." className="rounded-none" />
                      </div>
                    )}
                  </div>
                )}
              </RadioGroup>
            </div>


          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white p-6 shadow-sm sticky top-24">
              <h2 className="font-display text-xl mb-6">Order Summary</h2>

              {/* Product */}
              <div className="flex gap-4 pb-4 border-b">
                <div className="w-20 h-20 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                  <img 
                    src={product.images?.[0] || "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=200"}
                    alt={product.name}
                    loading="lazy"
                    decoding="async"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <h3 className="font-body font-medium text-sm">{product.name}</h3>
                  {selectedSize && <p className="text-xs text-gray-500">Size: {selectedSize}</p>}
                  {selectedColor && <p className="text-xs text-gray-500">Color: {selectedColor}</p>}
                  <p className="text-sm font-body mt-1">
                    ৳{price.toLocaleString()} × {quantity}
                  </p>
                  {/* Quantity Selector */}
                  <div className="flex items-center gap-2 mt-2">
                    <Label className="text-xs text-gray-500">Qty:</Label>
                    <div className="flex border border-gray-200">
                      <button
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="w-7 h-7 flex items-center justify-center hover:bg-gray-100 text-sm"
                      >
                        −
                      </button>
                      <span className="w-10 h-7 flex items-center justify-center border-x border-gray-200 text-sm font-medium">
                        {quantity}
                      </span>
                      <button
                        onClick={() => setQuantity(quantity + 1)}
                        className="w-7 h-7 flex items-center justify-center hover:bg-gray-100 text-sm"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Totals */}
              <div className="space-y-3 py-4 border-b">
                <div className="flex justify-between text-sm font-body">
                  <span>Subtotal</span>
                  <span>৳{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm font-body">
                  <span>Shipping</span>
                  <span className={shippingCost === 0 ? "text-green-600" : ""}>
                    {shippingCost === 0 ? "FREE" : `৳${shippingCost}`}
                  </span>
                </div>
              </div>

              <div className="flex justify-between py-4 text-xl">
                <span className="font-display">Total</span>
                <span className="font-body font-bold text-[#0a0a0a]">৳{total.toLocaleString()}</span>
              </div>

              <Button
                onClick={handleSubmit}
                disabled={submitting}
                className="w-full bg-[#d4a853] hover:bg-[#c49743] text-black rounded-none py-6 text-sm tracking-wider"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Processing...
                  </>
                ) : (
                  "PLACE ORDER"
                )}
              </Button>

              <div className="flex items-center justify-center gap-2 mt-4 text-xs text-gray-500 font-body">
                <Shield className="w-4 h-4" />
                <span>Secure & Safe Checkout</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}