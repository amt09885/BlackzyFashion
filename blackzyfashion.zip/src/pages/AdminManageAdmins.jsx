import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import AdminSidebar from "../components/admin/AdminSidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { Shield, Trash2, Loader2, UserPlus } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function AdminManageAdmins() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [admins, setAdmins] = useState([]);
  const [newAdminEmail, setNewAdminEmail] = useState("");
  const [adding, setAdding] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin();
        return;
      }
      const currentUser = await base44.auth.me();
      if (currentUser.role !== "admin") {
        window.location.href = "/";
        return;
      }
      setUser(currentUser);
      loadAdmins();
    } catch (e) {
      console.error(e);
      setLoading(false);
    }
  };

  const loadAdmins = async () => {
    try {
      const allUsers = await base44.entities.User.filter({ role: "admin" });
      setAdmins(allUsers);
    } catch (e) {
      toast({
        title: "Error loading admins",
        variant: "destructive",
      });
    }
    setLoading(false);
  };

  const handleAddAdmin = async (e) => {
    e.preventDefault();
    if (!newAdminEmail.trim()) return;

    setAdding(true);
    try {
      const existingUsers = await base44.entities.User.filter({ email: newAdminEmail.toLowerCase().trim() });
      
      if (existingUsers.length === 0) {
        toast({
          title: "User not found",
          description: "This email is not registered yet. User must sign up first.",
          variant: "destructive",
        });
        setAdding(false);
        return;
      }

      const targetUser = existingUsers[0];
      
      if (targetUser.role === "admin") {
        toast({
          title: "Already an admin",
          description: "This user is already an administrator.",
        });
        setAdding(false);
        return;
      }

      await base44.entities.User.update(targetUser.id, { role: "admin" });
      
      toast({
        title: "Admin added successfully",
        description: `${newAdminEmail} now has admin access.`,
      });
      
      setNewAdminEmail("");
      loadAdmins();
    } catch (e) {
      toast({
        title: "Error adding admin",
        description: e.message,
        variant: "destructive",
      });
    }
    setAdding(false);
  };

  const handleRemoveAdmin = async () => {
    if (!deleteConfirm) return;

    try {
      await base44.entities.User.update(deleteConfirm.id, { role: "user" });
      
      toast({
        title: "Admin removed",
        description: `${deleteConfirm.email} is no longer an admin.`,
      });
      
      setDeleteConfirm(null);
      loadAdmins();
    } catch (e) {
      toast({
        title: "Error removing admin",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        <AdminSidebar currentPage="Manage Admins" />
        
        <main className="flex-1 p-8">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-display font-bold mb-2">Manage Admins</h1>
              <p className="text-gray-600 font-body">Add or remove administrator access for users</p>
            </div>

            {/* Add Admin Form */}
            <div className="bg-white p-6 rounded-lg shadow-sm mb-8">
              <h2 className="text-xl font-display font-semibold mb-4 flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-[#d4a853]" />
                Add New Admin
              </h2>
              <form onSubmit={handleAddAdmin} className="flex gap-3">
                <Input
                  type="email"
                  placeholder="Enter user email address"
                  value={newAdminEmail}
                  onChange={(e) => setNewAdminEmail(e.target.value)}
                  className="flex-1"
                  required
                />
                <Button 
                  type="submit" 
                  disabled={adding}
                  className="bg-[#d4a853] hover:bg-[#c49743] text-black"
                >
                  {adding ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    "Add Admin"
                  )}
                </Button>
              </form>
              <p className="text-xs text-gray-500 mt-2 font-body">
                Note: User must be registered first. They will get admin access on next login.
              </p>
            </div>

            {/* Admin List */}
            <div className="bg-white rounded-lg shadow-sm">
              <div className="p-6 border-b">
                <h2 className="text-xl font-display font-semibold flex items-center gap-2">
                  <Shield className="w-5 h-5 text-[#d4a853]" />
                  Current Admins ({admins.length})
                </h2>
              </div>
              
              <div className="divide-y">
                {admins.length === 0 ? (
                  <div className="p-8 text-center text-gray-500 font-body">
                    No admins found
                  </div>
                ) : (
                  admins.map((admin) => (
                    <div key={admin.id} className="p-4 flex items-center justify-between hover:bg-gray-50">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-[#d4a853]/20 rounded-full flex items-center justify-center">
                          <Shield className="w-5 h-5 text-[#d4a853]" />
                        </div>
                        <div>
                          <p className="font-body font-medium">{admin.full_name || admin.email}</p>
                          <p className="text-sm text-gray-500 font-body">{admin.email}</p>
                        </div>
                      </div>
                      
                      {admin.email !== user?.email && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setDeleteConfirm(admin)}
                          className="text-red-500 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                      
                      {admin.email === user?.email && (
                        <span className="text-xs text-gray-500 font-body">You</span>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Admin Access</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove admin access from <strong>{deleteConfirm?.email}</strong>? 
              They will become a regular user.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleRemoveAdmin}
              className="bg-red-500 hover:bg-red-600"
            >
              Remove Admin
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}