import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Users, Search, Eye, Mail, Phone, MapPin,
  ShoppingBag, Menu, Loader2, Trash2
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import AdminSidebar from "../components/admin/AdminSidebar";
import { format } from "date-fns";

export default function AdminCustomers() {
  const [loading, setLoading] = useState(true);
  const [customers, setCustomers] = useState([]);
  const [orders, setOrders] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [showDialog, setShowDialog] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      
      const userData = await base44.auth.me();
      if (userData.role !== "admin") {
        window.location.href = createPageUrl("Home");
        return;
      }
      
      await loadData();
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const loadData = async () => {
    try {
      const [ordersData, usersData] = await Promise.all([
        base44.entities.Order.list("-created_date", 1000),
        base44.entities.User.list("-created_date", 500)
      ]);
      
      setOrders(ordersData);
      
      // Create customer list from orders and users
      const customerMap = new Map();
      
      // Add users first
      usersData.forEach(user => {
        customerMap.set(user.email, {
          email: user.email,
          name: user.full_name || user.email,
          phone: user.phone || "",
          created_date: user.created_date,
          orders: [],
          total_spent: 0,
          is_registered: true
        });
      });
      
      // Add order data
      ordersData.forEach(order => {
        const email = order.customer_email;
        if (customerMap.has(email)) {
          const customer = customerMap.get(email);
          customer.orders.push(order);
          customer.total_spent += order.total || 0;
          if (!customer.phone && order.customer_phone) {
            customer.phone = order.customer_phone;
          }
          if (customer.name === email && order.customer_name) {
            customer.name = order.customer_name;
          }
        } else {
          customerMap.set(email, {
            email: email,
            name: order.customer_name || email,
            phone: order.customer_phone || "",
            created_date: order.created_date,
            orders: [order],
            total_spent: order.total || 0,
            is_registered: false
          });
        }
      });
      
      setCustomers(Array.from(customerMap.values()));
    } catch (e) {
      console.error("Error loading customers:", e);
    }
  };

  const viewCustomer = (customer) => {
    setSelectedCustomer(customer);
    setShowDialog(true);
  };

  const deleteCustomer = async (customer) => {
    if (!confirm(`Are you sure you want to delete customer "${customer.name}" and all their ${customer.orders.length} orders? This cannot be undone.`)) return;
    
    try {
      // Delete all orders for this customer
      for (const order of customer.orders) {
        await base44.entities.Order.delete(order.id);
      }
      
      toast({ title: "Customer and their orders deleted successfully" });
      await loadData();
    } catch (e) {
      toast({ title: "Error deleting customer", variant: "destructive" });
    }
  };

  const filteredCustomers = customers.filter(c => {
    const query = searchQuery.toLowerCase();
    return (
      c.name?.toLowerCase().includes(query) ||
      c.email?.toLowerCase().includes(query) ||
      c.phone?.includes(query)
    );
  });

  // Sort by total spent descending
  filteredCustomers.sort((a, b) => b.total_spent - a.total_spent);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  const totalCustomers = customers.length;
  const registeredCustomers = customers.filter(c => c.is_registered).length;
  const repeatCustomers = customers.filter(c => c.orders.length > 1).length;

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar currentPage="AdminCustomers" />
      
      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b px-4 md:px-8 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <AdminSidebar mobile currentPage="AdminCustomers" />
                </SheetContent>
              </Sheet>
              <h1 className="text-xl font-bold">Customers</h1>
            </div>
          </div>
        </header>

        <main className="p-4 md:p-8">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Total Customers</p>
                    <p className="text-2xl font-bold">{totalCustomers}</p>
                  </div>
                  <Users className="w-8 h-8 text-[#d4a853]" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Registered Users</p>
                    <p className="text-2xl font-bold">{registeredCustomers}</p>
                  </div>
                  <Badge className="bg-green-100 text-green-800">Active</Badge>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Repeat Customers</p>
                    <p className="text-2xl font-bold">{repeatCustomers}</p>
                  </div>
                  <Badge className="bg-blue-100 text-blue-800">Loyal</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Search */}
          <div className="mb-6">
            <div className="relative max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search by name, email, or phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Customers Table */}
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Customer</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Orders</TableHead>
                    <TableHead>Total Spent</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCustomers.map((customer, index) => (
                    <TableRow key={customer.email}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-[#d4a853] rounded-full flex items-center justify-center text-black font-bold">
                            {customer.name?.charAt(0).toUpperCase() || "?"}
                          </div>
                          <div>
                            <p className="font-medium">{customer.name}</p>
                            <p className="text-xs text-gray-500">{customer.email}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {customer.phone && (
                          <p className="text-sm flex items-center gap-1">
                            <Phone className="w-3 h-3" /> {customer.phone}
                          </p>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{customer.orders.length} orders</Badge>
                      </TableCell>
                      <TableCell>
                        <p className="font-medium">৳{customer.total_spent.toLocaleString()}</p>
                      </TableCell>
                      <TableCell>
                        <Badge className={customer.is_registered ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                          {customer.is_registered ? "Registered" : "Guest"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => viewCustomer(customer)}>
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => deleteCustomer(customer)}>
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {filteredCustomers.length === 0 && (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500">No customers found</p>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>

      {/* Customer Details Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Customer Details</DialogTitle>
          </DialogHeader>

          {selectedCustomer && (
            <div className="space-y-6">
              {/* Customer Info */}
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 bg-[#d4a853] rounded-full flex items-center justify-center text-black text-2xl font-bold">
                  {selectedCustomer.name?.charAt(0).toUpperCase() || "?"}
                </div>
                <div>
                  <h3 className="text-xl font-bold">{selectedCustomer.name}</h3>
                  <p className="text-gray-500 flex items-center gap-2">
                    <Mail className="w-4 h-4" /> {selectedCustomer.email}
                  </p>
                  {selectedCustomer.phone && (
                    <p className="text-gray-500 flex items-center gap-2">
                      <Phone className="w-4 h-4" /> {selectedCustomer.phone}
                    </p>
                  )}
                  <Badge className={`mt-2 ${selectedCustomer.is_registered ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}`}>
                    {selectedCustomer.is_registered ? "Registered User" : "Guest Customer"}
                  </Badge>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <p className="text-2xl font-bold">{selectedCustomer.orders.length}</p>
                  <p className="text-sm text-gray-500">Total Orders</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <p className="text-2xl font-bold">৳{selectedCustomer.total_spent.toLocaleString()}</p>
                  <p className="text-sm text-gray-500">Total Spent</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <p className="text-2xl font-bold">
                    ৳{selectedCustomer.orders.length > 0 
                      ? Math.round(selectedCustomer.total_spent / selectedCustomer.orders.length).toLocaleString() 
                      : 0}
                  </p>
                  <p className="text-sm text-gray-500">Avg. Order</p>
                </div>
              </div>

              {/* Order History */}
              <div>
                <h4 className="font-medium mb-3 flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4" /> Order History
                </h4>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {selectedCustomer.orders.map((order) => (
                    <div key={order.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium">#{order.order_number}</p>
                        <p className="text-xs text-gray-500">
                          {format(new Date(order.created_date), "MMM d, yyyy")}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">৳{order.total?.toLocaleString()}</p>
                        <Badge className={
                          order.order_status === "delivered" ? "bg-green-100 text-green-800" :
                          order.order_status === "cancelled" ? "bg-red-100 text-red-800" :
                          "bg-yellow-100 text-yellow-800"
                        }>
                          {order.order_status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                  
                  {selectedCustomer.orders.length === 0 && (
                    <p className="text-center text-gray-500 py-4">No orders yet</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}