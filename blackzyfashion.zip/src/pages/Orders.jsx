import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Package, ChevronRight, Loader2, ShoppingBag,
  Clock, Truck, CheckCircle, XCircle
} from "lucide-react";
import { format } from "date-fns";


const statusConfig = {
  pending: { label: "Pending", color: "bg-yellow-100 text-yellow-800", icon: Clock },
  confirmed: { label: "Confirmed", color: "bg-blue-100 text-blue-800", icon: CheckCircle },
  processing: { label: "Processing", color: "bg-indigo-100 text-indigo-800", icon: Package },
  shipped: { label: "Shipped", color: "bg-purple-100 text-purple-800", icon: Truck },
  delivered: { label: "Delivered", color: "bg-green-100 text-green-800", icon: CheckCircle },
  cancelled: { label: "Cancelled", color: "bg-red-100 text-red-800", icon: XCircle }
};

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState(null);

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      
      const user = await base44.auth.me();
      const userOrders = await base44.entities.Order.filter(
        { customer_email: user.email },
        "-created_date"
      );
      setOrders(userOrders);
    } catch (e) {
      console.error("Error loading orders:", e);
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#fafafa]">
      {/* Header */}
      <div className="bg-[#0a0a0a] py-16 px-4">
        <div className="max-w-7xl mx-auto text-center text-white">
          <h1 className="font-display text-4xl md:text-5xl mb-4">My Orders</h1>
          <p className="text-gray-400 font-body">
            Track and manage your orders
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {orders.length > 0 ? (
          <div className="space-y-4">
            {orders.map((order, index) => {
              const status = statusConfig[order.order_status] || statusConfig.pending;
              const StatusIcon = status.icon;
              
              return (
                <div
                  key={order.id}
                  className="bg-white p-6"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-display text-lg">Order #{order.order_number}</h3>
                        <Badge className={`${status.color} rounded-none`}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {status.label}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-500 font-body">
                        Placed on {format(new Date(order.created_date), "MMM d, yyyy 'at' h:mm a")}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-display text-xl">৳{order.total?.toLocaleString()}</p>
                      <p className="text-sm text-gray-500 font-body">
                        {order.items?.length} {order.items?.length === 1 ? "item" : "items"}
                      </p>
                    </div>
                  </div>
                  
                  {/* Order Items Preview */}
                  <div className="flex gap-2 overflow-x-auto pb-2 mb-4">
                    {order.items?.slice(0, 4).map((item, i) => (
                      <div key={i} className="w-16 h-16 bg-gray-100 flex-shrink-0">
                        <img 
                          src={item.product_image || "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=100"}
                          alt={item.product_name}
                          loading="lazy"
                          decoding="async"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                    {order.items?.length > 4 && (
                      <div className="w-16 h-16 bg-gray-100 flex-shrink-0 flex items-center justify-center">
                        <span className="text-sm text-gray-500 font-body">
                          +{order.items.length - 4}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  {/* Shipping Address */}
                  <div className="text-sm text-gray-600 font-body mb-4">
                    <span className="font-medium">Shipping to: </span>
                    {order.shipping_address?.address_line1}, {order.shipping_address?.city}, {order.shipping_address?.district}
                  </div>
                  
                  {/* Actions */}
                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedOrder(selectedOrder?.id === order.id ? null : order)}
                      className="rounded-none"
                    >
                      {selectedOrder?.id === order.id ? "Hide Details" : "View Details"}
                      <ChevronRight className={`w-4 h-4 ml-1 transition-transform ${
                        selectedOrder?.id === order.id ? "rotate-90" : ""
                      }`} />
                    </Button>
                    {order.tracking_number && (
                      <Button size="sm" className="rounded-none bg-[#d4a853] text-black hover:bg-[#c49743]">
                        <Truck className="w-4 h-4 mr-1" />
                        Track
                      </Button>
                    )}
                  </div>
                  
                  {/* Expanded Details */}
                  {selectedOrder?.id === order.id && (
                    <div className="mt-6 pt-6 border-t">
                      <h4 className="font-display text-lg mb-4">Order Items</h4>
                      <div className="space-y-4">
                        {order.items?.map((item, i) => (
                          <div key={i} className="flex gap-4">
                            <div className="w-20 h-20 bg-gray-100 flex-shrink-0">
                              <img 
                                src={item.product_image || "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=100"}
                                alt={item.product_name}
                                loading="lazy"
                                decoding="async"
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="flex-1">
                              <p className="font-body font-medium">{item.product_name}</p>
                              <p className="text-sm text-gray-500 font-body">
                                {item.size && `Size: ${item.size}`} {item.color && `• Color: ${item.color}`}
                              </p>
                              <p className="text-sm font-body">
                                ৳{item.price?.toLocaleString()} × {item.quantity}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="font-body font-medium">
                                ৳{(item.price * item.quantity).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                      
                      {/* Order Summary */}
                      <div className="mt-6 pt-4 border-t space-y-2">
                        <div className="flex justify-between text-sm font-body">
                          <span className="text-gray-600">Subtotal</span>
                          <span>৳{order.subtotal?.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm font-body">
                          <span className="text-gray-600">Shipping</span>
                          <span>
                            {order.shipping_cost === 0 ? "FREE" : `৳${order.shipping_cost}`}
                          </span>
                        </div>
                        {order.discount_amount > 0 && (
                          <div className="flex justify-between text-sm font-body text-green-600">
                            <span>Discount</span>
                            <span>-৳{order.discount_amount.toLocaleString()}</span>
                          </div>
                        )}
                        <div className="flex justify-between font-display text-lg pt-2 border-t">
                          <span>Total</span>
                          <span>৳{order.total?.toLocaleString()}</span>
                        </div>
                      </div>
                      
                      {/* Payment & Shipping Info */}
                      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h5 className="font-display text-sm mb-2">Payment Method</h5>
                          <p className="text-sm text-gray-600 font-body capitalize">
                            {order.payment_method === "cod" ? "Cash on Delivery" : order.payment_method}
                          </p>
                          <Badge className={`mt-2 rounded-none ${
                            order.payment_status === "paid" 
                              ? "bg-green-100 text-green-800" 
                              : "bg-yellow-100 text-yellow-800"
                          }`}>
                            {order.payment_status}
                          </Badge>
                        </div>
                        <div>
                          <h5 className="font-display text-sm mb-2">Shipping Address</h5>
                          <p className="text-sm text-gray-600 font-body">
                            {order.shipping_address?.full_name}<br />
                            {order.shipping_address?.phone}<br />
                            {order.shipping_address?.address_line1}<br />
                            {order.shipping_address?.city}, {order.shipping_address?.district}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-20 bg-white">
            <ShoppingBag className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h2 className="font-display text-2xl mb-2">No orders yet</h2>
            <p className="text-gray-500 font-body mb-8">
              Looks like you haven't placed any orders yet.
            </p>
            <Link to={createPageUrl("Shop")}>
              <Button className="bg-[#0a0a0a] hover:bg-[#d4a853] hover:text-black rounded-none px-8">
                Start Shopping
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}