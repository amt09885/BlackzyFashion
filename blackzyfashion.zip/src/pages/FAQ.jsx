import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Loader2, MessageCircle, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const categoryLabels = {
  orders_shipping: "Orders & Shipping",
  returns_refunds: "Returns & Refunds",
  products_fabrics: "Products & Fabrics",
  payments: "Payments",
  account_orders: "Account & Orders"
};

export default function FAQ() {
  const { data: siteSettings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const settings = await base44.entities.SiteSettings.filter({ key: "main" });
      return settings[0] || null;
    },
    staleTime: 2 * 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const { data: faqs = [], isLoading } = useQuery({
    queryKey: ['faqs'],
    queryFn: () => base44.entities.FAQItem.filter({ is_active: true }, "sort_order"),
    staleTime: 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const s = siteSettings || {};

  const groupedFAQs = faqs.reduce((acc, item) => {
    const cat = item.category || "orders_shipping";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(item);
    return acc;
  }, {});

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <section className="bg-[#0a0a0a] py-16 px-4">
        <div className="max-w-7xl mx-auto text-center text-white">
          <h1 className="font-display text-4xl md:text-5xl mb-4">
            {s.faq_page_title || "Frequently Asked Questions"}
          </h1>
          <p className="text-gray-400 font-body">
            {s.faq_page_subtitle || "Find answers to common questions"}
          </p>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-3xl mx-auto">
          {Object.entries(groupedFAQs).map(([category, items]) => (
            <div key={category} className="mb-10">
              <h2 className="font-display text-2xl mb-4 pb-2 border-b">
                {categoryLabels[category] || category}
              </h2>
              <Accordion type="single" collapsible className="space-y-2">
                {items.map((item, index) => (
                  <AccordionItem key={item.id} value={item.id} className="bg-white border rounded-lg px-4">
                    <AccordionTrigger className="font-body text-left hover:no-underline">
                      {item.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-600 font-body">
                      {item.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          ))}

          {faqs.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              No FAQs available yet.
            </div>
          )}
        </div>
      </section>

      <section className="py-16 px-4 bg-[#faf8f5]">
        <div className="max-w-xl mx-auto text-center">
          <h2 className="font-display text-2xl mb-4">
            {s.faq_cta_title || "Still have questions?"}
          </h2>
          <p className="text-gray-600 font-body mb-6">
            {s.faq_cta_text || "Can't find the answer you're looking for? Our team is here to help."}
          </p>
          <Link to={createPageUrl("Contact")}>
            <Button className="bg-[#d4a853] hover:bg-[#c49743] text-black gap-2 rounded-none">
              <MessageCircle className="w-4 h-4" /> Contact Us
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}