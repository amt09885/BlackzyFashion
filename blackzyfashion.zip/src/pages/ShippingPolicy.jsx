import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Loader2, Truck, MapPin, Clock } from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function ShippingPolicy() {
  const { data: siteSettings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const settings = await base44.entities.SiteSettings.filter({ key: "main" });
      return settings[0] || null;
    },
    staleTime: 2 * 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const { data: pageContent, isLoading } = useQuery({
    queryKey: ['page-content', 'shipping_policy'],
    queryFn: async () => {
      const pages = await base44.entities.PageContent.filter({ page_key: "shipping_policy" });
      return pages[0] || null;
    },
    staleTime: 24 * 60 * 60 * 1000,
    cacheTime: 7 * 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const s = siteSettings || {};

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <section className="bg-[#0a0a0a] py-16 px-4">
        <div className="max-w-7xl mx-auto text-center text-white">
          <h1 className="font-display text-4xl md:text-5xl mb-4">
            {pageContent?.title || "Shipping Policy"}
          </h1>
          <p className="text-gray-400 font-body">
            {pageContent?.subtitle || "Fast & reliable delivery across Bangladesh"}
          </p>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Shipping Rates Table */}
          <div className="bg-white rounded-lg shadow-sm p-6 mb-10">
            <h2 className="font-display text-2xl mb-6">Shipping Rates & Delivery Times</h2>
            <div className="grid gap-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded">
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-[#d4a853]" />
                  <span className="font-body">Inside Dhaka</span>
                </div>
                <div className="text-right">
                  <p className="font-medium">{s.shipping_inside_dhaka_cost || "৳60 (Free above ৳2000)"}</p>
                  <p className="text-sm text-gray-500">{s.shipping_inside_dhaka_days || "3-5 business days"}</p>
                </div>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded">
                <div className="flex items-center gap-3">
                  <Truck className="w-5 h-5 text-[#d4a853]" />
                  <span className="font-body">Outside Dhaka</span>
                </div>
                <div className="text-right">
                  <p className="font-medium">{s.shipping_outside_dhaka_cost || "৳120 (Free above ৳2000)"}</p>
                  <p className="text-sm text-gray-500">{s.shipping_outside_dhaka_days || "5-7 business days"}</p>
                </div>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-[#d4a853]" />
                  <span className="font-body">Remote Areas</span>
                </div>
                <div className="text-right">
                  <p className="font-medium">{s.shipping_remote_cost || "৳150 (Free above ৳2000)"}</p>
                  <p className="text-sm text-gray-500">{s.shipping_remote_days || "7-10 business days"}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Custom Content */}
          {pageContent?.content ? (
            <div className="prose prose-lg max-w-none font-body">
              <ReactMarkdown>{pageContent.content}</ReactMarkdown>
            </div>
          ) : (
            <div className="space-y-8 font-body text-gray-600">
              <div>
                <h3 className="font-display text-xl mb-3">Order Processing</h3>
                <p>Orders are processed within 24-48 hours during business days. You will receive a confirmation email with tracking details once your order is shipped.</p>
              </div>
              <div>
                <h3 className="font-display text-xl mb-3">Tracking Your Order</h3>
                <p>Once shipped, you'll receive an SMS and email with your tracking number. Track your order anytime from our Track Order page.</p>
              </div>
              <div>
                <h3 className="font-display text-xl mb-3">Delivery Partners</h3>
                <p>We work with trusted courier partners including Pathao, Redx, and Sundarban Courier to ensure safe and timely delivery of your orders.</p>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}