import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  CreditCard, Wallet, Truck, ChevronLeft, 
  Loader2, Check, Shield, Lock, Copy
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";


const divisions = [
  "Dhaka", "Chittagong", "Rajshahi", "Khulna", 
  "Barisal", "Sylhet", "Rangpur", "Mymensingh"
];

export default function Checkout() {
  const [user, setUser] = useState(null);
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [step, setStep] = useState(1);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone: "",
    address_line1: "",
    address_line2: "",
    city: "",
    district: "",
    postal_code: "",
    delivery_area: "inside_dhaka",
    notes: "",
    payment_method: "cod",
    transaction_id: "",
    save_address: true
  });

  const { data: siteSettings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const settings = await base44.entities.SiteSettings.filter({ key: "main" });
      return settings[0] || null;
    },
    staleTime: 2 * 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const paymentSettings = {
    bkash_number: siteSettings?.bkash_number || "01923931102",
    nagad_number: siteSettings?.nagad_number || "01923931102",
    rocket_number: siteSettings?.rocket_number || "01923931102",
    upay_number: siteSettings?.upay_number || "01923931102",
    ific_bank_account: siteSettings?.ific_bank_account || "0210331357811",
    ific_bank_name: siteSettings?.ific_bank_name || "MD SIAM",
    ific_bank_branch: siteSettings?.ific_bank_branch || "Malibag Mur Uposhakha",
    dbbl_agent_account: siteSettings?.dbbl_agent_account || "7017341850529",
    dbbl_agent_name: siteSettings?.dbbl_agent_name || "Md Siam",
    dbbl_account: siteSettings?.dbbl_account || "1091580152138",
    dbbl_name: siteSettings?.dbbl_name || "MD SIAM",
    dbbl_branch: siteSettings?.dbbl_branch || "BaburHat Branch",
    ucb_account: siteSettings?.ucb_account || "1702113000003860",
    ucb_name: siteSettings?.ucb_name || "MD SIAM",
    ucb_branch: siteSettings?.ucb_branch || "Danga Bazar Branch",
    bkash_enabled: siteSettings?.bkash_enabled !== false,
    nagad_enabled: siteSettings?.nagad_enabled !== false,
    rocket_enabled: siteSettings?.rocket_enabled !== false,
    upay_enabled: siteSettings?.upay_enabled !== false,
    ific_enabled: siteSettings?.ific_enabled !== false,
    dbbl_agent_enabled: siteSettings?.dbbl_agent_enabled !== false,
    dbbl_enabled: siteSettings?.dbbl_enabled !== false,
    ucb_enabled: siteSettings?.ucb_enabled !== false,
    cod_enabled: siteSettings?.cod_enabled !== false
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Number copied!" });
  };

  useEffect(() => {
    loadData();
  }, []);

  const getSessionId = () => localStorage.getItem('guest_session_id');

  const loadData = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      let items = [];
      
      if (isAuth) {
        const userData = await base44.auth.me();
        setUser(userData);
        
        setFormData(prev => ({
          ...prev,
          full_name: userData.full_name || "",
          email: userData.email || "",
          phone: userData.phone || "",
          address_line1: userData.address_line1 || "",
          address_line2: userData.address_line2 || "",
          city: userData.city || "",
          district: userData.district || "",
          postal_code: userData.postal_code || ""
        }));
        
        items = await base44.entities.CartItem.filter({ user_email: userData.email });
      } else {
        const sessionId = getSessionId();
        if (sessionId) {
          items = await base44.entities.CartItem.filter({ session_id: sessionId });
        }
      }
      
      setCartItems(items);
      
      if (items.length === 0) {
        window.location.href = createPageUrl("Cart");
      }
    } catch (e) {
      console.error("Error loading checkout:", e);
    }
    setLoading(false);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateStep1 = () => {
    if (!formData.full_name || !formData.phone || !formData.address_line1 || !formData.city || !formData.district) {
      toast({
        title: "Please fill in all required fields",
        variant: "destructive"
      });
      return false;
    }
    
    if (!/^01[3-9]\d{8}$/.test(formData.phone)) {
      toast({
        title: "Please enter a valid Bangladeshi phone number",
        variant: "destructive"
      });
      return false;
    }

    const onlinePaymentMethods = ["bkash", "nagad", "rocket", "upay", "ific", "dbbl_agent", "dbbl", "ucb"];
    if (onlinePaymentMethods.includes(formData.payment_method) && !formData.transaction_id) {
      toast({
        title: "Please enter your Transaction ID or Account Details",
        variant: "destructive"
      });
      return false;
    }
    
    return true;
  };

  const handlePlaceOrder = async () => {
    if (!validateStep1()) return;

    // Track InitiateCheckout event
    if (window.fbq) {
      window.fbq('track', 'InitiateCheckout', {
        content_ids: cartItems.map(item => item.product_id),
        contents: cartItems.map(item => ({
          id: item.product_id,
          quantity: item.quantity
        })),
        value: total,
        currency: 'BDT',
        num_items: cartItems.reduce((sum, item) => sum + item.quantity, 0)
      });
    }
    
    setSubmitting(true);
    try {
      const orderNumber = `BF${Date.now().toString(36).toUpperCase()}`;
      
      const orderData = {
        order_number: orderNumber,
        customer_email: user?.email || formData.email || "",
        customer_name: formData.full_name,
        customer_phone: formData.phone,
        shipping_address: {
          full_name: formData.full_name,
          phone: formData.phone,
          address_line1: formData.address_line1,
          address_line2: formData.address_line2,
          city: formData.city,
          district: formData.district,
          postal_code: formData.postal_code
        },
        items: cartItems.map(item => ({
          product_id: item.product_id,
          product_name: item.product_name,
          product_image: item.product_image,
          quantity: item.quantity,
          price: item.price,
          size: item.size,
          color: item.color
        })),
        subtotal: subtotal,
        shipping_cost: shippingCost,
        discount_amount: 0,
        total: total,
        payment_method: formData.payment_method,
        payment_status: formData.payment_method === "cod" ? "pending" : "pending",
        order_status: "pending",
        notes: formData.notes
      };

      await base44.entities.Order.create(orderData);
      
      // Clear cart
      for (const item of cartItems) {
        await base44.entities.CartItem.delete(item.id);
      }
      
      // Clear guest session
      localStorage.removeItem('guest_session_id');
      
      // Save address if checked and user is logged in
      if (formData.save_address && user) {
        await base44.auth.updateMe({
          phone: formData.phone,
          address_line1: formData.address_line1,
          address_line2: formData.address_line2,
          city: formData.city,
          district: formData.district,
          postal_code: formData.postal_code
        });
      }
      
      // Redirect to success page
      window.location.href = createPageUrl("OrderSuccess") + `?order=${orderNumber}`;
    } catch (e) {
      console.error("Order error:", e);
      toast({
        title: "Error placing order",
        description: "Please try again.",
        variant: "destructive"
      });
    }
    setSubmitting(false);
  };

  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const freeShippingThreshold = siteSettings?.free_shipping_threshold || 2000;
  const isFreeShipping = subtotal >= freeShippingThreshold;
  const insideDhakaCost = parseInt(siteSettings?.shipping_inside_dhaka_cost) || 60;
  const outsideDhakaCost = parseInt(siteSettings?.shipping_outside_dhaka_cost) || 120;
  const shippingCost = isFreeShipping ? 0 : 
    (formData.delivery_area === "inside_dhaka" ? insideDhakaCost : outsideDhakaCost);
  const total = subtotal + shippingCost;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#fafafa]">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <Link 
            to={createPageUrl("Cart")}
            className="inline-flex items-center gap-2 text-sm text-gray-600 hover:text-[#d4a853] font-body"
          >
            <ChevronLeft className="w-4 h-4" />
            Back to Cart
          </Link>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="font-display text-3xl md:text-4xl text-center mb-8">Checkout</h1>
        
        {/* Progress Steps */}
        <div className="flex justify-center mb-12">
          <div className="flex items-center gap-4">
            <div className={`flex items-center gap-2 ${step >= 1 ? "text-[#d4a853]" : "text-gray-400"}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                step >= 1 ? "bg-[#d4a853] text-black" : "bg-gray-200"
              }`}>
                1
              </div>
              <span className="text-sm font-body hidden sm:inline">Shipping</span>
            </div>
            <div className="w-12 h-px bg-gray-300" />
            <div className={`flex items-center gap-2 ${step >= 2 ? "text-[#d4a853]" : "text-gray-400"}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                step >= 2 ? "bg-[#d4a853] text-black" : "bg-gray-200"
              }`}>
                2
              </div>
              <span className="text-sm font-body hidden sm:inline">Payment</span>
            </div>
            <div className="w-12 h-px bg-gray-300" />
            <div className={`flex items-center gap-2 ${step >= 3 ? "text-[#d4a853]" : "text-gray-400"}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                step >= 3 ? "bg-[#d4a853] text-black" : "bg-gray-200"
              }`}>
                3
              </div>
              <span className="text-sm font-body hidden sm:inline">Review</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <div className="bg-white p-6 md:p-8">
              {/* Order Notes - Moved to top */}
              <div className="mb-8">
                <Label className="font-body text-sm font-medium">Order Notes (Optional)</Label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => handleInputChange("notes", e.target.value)}
                  className="rounded-none mt-1"
                  placeholder="Any special instructions for your order..."
                  rows={3}
                />
              </div>

              {/* Shipping Information */}
              <div className="mb-8">
                <h2 className="font-body text-lg font-semibold mb-6 flex items-center gap-2">
                  <Truck className="w-5 h-5 text-[#d4a853]" />
                  Shipping Information
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="font-body text-sm font-medium">Full Name *</Label>
                    <Input
                      value={formData.full_name}
                      onChange={(e) => handleInputChange("full_name", e.target.value)}
                      className="rounded-none mt-1"
                      placeholder="Enter your full name"
                    />
                  </div>
                  <div>
                    <Label className="font-body text-sm">Phone Number *</Label>
                    <Input
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                      className="rounded-none mt-1"
                      placeholder="01XXXXXXXXX"
                    />
                  </div>
                  <div>
                    <Label className="font-body text-sm">Email</Label>
                    <Input
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      disabled={!!user}
                      className={`rounded-none mt-1 ${user ? "bg-gray-50" : ""}`}
                      placeholder="your@email.com"
                    />
                  </div>
                  <div>
                    <Label className="font-body text-sm">District *</Label>
                    <Select 
                      value={formData.district} 
                      onValueChange={(v) => handleInputChange("district", v)}
                    >
                      <SelectTrigger className="rounded-none mt-1">
                        <SelectValue placeholder="Select district" />
                      </SelectTrigger>
                      <SelectContent>
                        {divisions.map(div => (
                          <SelectItem key={div} value={div}>{div}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="md:col-span-2">
                    <Label className="font-body text-sm">Address *</Label>
                    <Input
                      value={formData.address_line1}
                      onChange={(e) => handleInputChange("address_line1", e.target.value)}
                      className="rounded-none mt-1"
                      placeholder="House/Road/Area"
                    />
                  </div>
                  <div>
                    <Label className="font-body text-sm font-medium">Upazila/City *</Label>
                    <Input
                      value={formData.city}
                      onChange={(e) => handleInputChange("city", e.target.value)}
                      className="rounded-none mt-1"
                      placeholder="Upazila/City"
                    />
                  </div>
                  <div>
                    <Label className="font-body text-sm">Postal Code</Label>
                    <Input
                      value={formData.postal_code}
                      onChange={(e) => handleInputChange("postal_code", e.target.value)}
                      className="rounded-none mt-1"
                      placeholder="Postal code"
                    />
                  </div>
                </div>

                {/* Delivery Area Selection */}
                <div className="mt-6 pt-6 border-t">
                  <Label className="font-body text-sm font-medium mb-3 block">Delivery Area *</Label>
                  <RadioGroup 
                    value={formData.delivery_area} 
                    onValueChange={(v) => handleInputChange("delivery_area", v)}
                    className="space-y-3"
                  >
                    <label className={`flex items-center justify-between p-4 border-2 rounded cursor-pointer ${
                      formData.delivery_area === "inside_dhaka" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200 hover:border-gray-300"
                    }`}>
                      <div className="flex items-center gap-3">
                        <RadioGroupItem value="inside_dhaka" id="inside_dhaka" />
                        <div>
                          <p className="font-medium font-body">Inside Dhaka</p>
                          <p className="text-xs text-gray-500">Delivery within Dhaka city</p>
                        </div>
                      </div>
                      <span className={`font-body font-semibold ${isFreeShipping ? "text-green-600" : "text-gray-700"}`}>
                        {isFreeShipping ? "FREE" : `৳${insideDhakaCost}`}
                      </span>
                    </label>

                    <label className={`flex items-center justify-between p-4 border-2 rounded cursor-pointer ${
                      formData.delivery_area === "outside_dhaka" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200 hover:border-gray-300"
                    }`}>
                      <div className="flex items-center gap-3">
                        <RadioGroupItem value="outside_dhaka" id="outside_dhaka" />
                        <div>
                          <p className="font-medium font-body">Outside Dhaka</p>
                          <p className="text-xs text-gray-500">Delivery outside Dhaka city</p>
                        </div>
                      </div>
                      <span className={`font-body font-semibold ${isFreeShipping ? "text-green-600" : "text-gray-700"}`}>
                        {isFreeShipping ? "FREE" : `৳${outsideDhakaCost}`}
                      </span>
                    </label>
                  </RadioGroup>
                </div>
                
                {user && (
                  <div className="flex items-center gap-2 mt-4">
                    <Checkbox
                      id="save_address"
                      checked={formData.save_address}
                      onCheckedChange={(v) => handleInputChange("save_address", v)}
                    />
                    <Label htmlFor="save_address" className="font-body text-sm cursor-pointer">
                      Save this address for future orders
                    </Label>
                  </div>
                )}
              </div>

              {/* Payment Method */}
              <div className="mb-8">
                <h2 className="font-display text-xl mb-6 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-[#d4a853]" />
                  Payment Method
                </h2>
                
                <RadioGroup 
                  value={formData.payment_method} 
                  onValueChange={(v) => {
                    handleInputChange("payment_method", v);
                    handleInputChange("transaction_id", "");
                  }}
                  className="space-y-3"
                >
                  {paymentSettings.cod_enabled && (
                    <label className={`flex items-center justify-between p-4 border-2 cursor-pointer ${
                      formData.payment_method === "cod" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200 hover:border-gray-300"
                    }`}>
                      <div className="flex items-center gap-4">
                        <RadioGroupItem value="cod" id="cod" />
                        <Wallet className="w-8 h-8 text-gray-600" />
                        <div>
                          <p className="font-body font-medium">Cash on Delivery</p>
                          <p className="text-xs text-gray-500">Pay when you receive</p>
                        </div>
                      </div>
                      <span className="font-bold text-lg">৳{total.toLocaleString()}</span>
                    </label>
                  )}
                  
                  {paymentSettings.bkash_enabled && (
                    <div className={`border-2 ${
                      formData.payment_method === "bkash" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"
                    }`}>
                      <label className="flex items-center justify-between p-4 cursor-pointer">
                        <div className="flex items-center gap-4">
                          <RadioGroupItem value="bkash" id="bkash" />
                          <img 
                            src="https://www.logo.wine/a/logo/BKash/BKash-Icon-Logo.wine.svg" 
                            alt="bKash" 
                            loading="lazy"
                            decoding="async"
                            className="h-12 object-contain"
                          />
                          <div>
                            <p className="font-body font-medium text-base">bKash</p>
                            <p className="text-xs text-gray-500">Personal/Agent</p>
                          </div>
                        </div>
                        <span className="font-bold text-xl text-[#E2136E]">৳{total.toLocaleString()}</span>
                      </label>
                      
                      {formData.payment_method === "bkash" && (
                        <div className="px-4 pb-4 pt-2 border-t border-[#d4a853]/20 bg-[#E2136E]/5">
                          <div className="text-sm space-y-2 mb-4 text-gray-700">
                            <p className="font-semibold">📱 How to Pay:</p>
                            <ol className="list-decimal list-inside text-xs space-y-1 ml-2">
                              <li>Open bKash app</li>
                              <li>Select "Send Money"</li>
                              <li>Enter number: <strong className="text-[#E2136E]">{paymentSettings.bkash_number}</strong></li>
                              <li>Amount: <strong>৳{total.toLocaleString()}</strong></li>
                              <li>Complete payment & copy Transaction ID</li>
                            </ol>
                          </div>
                          <div className="p-3 bg-white rounded border border-[#E2136E]/20 mb-3">
                            <div className="flex items-center justify-between">
                              <span className="font-mono font-bold text-base text-[#E2136E]">{paymentSettings.bkash_number}</span>
                              <Button 
                                type="button"
                                variant="ghost" 
                                size="sm"
                                onClick={() => copyToClipboard(paymentSettings.bkash_number)}
                                className="text-[#E2136E] hover:bg-[#E2136E]/10"
                              >
                                <Copy className="w-4 h-4 mr-1" /> Copy
                              </Button>
                            </div>
                          </div>
                          <div>
                            <Label className="font-body text-sm">Transaction ID *</Label>
                            <Input
                              value={formData.transaction_id}
                              onChange={(e) => handleInputChange("transaction_id", e.target.value)}
                              className="rounded-none mt-1"
                              placeholder="e.g., 8AH9K9I6J2"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {paymentSettings.nagad_enabled && (
                    <div className={`border-2 ${
                      formData.payment_method === "nagad" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"
                    }`}>
                      <label className="flex items-center justify-between p-4 cursor-pointer">
                        <div className="flex items-center gap-4">
                          <RadioGroupItem value="nagad" id="nagad" />
                          <img 
                            src="https://download.logo.wine/logo/Nagad/Nagad-Logo.wine.png" 
                            alt="Nagad" 
                            loading="lazy"
                            decoding="async"
                            className="h-12 object-contain"
                          />
                          <div>
                            <p className="font-body font-medium text-base">Nagad</p>
                            <p className="text-xs text-gray-500">Personal</p>
                          </div>
                        </div>
                        <span className="font-bold text-xl text-[#F6921E]">৳{total.toLocaleString()}</span>
                      </label>
                      
                      {formData.payment_method === "nagad" && (
                        <div className="px-4 pb-4 pt-2 border-t border-[#d4a853]/20 bg-[#F6921E]/5">
                          <div className="text-sm space-y-2 mb-4 text-gray-700">
                            <p className="font-semibold">📱 How to Pay:</p>
                            <ol className="list-decimal list-inside text-xs space-y-1 ml-2">
                              <li>Open Nagad app</li>
                              <li>Select "Send Money"</li>
                              <li>Enter number: <strong className="text-[#F6921E]">{paymentSettings.nagad_number}</strong></li>
                              <li>Amount: <strong>৳{total.toLocaleString()}</strong></li>
                              <li>Complete payment & copy Transaction ID</li>
                            </ol>
                          </div>
                          <div className="p-3 bg-white rounded border border-[#F6921E]/20 mb-3">
                            <div className="flex items-center justify-between">
                              <span className="font-mono font-bold text-base text-[#F6921E]">{paymentSettings.nagad_number}</span>
                              <Button 
                                type="button"
                                variant="ghost" 
                                size="sm"
                                onClick={() => copyToClipboard(paymentSettings.nagad_number)}
                                className="text-[#F6921E] hover:bg-[#F6921E]/10"
                              >
                                <Copy className="w-4 h-4 mr-1" /> Copy
                              </Button>
                            </div>
                          </div>
                          <div>
                            <Label className="font-body text-sm">Transaction ID *</Label>
                            <Input
                              value={formData.transaction_id}
                              onChange={(e) => handleInputChange("transaction_id", e.target.value)}
                              className="rounded-none mt-1"
                              placeholder="e.g., 7NH123456789"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {paymentSettings.rocket_enabled && (
                    <div className={`border-2 ${formData.payment_method === "rocket" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"}`}>
                      <label className="flex items-center justify-between p-4 cursor-pointer">
                        <div className="flex items-center gap-4">
                          <RadioGroupItem value="rocket" id="rocket" />
                          <div className="w-12 h-12 bg-purple-100 rounded flex items-center justify-center">
                            <Wallet className="w-7 h-7 text-purple-600" />
                          </div>
                          <div>
                            <p className="font-body font-medium text-base">Rocket</p>
                            <p className="text-xs text-gray-500">{paymentSettings.rocket_number}</p>
                          </div>
                        </div>
                        <span className="font-bold text-xl text-purple-600">৳{total.toLocaleString()}</span>
                      </label>
                      {formData.payment_method === "rocket" && (
                        <div className="px-4 pb-4 pt-2 border-t bg-purple-50">
                          <p className="text-xs mb-2">Send Money • Enter Transaction ID</p>
                          <Input value={formData.transaction_id} onChange={(e) => handleInputChange("transaction_id", e.target.value)} className="rounded-none" placeholder="Transaction ID" />
                        </div>
                      )}
                    </div>
                  )}

                  {paymentSettings.upay_enabled && (
                    <div className={`border-2 ${formData.payment_method === "upay" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"}`}>
                      <label className="flex items-center justify-between p-4 cursor-pointer">
                        <div className="flex items-center gap-4">
                          <RadioGroupItem value="upay" id="upay" />
                          <div className="w-12 h-12 bg-red-100 rounded flex items-center justify-center">
                            <Wallet className="w-7 h-7 text-red-600" />
                          </div>
                          <div>
                            <p className="font-body font-medium text-base">Upay</p>
                            <p className="text-xs text-gray-500">{paymentSettings.upay_number}</p>
                          </div>
                        </div>
                        <span className="font-bold text-xl text-red-600">৳{total.toLocaleString()}</span>
                      </label>
                      {formData.payment_method === "upay" && (
                        <div className="px-4 pb-4 pt-2 border-t bg-red-50">
                          <p className="text-xs mb-2">Send Money • Enter Transaction ID</p>
                          <Input value={formData.transaction_id} onChange={(e) => handleInputChange("transaction_id", e.target.value)} className="rounded-none" placeholder="Transaction ID" />
                        </div>
                      )}
                    </div>
                  )}

                  {paymentSettings.ific_enabled && (
                    <div className={`border-2 ${formData.payment_method === "ific" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"}`}>
                      <label className="flex items-center justify-between p-4 cursor-pointer">
                        <div className="flex items-center gap-4">
                          <RadioGroupItem value="ific" id="ific" />
                          <CreditCard className="w-10 h-10 text-blue-600" />
                          <div>
                            <p className="font-body font-medium text-base">IFIC Bank</p>
                            <p className="text-xs text-gray-500">{paymentSettings.ific_bank_branch}</p>
                          </div>
                        </div>
                        <span className="font-bold text-xl text-blue-600">৳{total.toLocaleString()}</span>
                      </label>
                      {formData.payment_method === "ific" && (
                        <div className="px-4 pb-4 pt-2 border-t bg-blue-50">
                          <p className="text-xs mb-2"><strong>A/C: {paymentSettings.ific_bank_account}</strong><br/>Name: {paymentSettings.ific_bank_name}<br/>Branch: {paymentSettings.ific_bank_branch}</p>
                          <Input value={formData.transaction_id} onChange={(e) => handleInputChange("transaction_id", e.target.value)} className="rounded-none" placeholder="Reference No." />
                        </div>
                      )}
                    </div>
                  )}

                  {paymentSettings.dbbl_agent_enabled && (
                    <div className={`border-2 ${formData.payment_method === "dbbl_agent" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"}`}>
                      <label className="flex items-center justify-between p-4 cursor-pointer">
                        <div className="flex items-center gap-4">
                          <RadioGroupItem value="dbbl_agent" id="dbbl_agent" />
                          <CreditCard className="w-10 h-10 text-green-600" />
                          <div>
                            <p className="font-body font-medium text-base">DBBL Agent Banking</p>
                            <p className="text-xs text-gray-500">{paymentSettings.dbbl_agent_name}</p>
                          </div>
                        </div>
                        <span className="font-bold text-xl text-green-600">৳{total.toLocaleString()}</span>
                      </label>
                      {formData.payment_method === "dbbl_agent" && (
                        <div className="px-4 pb-4 pt-2 border-t bg-green-50">
                          <p className="text-xs mb-2"><strong>A/C: {paymentSettings.dbbl_agent_account}</strong><br/>Name: {paymentSettings.dbbl_agent_name}</p>
                          <Input value={formData.transaction_id} onChange={(e) => handleInputChange("transaction_id", e.target.value)} className="rounded-none" placeholder="Reference No." />
                        </div>
                      )}
                    </div>
                  )}

                  {paymentSettings.dbbl_enabled && (
                    <div className={`border-2 ${formData.payment_method === "dbbl" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"}`}>
                      <label className="flex items-center justify-between p-4 cursor-pointer">
                        <div className="flex items-center gap-4">
                          <RadioGroupItem value="dbbl" id="dbbl" />
                          <CreditCard className="w-10 h-10 text-teal-600" />
                          <div>
                            <p className="font-body font-medium text-base">Dutch Bangla Bank</p>
                            <p className="text-xs text-gray-500">{paymentSettings.dbbl_branch}</p>
                          </div>
                        </div>
                        <span className="font-bold text-xl text-teal-600">৳{total.toLocaleString()}</span>
                      </label>
                      {formData.payment_method === "dbbl" && (
                        <div className="px-4 pb-4 pt-2 border-t bg-teal-50">
                          <p className="text-xs mb-2"><strong>A/C: {paymentSettings.dbbl_account}</strong><br/>Name: {paymentSettings.dbbl_name}<br/>Branch: {paymentSettings.dbbl_branch}</p>
                          <Input value={formData.transaction_id} onChange={(e) => handleInputChange("transaction_id", e.target.value)} className="rounded-none" placeholder="Reference No." />
                        </div>
                      )}
                    </div>
                  )}

                  {paymentSettings.ucb_enabled && (
                    <div className={`border-2 ${formData.payment_method === "ucb" ? "border-[#d4a853] bg-[#faf8f5]" : "border-gray-200"}`}>
                      <label className="flex items-center justify-between p-4 cursor-pointer">
                        <div className="flex items-center gap-4">
                          <RadioGroupItem value="ucb" id="ucb" />
                          <CreditCard className="w-10 h-10 text-indigo-600" />
                          <div>
                            <p className="font-body font-medium text-base">United Commercial Bank</p>
                            <p className="text-xs text-gray-500">{paymentSettings.ucb_branch}</p>
                          </div>
                        </div>
                        <span className="font-bold text-xl text-indigo-600">৳{total.toLocaleString()}</span>
                      </label>
                      {formData.payment_method === "ucb" && (
                        <div className="px-4 pb-4 pt-2 border-t bg-indigo-50">
                          <p className="text-xs mb-2"><strong>A/C: {paymentSettings.ucb_account}</strong><br/>Name: {paymentSettings.ucb_name}<br/>Branch: {paymentSettings.ucb_branch}</p>
                          <Input value={formData.transaction_id} onChange={(e) => handleInputChange("transaction_id", e.target.value)} className="rounded-none" placeholder="Reference No." />
                        </div>
                      )}
                    </div>
                  )}
                </RadioGroup>
              </div>


            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white p-6 sticky top-24">
              <h2 className="font-display text-xl mb-6">Order Summary</h2>
              
              {/* Items */}
              <div className="space-y-4 max-h-60 overflow-y-auto mb-6">
                {cartItems.map(item => (
                  <div key={item.id} className="flex gap-3">
                    <div className="w-16 h-16 bg-gray-100 flex-shrink-0">
                      <img 
                        src={item.product_image || "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=100"}
                        alt={item.product_name}
                        loading="lazy"
                        decoding="async"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-body text-sm line-clamp-1">{item.product_name}</p>
                      <p className="text-xs text-gray-500">
                        {item.size && `${item.size} `}× {item.quantity}
                      </p>
                      <p className="font-body text-sm font-bold">
                        ৳{(item.price * item.quantity).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Totals */}
              <div className="space-y-3 border-t pt-4">
                <div className="flex justify-between text-sm font-body">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-bold">৳{subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm font-body">
                  <span className="text-gray-600">Shipping</span>
                  <span className="font-bold">
                    {shippingCost === 0 ? (
                      <span className="text-green-600">FREE</span>
                    ) : (
                      `৳${shippingCost}`
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-lg font-body border-t pt-3">
                  <span className="font-medium">Total</span>
                  <span className="font-bold">৳{total.toLocaleString()}</span>
                </div>
              </div>
              
              {/* Place Order Button */}
              <Button 
                onClick={handlePlaceOrder}
                disabled={submitting}
                className="w-full mt-6 bg-[#d4a853] hover:bg-[#c49743] text-black rounded-none py-6 text-sm tracking-wider"
              >
                {submitting ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <Check className="w-4 h-4 mr-2" />
                )}
                PLACE ORDER
              </Button>
              
              {/* Security Note */}
              <div className="flex items-center justify-center gap-2 mt-4 text-xs text-gray-500 font-body">
                <Lock className="w-3 h-3" />
                <span>Secure checkout</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}