import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Mail, Users, Send, Trash2, Eye, Reply, Menu, 
  Loader2, CheckCircle, XCircle, MessageSquare
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useToast } from "@/components/ui/use-toast";
import { format } from "date-fns";
import AdminSidebar from "../components/admin/AdminSidebar";

const LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69258a473b6708fb6e444528/864e69bb5_Blackzyfashion.png";

const emailTemplates = [
  { id: "new_arrivals", name: "New Arrivals", subject: "✨ New Arrivals Just Dropped!" },
  { id: "exclusive_offer", name: "Exclusive Offer", subject: "🎁 Exclusive Offer Just For You!" },
  { id: "styling_tips", name: "Styling Tips", subject: "💃 Styling Tips: Rock Your Saree!" },
  { id: "custom", name: "Custom Email", subject: "" }
];

export default function AdminMarketing() {
  const [loading, setLoading] = useState(true);
  const [subscribers, setSubscribers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState("custom");
  const [emailSubject, setEmailSubject] = useState("");
  const [emailContent, setEmailContent] = useState("");
  const [sending, setSending] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [showMessageDialog, setShowMessageDialog] = useState(false);
  const [replyContent, setReplyContent] = useState("");
  const [sendingReply, setSendingReply] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      const userData = await base44.auth.me();
      if (userData.role !== "admin") {
        window.location.href = createPageUrl("Home");
        return;
      }
      await loadData();
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const loadData = async () => {
    try {
      const [subs, msgs] = await Promise.all([
        base44.entities.Subscriber.filter({ is_active: true }),
        base44.entities.ContactMessage.list("-created_date", 100)
      ]);
      setSubscribers(subs);
      setMessages(msgs);
    } catch (e) {
      console.error(e);
    }
  };

  const handleTemplateChange = (templateId) => {
    setSelectedTemplate(templateId);
    const template = emailTemplates.find(t => t.id === templateId);
    if (template && template.id !== "custom") {
      setEmailSubject(template.subject);
      
      if (templateId === "new_arrivals") {
        setEmailContent(`We're excited to announce our latest collection has arrived!

Discover stunning new sarees, fabrics, and designs that will make you stand out.

• Premium AC Cotton Collection
• Handcrafted Block Prints
• Elegant Silk Sarees

Shop now and be the first to grab these exclusive pieces.

With love,
Blackzy Fashion Team`);
      } else if (templateId === "exclusive_offer") {
        setEmailContent(`As a valued member of our family, we have a special offer just for you!

🎉 Get 20% OFF on your next purchase!

Use code: FAMILY20

Hurry! This offer is valid for a limited time only.

Happy Shopping!
Blackzy Fashion Team`);
      } else if (templateId === "styling_tips") {
        setEmailContent(`Hello Fashion Lover!

Here are some styling tips to rock your traditional look:

1. Pair your saree with statement jewelry
2. Choose the right blouse design for your body type
3. Experiment with different draping styles
4. Don't forget comfortable footwear

Visit our store for more inspiration!

Stay stylish,
Blackzy Fashion Team`);
      }
    } else {
      setEmailSubject("");
      setEmailContent("");
    }
  };

  const generateEmailHTML = (content) => {
    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600&family=Inter:wght@300;400;500&display=swap');
  </style>
</head>
<body style="margin: 0; padding: 0; background-color: #f5f5f5; font-family: 'Inter', Arial, sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; max-width: 600px;">
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%); padding: 30px; text-align: center;">
              <img src="${LOGO_URL}" alt="Blackzy Fashion" style="height: 50px; margin-bottom: 10px;" />
              <p style="color: #d4a853; font-size: 12px; letter-spacing: 3px; margin: 0;">PREMIUM BENGALI FASHION</p>
            </td>
          </tr>
          
          <!-- Content -->
          <tr>
            <td style="padding: 40px 30px;">
              <div style="font-size: 15px; line-height: 1.8; color: #333333; white-space: pre-wrap;">
${content}
              </div>
            </td>
          </tr>
          
          <!-- CTA Button -->
          <tr>
            <td style="padding: 0 30px 40px; text-align: center;">
              <a href="https://blackzyfashion.com" style="display: inline-block; background-color: #d4a853; color: #000000; padding: 15px 40px; text-decoration: none; font-weight: 600; font-size: 14px; letter-spacing: 1px;">
                SHOP NOW
              </a>
            </td>
          </tr>
          
          <!-- Divider -->
          <tr>
            <td style="padding: 0 30px;">
              <div style="border-top: 1px solid #eeeeee;"></div>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="padding: 30px; text-align: center; background-color: #fafafa;">
              <p style="color: #888888; font-size: 12px; margin: 0 0 10px;">
                Follow us on social media
              </p>
              <p style="margin: 0 0 20px;">
                <a href="#" style="color: #0a0a0a; text-decoration: none; margin: 0 10px;">Facebook</a>
                <a href="#" style="color: #0a0a0a; text-decoration: none; margin: 0 10px;">Instagram</a>
              </p>
              <p style="color: #aaaaaa; font-size: 11px; margin: 0;">
                © ${new Date().getFullYear()} Blackzy Fashion. All rights reserved.<br/>
                You received this email because you subscribed to our newsletter.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
  };

  const sendBulkEmail = async () => {
    if (!emailSubject || !emailContent) {
      toast({ title: "Please fill in subject and content", variant: "destructive" });
      return;
    }

    if (subscribers.length === 0) {
      toast({ title: "No subscribers to send to", variant: "destructive" });
      return;
    }

    setSending(true);
    let successCount = 0;
    let failCount = 0;

    const htmlBody = generateEmailHTML(emailContent);

    for (const subscriber of subscribers) {
      try {
        await base44.integrations.Core.SendEmail({
          to: subscriber.email,
          subject: emailSubject,
          body: htmlBody
        });
        successCount++;
      } catch (e) {
        failCount++;
        console.error(`Failed to send to ${subscriber.email}:`, e);
      }
    }

    toast({
      title: `Emails sent!`,
      description: `${successCount} successful, ${failCount} failed`
    });
    setSending(false);
  };

  const viewMessage = async (message) => {
    setSelectedMessage(message);
    setShowMessageDialog(true);
    
    if (!message.is_read) {
      await base44.entities.ContactMessage.update(message.id, { is_read: true });
      await loadData();
    }
  };

  const deleteMessage = async (message) => {
    if (!confirm("Delete this message?")) return;
    await base44.entities.ContactMessage.delete(message.id);
    toast({ title: "Message deleted" });
    await loadData();
  };

  const sendReply = async () => {
    if (!replyContent.trim()) {
      toast({ title: "Please enter a reply", variant: "destructive" });
      return;
    }

    setSendingReply(true);
    try {
      const htmlBody = generateEmailHTML(`Dear ${selectedMessage.name},

Thank you for contacting Blackzy Fashion.

${replyContent}

Best regards,
Blackzy Fashion Team`);

      await base44.integrations.Core.SendEmail({
        to: selectedMessage.email,
        subject: `Re: ${selectedMessage.subject || "Your message to Blackzy Fashion"}`,
        body: htmlBody
      });

      await base44.entities.ContactMessage.update(selectedMessage.id, { is_replied: true });
      
      toast({ title: "Reply sent successfully!" });
      setReplyContent("");
      setShowMessageDialog(false);
      await loadData();
    } catch (e) {
      toast({ title: "Error sending reply", variant: "destructive" });
    }
    setSendingReply(false);
  };

  const deleteSubscriber = async (sub) => {
    if (!confirm(`Remove ${sub.email} from subscribers?`)) return;
    await base44.entities.Subscriber.update(sub.id, { is_active: false });
    toast({ title: "Subscriber removed" });
    await loadData();
  };

  const unreadCount = messages.filter(m => !m.is_read).length;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar currentPage="AdminMarketing" />
      
      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b px-4 md:px-8 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <AdminSidebar mobile currentPage="AdminMarketing" />
                </SheetContent>
              </Sheet>
              <h1 className="text-xl font-bold">Marketing & Messages</h1>
            </div>
          </div>
        </header>

        <main className="p-4 md:p-8">
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Users className="w-8 h-8 text-[#d4a853]" />
                  <div>
                    <p className="text-2xl font-bold">{subscribers.length}</p>
                    <p className="text-sm text-gray-500">Subscribers</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <MessageSquare className="w-8 h-8 text-blue-500" />
                  <div>
                    <p className="text-2xl font-bold">{messages.length}</p>
                    <p className="text-sm text-gray-500">Total Messages</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Mail className="w-8 h-8 text-red-500" />
                  <div>
                    <p className="text-2xl font-bold">{unreadCount}</p>
                    <p className="text-sm text-gray-500">Unread Messages</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-8 h-8 text-green-500" />
                  <div>
                    <p className="text-2xl font-bold">{messages.filter(m => m.is_replied).length}</p>
                    <p className="text-sm text-gray-500">Replied</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="email" className="space-y-6">
            <TabsList>
              <TabsTrigger value="email">Send Email</TabsTrigger>
              <TabsTrigger value="subscribers">Subscribers</TabsTrigger>
              <TabsTrigger value="messages" className="relative">
                Messages
                {unreadCount > 0 && (
                  <Badge className="ml-2 bg-red-500 text-white">{unreadCount}</Badge>
                )}
              </TabsTrigger>
            </TabsList>

            {/* Send Email Tab */}
            <TabsContent value="email">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="w-5 h-5" />
                    Send Bulk Email to {subscribers.length} Subscribers
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <Label>Email Template</Label>
                    <Select value={selectedTemplate} onValueChange={handleTemplateChange}>
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {emailTemplates.map(t => (
                          <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Subject</Label>
                    <Input
                      value={emailSubject}
                      onChange={(e) => setEmailSubject(e.target.value)}
                      placeholder="Email subject line"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label>Email Content</Label>
                    <Textarea
                      value={emailContent}
                      onChange={(e) => setEmailContent(e.target.value)}
                      placeholder="Write your email content here..."
                      rows={12}
                      className="mt-1 font-mono text-sm"
                    />
                  </div>

                  <div className="flex gap-4">
                    <Button
                      onClick={sendBulkEmail}
                      disabled={sending || subscribers.length === 0}
                      className="bg-[#d4a853] hover:bg-[#c49743] text-black"
                    >
                      {sending ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin mr-2" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Send to All Subscribers
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Subscribers Tab */}
            <TabsContent value="subscribers">
              <Card>
                <CardHeader>
                  <CardTitle>Newsletter Subscribers ({subscribers.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Email</TableHead>
                        <TableHead>Subscribed Date</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {subscribers.map(sub => (
                        <TableRow key={sub.id}>
                          <TableCell className="font-medium">{sub.email}</TableCell>
                          <TableCell>
                            {sub.subscribed_date 
                              ? format(new Date(sub.subscribed_date), "MMM d, yyyy")
                              : format(new Date(sub.created_date), "MMM d, yyyy")
                            }
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="icon" onClick={() => deleteSubscriber(sub)}>
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  {subscribers.length === 0 && (
                    <p className="text-center py-8 text-gray-500">No subscribers yet</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Messages Tab */}
            <TabsContent value="messages">
              <Card>
                <CardHeader>
                  <CardTitle>Contact Messages</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>From</TableHead>
                        <TableHead>Subject</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {messages.map(msg => (
                        <TableRow key={msg.id} className={!msg.is_read ? "bg-blue-50" : ""}>
                          <TableCell>
                            <p className="font-medium">{msg.name}</p>
                            <p className="text-xs text-gray-500">{msg.email}</p>
                          </TableCell>
                          <TableCell>{msg.subject || "No subject"}</TableCell>
                          <TableCell>
                            {format(new Date(msg.created_date), "MMM d, yyyy h:mm a")}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              {!msg.is_read && (
                                <Badge className="bg-blue-100 text-blue-800">New</Badge>
                              )}
                              {msg.is_replied && (
                                <Badge className="bg-green-100 text-green-800">Replied</Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="icon" onClick={() => viewMessage(msg)}>
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => deleteMessage(msg)}>
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  {messages.length === 0 && (
                    <p className="text-center py-8 text-gray-500">No messages yet</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>

      {/* Message Dialog */}
      <Dialog open={showMessageDialog} onOpenChange={setShowMessageDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Message from {selectedMessage?.name}</DialogTitle>
          </DialogHeader>

          {selectedMessage && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-500">Email:</span>
                  <p className="font-medium">{selectedMessage.email}</p>
                </div>
                <div>
                  <span className="text-gray-500">Phone:</span>
                  <p className="font-medium">{selectedMessage.phone || "Not provided"}</p>
                </div>
                <div>
                  <span className="text-gray-500">Subject:</span>
                  <p className="font-medium">{selectedMessage.subject || "No subject"}</p>
                </div>
                <div>
                  <span className="text-gray-500">Date:</span>
                  <p className="font-medium">
                    {format(new Date(selectedMessage.created_date), "MMM d, yyyy h:mm a")}
                  </p>
                </div>
              </div>

              <div>
                <span className="text-gray-500 text-sm">Message:</span>
                <div className="mt-2 p-4 bg-gray-50 rounded whitespace-pre-wrap">
                  {selectedMessage.message}
                </div>
              </div>

              <div className="border-t pt-4">
                <Label>Reply to {selectedMessage.name}</Label>
                <Textarea
                  value={replyContent}
                  onChange={(e) => setReplyContent(e.target.value)}
                  placeholder="Write your reply here..."
                  rows={5}
                  className="mt-2"
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowMessageDialog(false)}>
              Close
            </Button>
            <Button 
              onClick={sendReply}
              disabled={sendingReply}
              className="bg-[#d4a853] hover:bg-[#c49743] text-black"
            >
              {sendingReply ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <Reply className="w-4 h-4 mr-2" />
              )}
              Send Reply
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}