import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  MapPin, Phone, Mail, Clock, Send, 
  Facebook, Instagram, MessageCircle, Loader2
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";


export default function Contact() {
  const { data: siteSettings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const settings = await base44.entities.SiteSettings.filter({ key: "main" });
      return settings[0] || null;
    },
    staleTime: 2 * 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const settings = siteSettings || {
    phone: "+880 1XXX-XXXXXX",
    email: "info@blackzy.com",
    address: "Dhaka, Bangladesh",
    working_hours: "Sat-Thu: 10AM - 8PM",
    whatsapp_number: "8801XXXXXXXXX",
    facebook_url: "",
    instagram_url: ""
  };
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: ""
  });
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }
    
    setSubmitting(true);
    try {
      // Save message to database
      await base44.entities.ContactMessage.create({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        subject: formData.subject,
        message: formData.message,
        is_read: false,
        is_replied: false
      });
      
      toast({
        title: "Message sent successfully!",
        description: "We'll get back to you within 24 hours."
      });
      
      setFormData({
        name: "",
        email: "",
        phone: "",
        subject: "",
        message: ""
      });
    } catch (e) {
      toast({
        title: "Error sending message",
        variant: "destructive"
      });
    }
    setSubmitting(false);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="bg-[#0a0a0a] py-16 px-4">
        <div className="max-w-7xl mx-auto text-center text-white">
          <span className="text-[#d4a853] text-sm tracking-[0.3em] uppercase font-body">
            Get in Touch
          </span>
          <h1 className="font-display text-4xl md:text-5xl mt-3 mb-4">Contact Us</h1>
          <p className="text-gray-400 font-body max-w-xl mx-auto">
            Have questions? We'd love to hear from you. Send us a message and we'll respond as soon as possible.
          </p>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Contact Info */}
            <div className="lg:col-span-1 space-y-8">
              <div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#d4a853] flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5 text-black" />
                  </div>
                  <div>
                    <h3 className="font-display text-lg mb-2">Visit Us</h3>
                    <p className="text-gray-600 font-body text-sm">
                      {settings.address}
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#d4a853] flex items-center justify-center flex-shrink-0">
                    <Phone className="w-5 h-5 text-black" />
                  </div>
                  <div>
                    <h3 className="font-display text-lg mb-2">Call Us</h3>
                    <p className="text-gray-600 font-body text-sm">
                      {settings.phone}
                    </p>
                    <a 
                      href={`https://wa.me/${settings.whatsapp_number}`}
                      className="text-[#25D366] text-sm font-body flex items-center gap-1 mt-1 hover:underline"
                    >
                      <MessageCircle className="w-4 h-4" />
                      WhatsApp Available
                    </a>
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#d4a853] flex items-center justify-center flex-shrink-0">
                    <Mail className="w-5 h-5 text-black" />
                  </div>
                  <div>
                    <h3 className="font-display text-lg mb-2">Email Us</h3>
                    <p className="text-gray-600 font-body text-sm">
                      {settings.email}
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#d4a853] flex items-center justify-center flex-shrink-0">
                    <Clock className="w-5 h-5 text-black" />
                  </div>
                  <div>
                    <h3 className="font-display text-lg mb-2">Business Hours</h3>
                    <p className="text-gray-600 font-body text-sm">
                      {settings.working_hours}
                    </p>
                  </div>
                </div>
              </div>

              {/* Social Links */}
              <div className="pt-8 border-t">
                <h3 className="font-display text-lg mb-4">Follow Us</h3>
                <div className="flex gap-3">
                  <a 
                    href={settings.facebook_url || "#"} 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 bg-[#0a0a0a] flex items-center justify-center text-white hover:bg-[#d4a853] hover:text-black"
                  >
                    <Facebook className="w-5 h-5" />
                  </a>
                  <a 
                    href={settings.instagram_url || "#"} 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 bg-[#0a0a0a] flex items-center justify-center text-white hover:bg-[#d4a853] hover:text-black"
                  >
                    <Instagram className="w-5 h-5" />
                  </a>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <div className="bg-white p-8 shadow-sm">
                <h2 className="font-display text-2xl mb-6">Send us a Message</h2>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label className="font-body text-sm">Name *</Label>
                      <Input
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="rounded-none mt-1"
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <Label className="font-body text-sm">Email *</Label>
                      <Input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="rounded-none mt-1"
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label className="font-body text-sm">Phone</Label>
                      <Input
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="rounded-none mt-1"
                        placeholder="01XXXXXXXXX"
                      />
                    </div>
                    <div>
                      <Label className="font-body text-sm">Subject</Label>
                      <Input
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        className="rounded-none mt-1"
                        placeholder="What's this about?"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label className="font-body text-sm">Message *</Label>
                    <Textarea
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="rounded-none mt-1"
                      placeholder="How can we help you?"
                      rows={6}
                    />
                  </div>
                  
                  <Button 
                    type="submit"
                    disabled={submitting}
                    className="bg-[#d4a853] hover:bg-[#c49743] text-black px-8 rounded-none"
                  >
                    {submitting ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    ) : (
                      <Send className="w-4 h-4 mr-2" />
                    )}
                    Send Message
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map Placeholder */}
      <section className="h-[400px] bg-gray-200 relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <MapPin className="w-12 h-12 text-[#d4a853] mx-auto mb-4" />
            <p className="font-display text-xl">{settings.address}</p>
            <p className="text-gray-500 font-body text-sm mt-2">
              Visit our showroom for the full experience
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}