import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ArrowRight, Heart, Award, Users, Truck, Loader2 } from "lucide-react";


const LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_68efc8686692d4a66165643e/68ce1934a_500199112_122159999006541940_8065689141022182336_n.jpg";

export default function About() {
  const { data: siteSettings, isLoading } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const settings = await base44.entities.SiteSettings.filter({ key: "main" });
      return settings[0] || null;
    },
    staleTime: 2 * 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const s = siteSettings || {
    about_hero_subtitle: "Our Story",
    about_hero_title: "About Blackzy Fashion",
    about_hero_description: "Celebrating the rich heritage of Bengali textiles with modern elegance",
    about_established_year: "Est. 2020",
    about_story_paragraph1: "Blackzy Fashion was born from a passion to bring the finest Bengali traditional fabrics to the modern woman. What started as a small venture has grown into a trusted brand with over 20,000 followers and more than 1,000 satisfied customers.",
    about_story_paragraph2: "We specialize in premium AC Cotton, authentic Block Prints, and traditional Gojkapor sarees - each piece carefully selected to ensure the highest quality. Our commitment to authenticity means every fabric tells a story of Bengali craftsmanship.",
    about_story_paragraph3: "From our humble beginnings on Facebook to becoming one of the most trusted names in traditional Bengali fashion, we continue to serve customers with dedication, quality, and love for our cultural heritage.",
    about_stat_followers: "20K+",
    about_stat_reviews: "1,020+",
    about_stat_rating: "100%",
    about_stat_orders: "5000+"
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[60vh] overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ 
            backgroundImage: "url(https://images.unsplash.com/photo-1558171813-4c088753af8f?w=1600&auto=format)"
          }}
        />
        <div className="absolute inset-0 bg-black/70" />
        <div className="relative h-full flex items-center justify-center text-center px-4">
          <div>
            <span className="text-[#d4a853] text-sm tracking-[0.3em] uppercase font-body">
              {s.about_hero_subtitle}
            </span>
            <h1 className="font-display text-5xl md:text-7xl text-white mt-4 mb-6">
              {s.about_hero_title}
            </h1>
            <p className="text-gray-300 font-body text-lg max-w-2xl mx-auto">
              {s.about_hero_description}
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src={LOGO_URL}
                alt="Blackzy Fashion"
                loading="lazy"
                decoding="async"
                className="w-full max-w-md mx-auto"
              />
            </div>
            <div>
              <span className="text-[#d4a853] text-sm tracking-[0.3em] uppercase font-body">
                {s.about_established_year}
              </span>
              <h2 className="font-display text-4xl mt-3 mb-6">Our Journey</h2>
              <p className="text-gray-600 font-body leading-relaxed mb-6">
                {s.about_story_paragraph1}
              </p>
              <p className="text-gray-600 font-body leading-relaxed mb-6">
                {s.about_story_paragraph2}
              </p>
              <p className="text-gray-600 font-body leading-relaxed">
                {s.about_story_paragraph3}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-[#0a0a0a] text-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#d4a853] text-sm tracking-[0.3em] uppercase font-body">
              What We Stand For
            </span>
            <h2 className="font-display text-4xl mt-3">Our Values</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: Heart,
                title: "Authenticity",
                description: "100% genuine fabrics sourced directly from trusted artisans and weavers."
              },
              {
                icon: Award,
                title: "Quality",
                description: "Every piece undergoes strict quality checks before reaching our customers."
              },
              {
                icon: Users,
                title: "Customer First",
                description: "Your satisfaction is our priority. We're here to help you find the perfect piece."
              },
              {
                icon: Truck,
                title: "Reliability",
                description: "Fast, secure delivery across Bangladesh with careful packaging."
              }
            ].map((value, index) => (
              <div
                key={index}
                className="text-center"
              >
                <div className="w-16 h-16 bg-[#d4a853] rounded-full flex items-center justify-center mx-auto mb-4">
                  <value.icon className="w-7 h-7 text-black" />
                </div>
                <h3 className="font-display text-xl mb-3">{value.title}</h3>
                <p className="text-gray-400 font-body text-sm">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { number: s.about_stat_followers, label: "Facebook Followers" },
              { number: s.about_stat_reviews, label: "5-Star Reviews" },
              { number: s.about_stat_rating, label: "Customer Rating" },
              { number: s.about_stat_orders, label: "Orders Delivered" }
            ].map((stat, index) => (
              <div key={index}>
                <p className="font-display text-5xl text-[#d4a853]">{stat.number}</p>
                <p className="text-gray-600 font-body mt-2">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-[#faf8f5]">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="font-display text-4xl mb-6">
            Experience the Blackzy Difference
          </h2>
          <p className="text-gray-600 font-body mb-8">
            Browse our curated collection of premium Bengali fabrics and find your perfect piece today.
          </p>
          <Link to={createPageUrl("Shop")}>
            <Button 
              size="lg" 
              className="bg-[#d4a853] hover:bg-[#c49743] text-black px-10 rounded-none"
            >
              Shop Now
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}