import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Loader2, Plus, Pencil, Trash2, HelpCircle, Menu
} from "lucide-react";
import AdminSidebar from "../components/admin/AdminSidebar";

const categoryLabels = {
  orders_shipping: "Orders & Shipping",
  returns_refunds: "Returns & Refunds",
  products_fabrics: "Products & Fabrics",
  payments: "Payments",
  account_orders: "Account & Orders"
};

export default function AdminFAQ() {
  const [faqs, setFaqs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    category: "orders_shipping",
    question: "",
    answer: "",
    is_active: true,
    sort_order: 0
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) { base44.auth.redirectToLogin(); return; }
      const user = await base44.auth.me();
      if (user.role !== "admin") { window.location.href = createPageUrl("Home"); return; }

      const items = await base44.entities.FAQItem.list("sort_order");
      setFaqs(items);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!formData.question || !formData.answer) {
      toast({ title: "Question and answer are required", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      if (editing) {
        await base44.entities.FAQItem.update(editing.id, formData);
        toast({ title: "FAQ updated" });
      } else {
        await base44.entities.FAQItem.create(formData);
        toast({ title: "FAQ created" });
      }
      setDialogOpen(false);
      loadData();
    } catch (err) {
      toast({ title: "Error saving", variant: "destructive" });
    }
    setSaving(false);
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this FAQ?")) return;
    await base44.entities.FAQItem.delete(id);
    loadData();
    toast({ title: "FAQ deleted" });
  };

  const openDialog = (item = null) => {
    if (item) {
      setEditing(item);
      setFormData({
        category: item.category || "orders_shipping",
        question: item.question || "",
        answer: item.answer || "",
        is_active: item.is_active !== false,
        sort_order: item.sort_order || 0
      });
    } else {
      setEditing(null);
      setFormData({ 
        category: "orders_shipping", 
        question: "", 
        answer: "", 
        is_active: true, 
        sort_order: faqs.length 
      });
    }
    setDialogOpen(true);
  };

  // Group by category
  const groupedFAQs = faqs.reduce((acc, item) => {
    const cat = item.category || "orders_shipping";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(item);
    return acc;
  }, {});

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar currentPage="AdminFAQ" />

      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b px-4 md:px-8 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <AdminSidebar mobile currentPage="AdminFAQ" />
                </SheetContent>
              </Sheet>
              <h1 className="text-xl font-bold">FAQ Management</h1>
            </div>
            
            <Button onClick={() => openDialog()} className="bg-[#d4a853] hover:bg-[#c49743] text-black">
              <Plus className="w-4 h-4 mr-2" />
              Add FAQ
            </Button>
          </div>
        </header>

        <main className="p-4 md:p-8">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="p-6">
                <p className="text-sm text-gray-500">Total FAQs</p>
                <p className="text-2xl font-bold">{faqs.length}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <p className="text-sm text-gray-500">Categories</p>
                <p className="text-2xl font-bold">{Object.keys(groupedFAQs).length}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <p className="text-sm text-gray-500">Active</p>
                <p className="text-2xl font-bold">{faqs.filter(f => f.is_active).length}</p>
              </CardContent>
            </Card>
          </div>

          {/* FAQs by Category */}
          <div className="space-y-6">
            {Object.entries(categoryLabels).map(([catKey, catLabel]) => {
              const items = groupedFAQs[catKey] || [];
              if (items.length === 0) return null;
              
              return (
                <Card key={catKey}>
                  <CardContent className="p-6">
                    <h2 className="font-bold text-lg mb-4 flex items-center gap-2">
                      <HelpCircle className="w-5 h-5 text-[#d4a853]" />
                      {catLabel}
                      <Badge variant="outline" className="ml-2">{items.length}</Badge>
                    </h2>
                    <div className="space-y-3">
                      {items.map((item) => (
                        <div key={item.id} className="flex items-start justify-between p-4 bg-gray-50 rounded-lg">
                          <div className="flex-1">
                            <h3 className="font-medium">{item.question}</h3>
                            <p className="text-gray-600 text-sm mt-1 line-clamp-2">{item.answer}</p>
                          </div>
                          <div className="flex items-center gap-2 ml-4">
                            <Badge className={item.is_active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}>
                              {item.is_active ? "Active" : "Inactive"}
                            </Badge>
                            <Button variant="ghost" size="icon" onClick={() => openDialog(item)}>
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDelete(item.id)}>
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })}

            {faqs.length === 0 && (
              <div className="text-center py-12 bg-white rounded-lg">
                <HelpCircle className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500">No FAQs yet</p>
                <Button onClick={() => openDialog()} className="mt-4 bg-[#d4a853] hover:bg-[#c49743] text-black">
                  <Plus className="w-4 h-4 mr-2" />
                  Add First FAQ
                </Button>
              </div>
            )}
          </div>
        </main>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit FAQ" : "Add FAQ"}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label>Category</Label>
              <Select value={formData.category} onValueChange={(v) => setFormData({...formData, category: v})}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(categoryLabels).map(([key, label]) => (
                    <SelectItem key={key} value={key}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Question *</Label>
              <Input 
                value={formData.question} 
                onChange={(e) => setFormData({...formData, question: e.target.value})} 
                className="mt-1"
                placeholder="What is your question?"
              />
            </div>

            <div>
              <Label>Answer *</Label>
              <Textarea 
                value={formData.answer} 
                onChange={(e) => setFormData({...formData, answer: e.target.value})} 
                className="mt-1" 
                rows={4}
                placeholder="Provide the answer..."
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Sort Order</Label>
                <Input 
                  type="number" 
                  value={formData.sort_order} 
                  onChange={(e) => setFormData({...formData, sort_order: Number(e.target.value)})} 
                  className="mt-1" 
                />
              </div>
              <div className="flex items-center gap-2 pt-6">
                <Switch 
                  checked={formData.is_active} 
                  onCheckedChange={(v) => setFormData({...formData, is_active: v})} 
                />
                <Label>Active</Label>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button 
              onClick={handleSubmit} 
              disabled={saving} 
              className="bg-[#d4a853] hover:bg-[#c49743] text-black"
            >
              {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              {editing ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}