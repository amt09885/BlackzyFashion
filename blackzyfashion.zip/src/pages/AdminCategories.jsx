import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { 
  Plus, Edit, Trash2, Tag, 
  Menu, Loader2, Upload
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useToast } from "@/components/ui/use-toast";

import AdminSidebar from "../components/admin/AdminSidebar";

export default function AdminCategories() {
  const [loading, setLoading] = useState(true);
  const [categories, setCategories] = useState([]);
  const [showDialog, setShowDialog] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    name: "",
    name_bn: "",
    slug: "",
    description: "",
    image_url: "",
    is_featured: false,
    is_active: true,
    sort_order: 0
  });

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      
      const userData = await base44.auth.me();
      if (userData.role !== "admin") {
        window.location.href = createPageUrl("Home");
        return;
      }
      
      await loadCategories();
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const loadCategories = async () => {
    try {
      const data = await base44.entities.Category.list("sort_order", 100);
      setCategories(data);
    } catch (e) {
      console.error("Error loading categories:", e);
    }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({ ...prev, image_url: file_url }));
    } catch (e) {
      toast({ title: "Error uploading image", variant: "destructive" });
    }
    setUploading(false);
  };

  const openAddDialog = () => {
    setEditingCategory(null);
    setFormData({
      name: "",
      name_bn: "",
      slug: "",
      description: "",
      image_url: "",
      is_featured: false,
      is_active: true,
      sort_order: categories.length
    });
    setShowDialog(true);
  };

  const openEditDialog = (category) => {
    setEditingCategory(category);
    setFormData({
      name: category.name || "",
      name_bn: category.name_bn || "",
      slug: category.slug || "",
      description: category.description || "",
      image_url: category.image_url || "",
      is_featured: category.is_featured || false,
      is_active: category.is_active !== false,
      sort_order: category.sort_order || 0
    });
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!formData.name) {
      toast({ title: "Please enter a category name", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      const slug = formData.slug || formData.name.toLowerCase().replace(/\s+/g, "-");
      const dataToSave = { ...formData, slug };

      if (editingCategory) {
        await base44.entities.Category.update(editingCategory.id, dataToSave);
        toast({ title: "Category updated!" });
      } else {
        await base44.entities.Category.create(dataToSave);
        toast({ title: "Category created!" });
      }

      // Invalidate categories cache to update frontend
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      
      setShowDialog(false);
      await loadCategories();
    } catch (e) {
      toast({ title: "Error saving category", variant: "destructive" });
    }
    setSaving(false);
  };

  const handleDelete = async (category) => {
    if (!confirm(`Delete "${category.name}"?`)) return;
    
    try {
      await base44.entities.Category.delete(category.id);
      toast({ title: "Category deleted" });
      
      // Invalidate categories cache to update frontend
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      
      await loadCategories();
    } catch (e) {
      toast({ title: "Error deleting category", variant: "destructive" });
    }
  };



  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar currentPage="AdminCategories" />
      
      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b px-4 md:px-8 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <AdminSidebar mobile currentPage="AdminCategories" />
                </SheetContent>
              </Sheet>
              <h1 className="text-xl font-bold">Categories</h1>
            </div>
            
            <Button onClick={openAddDialog} className="bg-[#d4a853] hover:bg-[#c49743] text-black">
              <Plus className="w-4 h-4 mr-2" />
              Add Category
            </Button>
          </div>
        </header>

        <main className="p-4 md:p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map(category => (
              <Card key={category.id} className="overflow-hidden">
                <div className="aspect-video bg-gray-100 relative">
                  {category.image_url ? (
                    <img 
                      src={category.image_url}
                      alt={category.name}
                      loading="lazy"
                      decoding="async"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Tag className="w-12 h-12 text-gray-300" />
                    </div>
                  )}
                  {category.is_featured && (
                    <span className="absolute top-2 right-2 bg-[#d4a853] text-black text-xs px-2 py-1">
                      Featured
                    </span>
                  )}
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">{category.name}</h3>
                      {category.name_bn && (
                        <p className="text-sm text-gray-500">{category.name_bn}</p>
                      )}
                      <span className={`text-xs ${category.is_active ? "text-green-600" : "text-gray-400"}`}>
                        {category.is_active ? "Active" : "Inactive"}
                      </span>
                    </div>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" onClick={() => openEditDialog(category)}>
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDelete(category)}>
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {categories.length === 0 && (
            <div className="text-center py-20 bg-white rounded-lg">
              <Tag className="w-12 h-12 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500">No categories yet</p>
              <Button onClick={openAddDialog} className="mt-4 bg-[#d4a853] hover:bg-[#c49743] text-black">
                <Plus className="w-4 h-4 mr-2" />
                Add First Category
              </Button>
            </div>
          )}
        </main>
      </div>

      {/* Add/Edit Category Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingCategory ? "Edit Category" : "Add Category"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Image */}
            <div>
              <Label>Category Image</Label>
              <div className="mt-2">
                {formData.image_url ? (
                  <div className="relative aspect-video bg-gray-100 rounded overflow-hidden">
                    <img 
                      src={formData.image_url}
                      alt=""
                      loading="lazy"
                      decoding="async"
                      className="w-full h-full object-cover"
                    />
                    <Button
                      variant="destructive"
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={() => setFormData({ ...formData, image_url: "" })}
                    >
                      Remove
                    </Button>
                  </div>
                ) : (
                  <label className="aspect-video border-2 border-dashed rounded flex items-center justify-center cursor-pointer hover:border-[#d4a853]">
                    {uploading ? (
                      <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
                    ) : (
                      <div className="text-center">
                        <Upload className="w-8 h-8 mx-auto text-gray-400" />
                        <p className="text-sm text-gray-500 mt-2">Upload image</p>
                      </div>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                )}
              </div>
            </div>

            <div>
              <Label>Name (English) *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="AC Cotton"
              />
            </div>

            <div>
              <Label>Name (Bengali)</Label>
              <Input
                value={formData.name_bn}
                onChange={(e) => setFormData({ ...formData, name_bn: e.target.value })}
                placeholder="এসি কটন"
              />
            </div>

            <div>
              <Label>Slug</Label>
              <Input
                value={formData.slug}
                onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                placeholder="ac-cotton (auto-generated if empty)"
              />
            </div>

            <div>
              <Label>Description</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Category description"
                rows={2}
              />
            </div>

            <div className="flex gap-6">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(v) => setFormData({ ...formData, is_active: v })}
                />
                <Label htmlFor="is_active">Active</Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="is_featured"
                  checked={formData.is_featured}
                  onCheckedChange={(v) => setFormData({ ...formData, is_featured: v })}
                />
                <Label htmlFor="is_featured">Featured</Label>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancel</Button>
            <Button 
              onClick={handleSave} 
              disabled={saving}
              className="bg-[#d4a853] hover:bg-[#c49743] text-black"
            >
              {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              {editingCategory ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}