import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  User, Package, Heart, MapPin, 
  Loader2, Save, LogOut, ChevronRight
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";


const divisions = [
  "Dhaka", "Chittagong", "Rajshahi", "Khulna", 
  "Barisal", "Sylhet", "Rangpur", "Mymensingh"
];

export default function Account() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    full_name: "",
    phone: "",
    address_line1: "",
    city: "",
    district: ""
  });
  const { toast } = useToast();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      
      const userData = await base44.auth.me();
      setUser(userData);
      setFormData({
        full_name: userData.full_name || "",
        phone: userData.phone || "",
        address_line1: userData.address_line1 || "",
        city: userData.city || "",
        district: userData.district || ""
      });
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await base44.auth.updateMe(formData);
      toast({ title: "Profile updated successfully!" });
    } catch (e) {
      toast({ title: "Error updating profile", variant: "destructive" });
    }
    setSaving(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#fafafa]">
      {/* Header */}
      <div className="bg-[#0a0a0a] py-16 px-4">
        <div className="max-w-7xl mx-auto text-center text-white">
          <h1 className="font-display text-4xl md:text-5xl mb-4">My Account</h1>
          <p className="text-gray-400 font-body">
            Manage your account and preferences
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Sidebar */}
          <div className="space-y-4">
            <Card className="bg-white">
              <CardContent className="p-6 text-center">
                <div className="w-20 h-20 bg-[#d4a853] rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="font-display text-3xl text-black">
                    {user?.full_name?.[0] || "U"}
                  </span>
                </div>
                <h3 className="font-display text-lg">{user?.full_name}</h3>
                <p className="text-sm text-gray-500 font-body">{user?.email}</p>
              </CardContent>
            </Card>

            <Card className="bg-white">
              <CardContent className="p-0">
                <Link 
                  to={createPageUrl("Orders")}
                  className="flex items-center justify-between p-4 hover:bg-gray-50"
                >
                  <div className="flex items-center gap-3">
                    <Package className="w-5 h-5 text-[#d4a853]" />
                    <span className="font-body">My Orders</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </Link>
                <Link 
                  to={createPageUrl("Wishlist")}
                  className="flex items-center justify-between p-4 hover:bg-gray-50 border-t"
                >
                  <div className="flex items-center gap-3">
                    <Heart className="w-5 h-5 text-[#d4a853]" />
                    <span className="font-body">Wishlist</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </Link>
                <button 
                  onClick={() => base44.auth.logout(createPageUrl("Home"))}
                  className="flex items-center justify-between p-4 hover:bg-gray-50 border-t w-full text-left text-red-500"
                >
                  <div className="flex items-center gap-3">
                    <LogOut className="w-5 h-5" />
                    <span className="font-body">Logout</span>
                  </div>
                </button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="md:col-span-2">
            <div>
              <Card className="bg-white">
                <CardHeader>
                  <CardTitle className="font-display flex items-center gap-2">
                    <User className="w-5 h-5 text-[#d4a853]" />
                    Personal Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="font-body text-sm">Full Name</Label>
                      <Input
                        value={formData.full_name}
                        onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                        className="rounded-none mt-1"
                      />
                    </div>
                    <div>
                      <Label className="font-body text-sm">Email</Label>
                      <Input
                        value={user?.email || ""}
                        disabled
                        className="rounded-none mt-1 bg-gray-50"
                      />
                    </div>
                    <div>
                      <Label className="font-body text-sm">Phone</Label>
                      <Input
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="rounded-none mt-1"
                        placeholder="01XXXXXXXXX"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white mt-6">
                <CardHeader>
                  <CardTitle className="font-display flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-[#d4a853]" />
                    Default Address
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="font-body text-sm">Address</Label>
                    <Input
                      value={formData.address_line1}
                      onChange={(e) => setFormData({ ...formData, address_line1: e.target.value })}
                      className="rounded-none mt-1"
                      placeholder="House/Road/Area"
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="font-body text-sm">City</Label>
                      <Input
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        className="rounded-none mt-1"
                        placeholder="City"
                      />
                    </div>
                    <div>
                      <Label className="font-body text-sm">District</Label>
                      <Select 
                        value={formData.district} 
                        onValueChange={(v) => setFormData({ ...formData, district: v })}
                      >
                        <SelectTrigger className="rounded-none mt-1">
                          <SelectValue placeholder="Select district" />
                        </SelectTrigger>
                        <SelectContent>
                          {divisions.map(div => (
                            <SelectItem key={div} value={div}>{div}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="mt-6">
                <Button 
                  onClick={handleSave}
                  disabled={saving}
                  className="bg-[#d4a853] hover:bg-[#c49743] text-black rounded-none px-8"
                >
                  {saving ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  Save Changes
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}