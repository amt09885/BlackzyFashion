import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Loader2, Plus, Pencil, Trash2, Facebook, Menu, Upload
} from "lucide-react";
import AdminSidebar from "../components/admin/AdminSidebar";

export default function AdminInstagram() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    image_url: "",
    link_url: "",
    is_active: true,
    sort_order: 0
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) { base44.auth.redirectToLogin(); return; }
      const user = await base44.auth.me();
      if (user.role !== "admin") { window.location.href = createPageUrl("Home"); return; }

      const items = await base44.entities.InstagramPost.list("sort_order");
      setPosts(items);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({ ...prev, image_url: file_url }));
    } catch (err) {
      toast({ title: "Error uploading image", variant: "destructive" });
    }
    setUploading(false);
  };

  const handleSubmit = async () => {
    if (!formData.image_url) {
      toast({ title: "Image is required", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      if (editing) {
        await base44.entities.InstagramPost.update(editing.id, formData);
        toast({ title: "Post updated" });
      } else {
        await base44.entities.InstagramPost.create(formData);
        toast({ title: "Post created" });
      }
      queryClient.invalidateQueries({ queryKey: ['instagram-posts'] });
      setDialogOpen(false);
      loadData();
    } catch (err) {
      toast({ title: "Error saving", variant: "destructive" });
    }
    setSaving(false);
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this post?")) return;
    await base44.entities.InstagramPost.delete(id);
    queryClient.invalidateQueries({ queryKey: ['instagram-posts'] });
    loadData();
    toast({ title: "Post deleted" });
  };

  const openDialog = (item = null) => {
    if (item) {
      setEditing(item);
      setFormData({
        image_url: item.image_url || "",
        link_url: item.link_url || "",
        is_active: item.is_active !== false,
        sort_order: item.sort_order || 0
      });
    } else {
      setEditing(null);
      setFormData({ image_url: "", link_url: "", is_active: true, sort_order: posts.length });
    }
    setDialogOpen(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar currentPage="AdminInstagram" />

      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b px-4 md:px-8 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <AdminSidebar mobile currentPage="AdminInstagram" />
                </SheetContent>
              </Sheet>
              <div>
                <h1 className="text-xl font-bold">Facebook Feed</h1>
                <p className="text-sm text-gray-500">Manage posts shown on homepage</p>
              </div>
            </div>
            
            <Button onClick={() => openDialog()} className="bg-[#d4a853] hover:bg-[#c49743] text-black">
              <Plus className="w-4 h-4 mr-2" />
              Add Post
            </Button>
          </div>
        </header>

        <main className="p-4 md:p-8">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="p-6">
                <p className="text-sm text-gray-500">Total Posts</p>
                <p className="text-2xl font-bold">{posts.length}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <p className="text-sm text-gray-500">Active</p>
                <p className="text-2xl font-bold">{posts.filter(p => p.is_active).length}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <p className="text-sm text-gray-500">Showing on Homepage</p>
                <p className="text-2xl font-bold">{Math.min(posts.filter(p => p.is_active).length, 6)}</p>
              </CardContent>
            </Card>
          </div>

          {/* Posts Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {posts.map((item) => (
              <div key={item.id} className="relative group aspect-square bg-gray-100 rounded-lg overflow-hidden">
                <img src={item.image_url} alt="Facebook" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={() => openDialog(item)}>
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={() => handleDelete(item.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                {!item.is_active && (
                  <div className="absolute top-2 right-2 bg-red-500 text-white text-xs px-2 py-1 rounded">Inactive</div>
                )}
                <div className="absolute bottom-2 left-2 bg-black/50 text-white text-xs px-2 py-1 rounded">
                  #{item.sort_order + 1}
                </div>
              </div>
            ))}

            {posts.length === 0 && (
              <div className="col-span-full text-center py-12 bg-white rounded-lg">
                <Facebook className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500">No posts yet</p>
                <Button onClick={() => openDialog()} className="mt-4 bg-[#d4a853] hover:bg-[#c49743] text-black">
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Post
                </Button>
              </div>
            )}
          </div>
        </main>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Post" : "Add Facebook Post"}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Image Upload */}
            <div>
              <Label>Image *</Label>
              <div className="mt-2">
                {formData.image_url ? (
                  <div className="relative aspect-square w-32 rounded overflow-hidden">
                    <img src={formData.image_url} alt="Preview" className="w-full h-full object-cover" />
                    <Button
                      variant="destructive"
                      size="sm"
                      className="absolute top-1 right-1"
                      onClick={() => setFormData({ ...formData, image_url: "" })}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ) : (
                  <label className="aspect-square w-32 border-2 border-dashed rounded flex items-center justify-center cursor-pointer hover:border-[#d4a853] transition-colors">
                    {uploading ? (
                      <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
                    ) : (
                      <div className="text-center">
                        <Upload className="w-6 h-6 mx-auto text-gray-400" />
                        <p className="text-xs text-gray-500 mt-1">Upload</p>
                      </div>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleImageUpload}
                      disabled={uploading}
                    />
                  </label>
                )}
              </div>
              <Input 
                value={formData.image_url} 
                onChange={(e) => setFormData({...formData, image_url: e.target.value})} 
                className="mt-2" 
                placeholder="Or paste image URL"
              />
            </div>

            <div>
              <Label>Link URL (optional)</Label>
              <Input 
                value={formData.link_url} 
                onChange={(e) => setFormData({...formData, link_url: e.target.value})} 
                className="mt-1" 
                placeholder="https://facebook.com/..." 
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Sort Order</Label>
                <Input 
                  type="number" 
                  value={formData.sort_order} 
                  onChange={(e) => setFormData({...formData, sort_order: Number(e.target.value)})} 
                  className="mt-1" 
                />
              </div>
              <div className="flex items-center gap-2 pt-6">
                <Switch 
                  checked={formData.is_active} 
                  onCheckedChange={(v) => setFormData({...formData, is_active: v})} 
                />
                <Label>Active</Label>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button 
              onClick={handleSubmit} 
              disabled={saving} 
              className="bg-[#d4a853] hover:bg-[#c49743] text-black"
            >
              {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              {editing ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}