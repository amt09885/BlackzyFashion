import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function Terms() {
  const { data: pageContent, isLoading } = useQuery({
    queryKey: ['page-content', 'terms_conditions'],
    queryFn: async () => {
      const pages = await base44.entities.PageContent.filter({ page_key: "terms_conditions" });
      return pages[0] || null;
    },
    staleTime: 24 * 60 * 60 * 1000,
    cacheTime: 7 * 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <section className="bg-[#0a0a0a] py-16 px-4">
        <div className="max-w-7xl mx-auto text-center text-white">
          <h1 className="font-display text-4xl md:text-5xl mb-4">
            {pageContent?.title || "Terms & Conditions"}
          </h1>
          <p className="text-gray-400 font-body">
            {pageContent?.subtitle || "Please read these terms carefully before using our services"}
          </p>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          {pageContent?.content ? (
            <div className="prose prose-lg max-w-none font-body">
              <ReactMarkdown>{pageContent.content}</ReactMarkdown>
            </div>
          ) : (
            <div className="space-y-8 font-body text-gray-600">
              <div>
                <h2 className="font-display text-2xl mb-4">1. General Terms</h2>
                <p>By accessing and using Blackzy Fashion website, you accept and agree to be bound by these Terms and Conditions. If you do not agree, please do not use our services.</p>
              </div>

              <div>
                <h2 className="font-display text-2xl mb-4">2. Products & Pricing</h2>
                <ul className="list-disc list-inside space-y-2">
                  <li>All prices are in Bangladeshi Taka (BDT)</li>
                  <li>Prices are subject to change without prior notice</li>
                  <li>Product images are for illustration purposes; actual colors may vary slightly</li>
                  <li>We reserve the right to limit quantities</li>
                </ul>
              </div>

              <div>
                <h2 className="font-display text-2xl mb-4">3. Orders & Payment</h2>
                <ul className="list-disc list-inside space-y-2">
                  <li>Orders are confirmed upon successful payment or COD confirmation</li>
                  <li>We accept bKash, Nagad, and Cash on Delivery</li>
                  <li>We reserve the right to cancel orders due to stock unavailability</li>
                </ul>
              </div>

              <div>
                <h2 className="font-display text-2xl mb-4">4. Shipping & Delivery</h2>
                <p>Delivery times are estimates and may vary. We are not responsible for delays caused by courier services or unforeseen circumstances.</p>
              </div>

              <div>
                <h2 className="font-display text-2xl mb-4">5. Returns & Refunds</h2>
                <p>Please refer to our Return Policy page for detailed information on returns and refunds.</p>
              </div>

              <div>
                <h2 className="font-display text-2xl mb-4">6. Intellectual Property</h2>
                <p>All content on this website, including images, text, and logos, is the property of Blackzy Fashion and may not be used without permission.</p>
              </div>

              <div>
                <h2 className="font-display text-2xl mb-4">7. Contact</h2>
                <p>For any questions regarding these terms, please contact us through our Contact page.</p>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}