import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Package, ShoppingCart, Users, Tag, 
  Image, DollarSign, ShoppingBag,
  Clock, CheckCircle, Truck, XCircle, ArrowUpRight,
  Menu, Loader2
} from "lucide-react";
import { startOfDay } from "date-fns";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";

import AdminSidebar from "../components/admin/AdminSidebar";

export default function AdminDashboard() {
  const [dateRange, setDateRange] = useState("7days");

  const { data: user, isLoading: authLoading } = useQuery({
    queryKey: ['admin-user'],
    queryFn: async () => {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return null;
      }
      const userData = await base44.auth.me();
      if (userData.role !== "admin") {
        window.location.href = createPageUrl("Home");
        return null;
      }
      return userData;
    },
    staleTime: 15 * 60 * 1000,
    cacheTime: 60 * 60 * 1000,
    refetchOnWindowFocus: false,
  });

  const { data: orders = [] } = useQuery({
    queryKey: ['admin-orders'],
    queryFn: () => base44.entities.Order.list("-created_date", 500),
    enabled: !!user,
    staleTime: 5 * 60 * 1000,
    cacheTime: 15 * 60 * 1000,
    refetchOnWindowFocus: false,
  });

  const { data: products = [] } = useQuery({
    queryKey: ['admin-products-count'],
    queryFn: () => base44.entities.Product.filter({ is_active: true }),
    enabled: !!user,
    staleTime: 10 * 60 * 1000,
    cacheTime: 30 * 60 * 1000,
    refetchOnWindowFocus: false,
  });

  const { stats, recentOrders, topProducts } = useMemo(() => {
    if (!orders.length) return { 
      stats: { totalRevenue: 0, totalOrders: 0, pendingOrders: 0, totalProducts: 0, totalCustomers: 0, todayOrders: 0, todayRevenue: 0 },
      recentOrders: [],
      topProducts: []
    };

    const today = startOfDay(new Date());
    const todayOrders = orders.filter(o => new Date(o.created_date) >= today);
    const pendingOrders = orders.filter(o => o.order_status === "pending");
    
    const totalRevenue = orders
      .filter(o => o.order_status !== "cancelled")
      .reduce((sum, o) => sum + (o.total || 0), 0);
    
    const todayRevenue = todayOrders
      .filter(o => o.order_status !== "cancelled")
      .reduce((sum, o) => sum + (o.total || 0), 0);
    
    const uniqueCustomers = [...new Set(orders.map(o => o.customer_email).filter(Boolean))];

    const productSales = {};
    orders.forEach(order => {
      order.items?.forEach(item => {
        if (!productSales[item.product_id]) {
          productSales[item.product_id] = { name: item.product_name, image: item.product_image, sold: 0, revenue: 0 };
        }
        productSales[item.product_id].sold += item.quantity;
        productSales[item.product_id].revenue += item.price * item.quantity;
      });
    });
    
    const sortedProducts = Object.entries(productSales)
      .sort((a, b) => b[1].sold - a[1].sold)
      .slice(0, 5)
      .map(([id, data]) => ({ id, ...data }));

    return {
      stats: {
        totalRevenue,
        totalOrders: orders.length,
        pendingOrders: pendingOrders.length,
        totalProducts: products.length,
        totalCustomers: uniqueCustomers.length,
        todayOrders: todayOrders.length,
        todayRevenue
      },
      recentOrders: orders.slice(0, 5),
      topProducts: sortedProducts
    };
  }, [orders, products]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  if (!user) return null;

  const statusConfig = {
    pending: { color: "bg-yellow-100 text-yellow-800", icon: Clock },
    confirmed: { color: "bg-blue-100 text-blue-800", icon: CheckCircle },
    processing: { color: "bg-indigo-100 text-indigo-800", icon: Package },
    shipped: { color: "bg-purple-100 text-purple-800", icon: Truck },
    delivered: { color: "bg-green-100 text-green-800", icon: CheckCircle },
    cancelled: { color: "bg-red-100 text-red-800", icon: XCircle }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Desktop Sidebar */}
      <AdminSidebar currentPage="AdminDashboard" />
      
      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {/* Top Bar */}
        <header className="bg-white border-b px-4 md:px-8 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {/* Mobile Menu */}
              <Sheet>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <AdminSidebar mobile currentPage="AdminDashboard" />
                </SheetContent>
              </Sheet>
              
              <div>
                <h1 className="text-xl font-bold">Dashboard</h1>
                <p className="text-sm text-gray-500">Welcome back, {user?.full_name}</p>
              </div>
            </div>
            
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-36">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="7days">Last 7 days</SelectItem>
                <SelectItem value="30days">Last 30 days</SelectItem>
                <SelectItem value="all">All time</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </header>

        <main className="p-4 md:p-8">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-green-600" />
                  </div>
                  <Badge className="bg-green-100 text-green-700">
                    <ArrowUpRight className="w-3 h-3 mr-1" />
                    12%
                  </Badge>
                </div>
                <p className="text-sm text-gray-500">Total Revenue</p>
                <p className="text-2xl font-bold">৳{stats.totalRevenue.toLocaleString()}</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <ShoppingBag className="w-6 h-6 text-blue-600" />
                  </div>
                  <span className="text-sm text-gray-500">
                    {stats.todayOrders} today
                  </span>
                </div>
                <p className="text-sm text-gray-500">Total Orders</p>
                <p className="text-2xl font-bold">{stats.totalOrders}</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                    <Clock className="w-6 h-6 text-yellow-600" />
                  </div>
                  <Badge className="bg-yellow-100 text-yellow-700">
                    Needs Action
                  </Badge>
                </div>
                <p className="text-sm text-gray-500">Pending Orders</p>
                <p className="text-2xl font-bold">{stats.pendingOrders}</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
                <p className="text-sm text-gray-500">Total Customers</p>
                <p className="text-2xl font-bold">{stats.totalCustomers}</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Recent Orders */}
            <Card className="lg:col-span-2">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Recent Orders</CardTitle>
                <Link to={createPageUrl("AdminOrders")}>
                  <Button variant="ghost" size="sm">View All</Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentOrders.map((order) => {
                    const status = statusConfig[order.order_status] || statusConfig.pending;
                    return (
                      <div key={order.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                            <Package className="w-5 h-5 text-gray-400" />
                          </div>
                          <div>
                            <p className="font-medium text-sm">#{order.order_number}</p>
                            <p className="text-xs text-gray-500">{order.customer_name}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-sm">৳{order.total?.toLocaleString()}</p>
                          <Badge className={`${status.color} text-xs`}>
                            {order.order_status}
                          </Badge>
                        </div>
                      </div>
                    );
                  })}
                  
                  {recentOrders.length === 0 && (
                    <p className="text-center text-gray-500 py-8">No orders yet</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Top Products */}
            <Card>
              <CardHeader>
                <CardTitle>Top Products</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {topProducts.map((product, index) => (
                    <div key={product.id} className="flex items-center gap-3">
                      <span className="text-sm font-bold text-gray-400 w-4">
                        {index + 1}
                      </span>
                      <div className="w-10 h-10 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                        <img 
                          src={product.image || "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=100"}
                          alt={product.name}
                          loading="lazy"
                          decoding="async"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{product.name}</p>
                        <p className="text-xs text-gray-500">{product.sold} sold</p>
                      </div>
                      <p className="text-sm font-medium">৳{product.revenue.toLocaleString()}</p>
                    </div>
                  ))}
                  
                  {topProducts.length === 0 && (
                    <p className="text-center text-gray-500 py-4">No sales data yet</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            <Link to={createPageUrl("AdminProducts") + "?action=add"}>
              <Card className="hover:shadow-md cursor-pointer">
                <CardContent className="p-6 text-center">
                  <Package className="w-8 h-8 mx-auto mb-3 text-[#d4a853]" />
                  <p className="font-medium">Add Product</p>
                </CardContent>
              </Card>
            </Link>
            <Link to={createPageUrl("AdminOrders")}>
              <Card className="hover:shadow-md cursor-pointer">
                <CardContent className="p-6 text-center">
                  <ShoppingCart className="w-8 h-8 mx-auto mb-3 text-[#d4a853]" />
                  <p className="font-medium">Manage Orders</p>
                </CardContent>
              </Card>
            </Link>
            <Link to={createPageUrl("AdminCategories")}>
              <Card className="hover:shadow-md cursor-pointer">
                <CardContent className="p-6 text-center">
                  <Tag className="w-8 h-8 mx-auto mb-3 text-[#d4a853]" />
                  <p className="font-medium">Categories</p>
                </CardContent>
              </Card>
            </Link>
            <Link to={createPageUrl("AdminBanners")}>
              <Card className="hover:shadow-md cursor-pointer">
                <CardContent className="p-6 text-center">
                  <Image className="w-8 h-8 mx-auto mb-3 text-[#d4a853]" />
                  <p className="font-medium">Banners</p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </main>
      </div>
    </div>
  );
}