import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function PrivacyPolicy() {
  const { data: pageContent, isLoading } = useQuery({
    queryKey: ['page-content', 'privacy_policy'],
    queryFn: async () => {
      const pages = await base44.entities.PageContent.filter({ page_key: "privacy_policy" });
      return pages[0] || null;
    },
    staleTime: 24 * 60 * 60 * 1000,
    cacheTime: 7 * 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <section className="bg-[#0a0a0a] py-16 px-4">
        <div className="max-w-7xl mx-auto text-center text-white">
          <h1 className="font-display text-4xl md:text-5xl mb-4">
            {pageContent?.title || "Privacy Policy"}
          </h1>
          <p className="text-gray-400 font-body">
            {pageContent?.subtitle || "How we collect, use, and protect your information"}
          </p>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          {pageContent?.content ? (
            <div className="prose prose-lg max-w-none font-body">
              <ReactMarkdown>{pageContent.content}</ReactMarkdown>
            </div>
          ) : (
            <div className="space-y-8 font-body text-gray-600">
              <div>
                <h2 className="font-display text-2xl mb-4">Information We Collect</h2>
                <p className="mb-4">We collect information you provide directly to us, including:</p>
                <ul className="list-disc list-inside space-y-2">
                  <li>Name, email address, phone number</li>
                  <li>Shipping and billing address</li>
                  <li>Payment information (processed securely)</li>
                  <li>Order history and preferences</li>
                </ul>
              </div>

              <div>
                <h2 className="font-display text-2xl mb-4">How We Use Your Information</h2>
                <ul className="list-disc list-inside space-y-2">
                  <li>Process and fulfill your orders</li>
                  <li>Send order confirmations and shipping updates</li>
                  <li>Respond to your questions and requests</li>
                  <li>Send promotional offers (with your consent)</li>
                  <li>Improve our services and website</li>
                </ul>
              </div>

              <div>
                <h2 className="font-display text-2xl mb-4">Information Security</h2>
                <p>We implement appropriate security measures to protect your personal information. Payment information is encrypted and processed through secure payment gateways.</p>
              </div>

              <div>
                <h2 className="font-display text-2xl mb-4">Your Rights</h2>
                <p>You can request access to, correction of, or deletion of your personal information by contacting us. You can also opt out of promotional communications at any time.</p>
              </div>

              <div>
                <h2 className="font-display text-2xl mb-4">Contact Us</h2>
                <p>If you have questions about this Privacy Policy, please contact us through our Contact page.</p>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}