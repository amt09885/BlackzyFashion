import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Loader2, Plus, Pencil, Trash2, Star, Menu, Upload
} from "lucide-react";
import AdminSidebar from "../components/admin/AdminSidebar";

export default function AdminTestimonials() {
  const [testimonials, setTestimonials] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    name: "",
    location: "",
    rating: 5,
    comment: "",
    image: "",
    screenshot: "",
    product: "",
    is_active: true,
    sort_order: 0
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) { base44.auth.redirectToLogin(); return; }
      const user = await base44.auth.me();
      if (user.role !== "admin") { window.location.href = createPageUrl("Home"); return; }

      const items = await base44.entities.Testimonial.list("sort_order");
      setTestimonials(items);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = async (e, field = "image") => {
    const file = e.target.files[0];
    if (!file) return;
    
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({ ...prev, [field]: file_url }));
    } catch (err) {
      toast({ title: "Error uploading image", variant: "destructive" });
    }
    setUploading(false);
  };

  const handleSubmit = async () => {
    if (!formData.name || !formData.comment) {
      toast({ title: "Name and comment are required", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      if (editing) {
        await base44.entities.Testimonial.update(editing.id, formData);
        toast({ title: "Testimonial updated" });
      } else {
        await base44.entities.Testimonial.create(formData);
        toast({ title: "Testimonial created" });
      }
      queryClient.invalidateQueries({ queryKey: ['testimonials'] });
      setDialogOpen(false);
      loadData();
    } catch (err) {
      toast({ title: "Error saving", variant: "destructive" });
    }
    setSaving(false);
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this testimonial?")) return;
    await base44.entities.Testimonial.delete(id);
    queryClient.invalidateQueries({ queryKey: ['testimonials'] });
    loadData();
    toast({ title: "Testimonial deleted" });
  };

  const openDialog = (item = null) => {
    if (item) {
      setEditing(item);
      setFormData({
        name: item.name || "",
        location: item.location || "",
        rating: item.rating || 5,
        comment: item.comment || "",
        image: item.image || "",
        screenshot: item.screenshot || "",
        product: item.product || "",
        is_active: item.is_active !== false,
        sort_order: item.sort_order || 0
      });
    } else {
      setEditing(null);
      setFormData({
        name: "", location: "", rating: 5, comment: "", image: "", screenshot: "", product: "", is_active: true, sort_order: testimonials.length
      });
    }
    setDialogOpen(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar currentPage="AdminTestimonials" />

      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b px-4 md:px-8 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <AdminSidebar mobile currentPage="AdminTestimonials" />
                </SheetContent>
              </Sheet>
              <h1 className="text-xl font-bold">Testimonials</h1>
            </div>
            
            <Button onClick={() => openDialog()} className="bg-[#d4a853] hover:bg-[#c49743] text-black">
              <Plus className="w-4 h-4 mr-2" />
              Add Testimonial
            </Button>
          </div>
        </header>

        <main className="p-4 md:p-8">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="p-6">
                <p className="text-sm text-gray-500">Total Testimonials</p>
                <p className="text-2xl font-bold">{testimonials.length}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <p className="text-sm text-gray-500">Active</p>
                <p className="text-2xl font-bold">{testimonials.filter(t => t.is_active).length}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <p className="text-sm text-gray-500">Avg Rating</p>
                <p className="text-2xl font-bold flex items-center gap-1">
                  {testimonials.length > 0 
                    ? (testimonials.reduce((sum, t) => sum + (t.rating || 5), 0) / testimonials.length).toFixed(1)
                    : "0"
                  }
                  <Star className="w-5 h-5 fill-[#d4a853] text-[#d4a853]" />
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Testimonials Grid */}
          <div className="grid gap-4">
            {testimonials.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-6 flex items-start gap-4">
                  <img 
                    src={item.image || "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100"} 
                    alt={item.name} 
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-medium text-lg">{item.name}</h3>
                      {item.location && <span className="text-sm text-gray-500">• {item.location}</span>}
                      <div className="flex">
                        {[...Array(item.rating || 5)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-[#d4a853] text-[#d4a853]" />
                        ))}
                      </div>
                    </div>
                    <p className="text-gray-600 text-sm mb-2">"{item.comment}"</p>
                    {item.product && <span className="text-xs text-[#d4a853]">Product: {item.product}</span>}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-1 text-xs rounded ${item.is_active ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}`}>
                      {item.is_active ? "Active" : "Inactive"}
                    </span>
                    <Button variant="ghost" size="icon" onClick={() => openDialog(item)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(item.id)}>
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}

            {testimonials.length === 0 && (
              <div className="text-center py-12 bg-white rounded-lg">
                <Star className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500">No testimonials yet</p>
                <Button onClick={() => openDialog()} className="mt-4 bg-[#d4a853] hover:bg-[#c49743] text-black">
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Testimonial
                </Button>
              </div>
            )}
          </div>
        </main>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Testimonial" : "Add Testimonial"}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Image Upload */}
            <div>
              <Label>Customer Photo</Label>
              <div className="mt-2 flex gap-4 items-center">
                {formData.image && (
                  <img src={formData.image} alt="" className="w-16 h-16 rounded-full object-cover" />
                )}
                <label className="cursor-pointer">
                  <div className="flex items-center gap-2 text-sm text-[#d4a853] hover:underline">
                    <Upload className="w-4 h-4" />
                    {uploading ? "Uploading..." : "Upload photo"}
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleImageUpload(e, "image")}
                    disabled={uploading}
                  />
                </label>
              </div>
            </div>

            {/* Screenshot Upload */}
            <div>
              <Label>Screenshot (Chat/Review Screenshot)</Label>
              <div className="mt-2 space-y-2">
                {formData.screenshot && (
                  <img src={formData.screenshot} alt="" className="w-full max-w-xs h-auto rounded-lg border object-cover" />
                )}
                <label className="cursor-pointer inline-block">
                  <div className="flex items-center gap-2 text-sm text-[#d4a853] hover:underline">
                    <Upload className="w-4 h-4" />
                    {uploading ? "Uploading..." : "Upload screenshot"}
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleImageUpload(e, "screenshot")}
                    disabled={uploading}
                  />
                </label>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Name *</Label>
                <Input 
                  value={formData.name} 
                  onChange={(e) => setFormData({...formData, name: e.target.value})} 
                  className="mt-1" 
                  placeholder="Customer name"
                />
              </div>
              <div>
                <Label>Location</Label>
                <Input 
                  value={formData.location} 
                  onChange={(e) => setFormData({...formData, location: e.target.value})} 
                  className="mt-1" 
                  placeholder="Dhaka, Bangladesh"
                />
              </div>
            </div>

            <div>
              <Label>Comment *</Label>
              <Textarea 
                value={formData.comment} 
                onChange={(e) => setFormData({...formData, comment: e.target.value})} 
                className="mt-1" 
                rows={3}
                placeholder="What did the customer say?"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Product Purchased</Label>
                <Input 
                  value={formData.product} 
                  onChange={(e) => setFormData({...formData, product: e.target.value})} 
                  className="mt-1" 
                  placeholder="AC Cotton Saree"
                />
              </div>
              <div>
                <Label>Rating (1-5)</Label>
                <Input 
                  type="number" 
                  min="1" 
                  max="5" 
                  value={formData.rating} 
                  onChange={(e) => setFormData({...formData, rating: Number(e.target.value)})} 
                  className="mt-1" 
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Sort Order</Label>
                <Input 
                  type="number" 
                  value={formData.sort_order} 
                  onChange={(e) => setFormData({...formData, sort_order: Number(e.target.value)})} 
                  className="mt-1" 
                />
              </div>
              <div className="flex items-center gap-2 pt-6">
                <Switch 
                  checked={formData.is_active} 
                  onCheckedChange={(v) => setFormData({...formData, is_active: v})} 
                />
                <Label>Active</Label>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button 
              onClick={handleSubmit} 
              disabled={saving} 
              className="bg-[#d4a853] hover:bg-[#c49743] text-black"
            >
              {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              {editing ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}