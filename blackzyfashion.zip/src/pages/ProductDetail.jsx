import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Heart, ShoppingBag, Share2, Truck, Shield, RefreshCw,
  Minus, Plus, ChevronLeft, ChevronRight, Star, Check,
  ZoomIn, Loader2, X
} from "lucide-react";

import { useToast } from "@/components/ui/use-toast";
import ProductCard from "../components/products/ProductCard";

export default function ProductDetail() {
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState("");
  const [selectedColor, setSelectedColor] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [relatedProducts, setRelatedProducts] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [zoomOpen, setZoomOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const productId = params.get("id");
    if (productId) {
      loadProduct(productId);
    }
  }, []);

  const loadProduct = async (id) => {
    setLoading(true);
    try {
      const products = await base44.entities.Product.filter({ id: id });
      if (products.length > 0) {
        const prod = products[0];
        setProduct(prod);

        // Track ViewContent event
        if (window.fbq) {
          window.fbq('track', 'ViewContent', {
            content_name: prod.name,
            content_ids: [prod.id],
            content_type: 'product',
            value: prod.sale_price || prod.price,
            currency: 'BDT'
          });
        }
        
        if (prod.sizes?.length > 0) setSelectedSize(prod.sizes[0]);
        if (prod.colors?.length > 0) setSelectedColor(prod.colors[0]);
        
        // Load related products
        const related = await base44.entities.Product.filter({
          category_id: prod.category_id,
          is_active: true
        });
        setRelatedProducts(related.filter(p => p.id !== id).slice(0, 4));
        
        // Load reviews
        const productReviews = await base44.entities.Review.filter({
          product_id: id,
          is_approved: true
        });
        setReviews(productReviews);
        
        // Check wishlist
        const isAuth = await base44.auth.isAuthenticated();
        if (isAuth) {
          const user = await base44.auth.me();
          const wishlist = await base44.entities.Wishlist.filter({
            user_email: user.email,
            product_id: id
          });
          setIsWishlisted(wishlist.length > 0);
        }
      }
    } catch (e) {
      console.error("Error loading product:", e);
    }
    setLoading(false);
  };

  const handleAddToCart = async () => {
    if (!selectedSize && product?.sizes?.length > 0) {
      toast({
        title: "Please select a size",
        variant: "destructive"
      });
      return;
    }

    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      
      const user = await base44.auth.me();
      await base44.entities.CartItem.create({
        user_email: user.email,
        product_id: product.id,
        product_name: product.name,
        product_image: product.images?.[0] || "",
        price: product.sale_price || product.price,
        quantity: quantity,
        size: selectedSize,
        color: selectedColor
      });

      // Track AddToCart event
      if (window.fbq) {
        window.fbq('track', 'AddToCart', {
          content_name: product.name,
          content_ids: [product.id],
          content_type: 'product',
          value: (product.sale_price || product.price) * quantity,
          currency: 'BDT'
        });
      }
      
      toast({
        title: "Added to Cart!",
        description: `${product.name} has been added to your cart.`,
      });
      
      window.location.reload();
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to add item to cart.",
        variant: "destructive"
      });
    }
  };

  const handleBuyNow = async () => {
    if (!selectedSize && product?.sizes?.length > 0) {
      toast({
        title: "Please select a size",
        variant: "destructive"
      });
      return;
    }
    
    // Direct buy without login - redirect to quick checkout
    const params = new URLSearchParams({
      product: product.id,
      qty: quantity.toString(),
      size: selectedSize || "",
      color: selectedColor || ""
    });
    window.location.href = createPageUrl("QuickCheckout") + "?" + params.toString();
  };

  const handleWishlist = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      
      const user = await base44.auth.me();
      
      if (isWishlisted) {
        const wishlist = await base44.entities.Wishlist.filter({
          user_email: user.email,
          product_id: product.id
        });
        if (wishlist.length > 0) {
          await base44.entities.Wishlist.delete(wishlist[0].id);
        }
        setIsWishlisted(false);
        toast({ title: "Removed from Wishlist" });
      } else {
        await base44.entities.Wishlist.create({
          user_email: user.email,
          product_id: product.id,
          product_name: product.name,
          product_image: product.images?.[0] || "",
          product_price: product.sale_price || product.price
        });
        setIsWishlisted(true);
        toast({ title: "Added to Wishlist" });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleShare = async () => {
    try {
      await navigator.share({
        title: product.name,
        text: product.description,
        url: window.location.href
      });
    } catch (err) {
      navigator.clipboard.writeText(window.location.href);
      toast({ title: "Link copied to clipboard!" });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h1 className="font-display text-2xl mb-4">Product Not Found</h1>
        <Link to={createPageUrl("Shop")}>
          <Button className="rounded-none bg-[#0a0a0a]">Back to Shop</Button>
        </Link>
      </div>
    );
  }

  const discount = product.sale_price 
    ? Math.round((1 - product.sale_price / product.price) * 100) 
    : 0;

  return (
    <div className="min-h-screen bg-[#fafafa]">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-2 text-sm font-body text-gray-500">
            <Link to={createPageUrl("Home")} className="hover:text-[#d4a853]">Home</Link>
            <span>/</span>
            <Link to={createPageUrl("Shop")} className="hover:text-[#d4a853]">Shop</Link>
            <span>/</span>
            <span className="text-[#0a0a0a]">{product.name}</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Images */}
          <div className="space-y-4">
            {/* Main Image */}
            <div 
              className="relative aspect-square bg-gray-100 overflow-hidden cursor-zoom-in"
              onClick={() => setZoomOpen(true)}
            >
                <img
                  src={product.images?.[selectedImage] || "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=800"}
                  alt={product.name}
                  width="800"
                  height="800"
                  loading="eager"
                  decoding="async"
                  fetchpriority="high"
                  className="w-full h-full object-cover"
                />
              
              <button className="absolute top-4 right-4 w-10 h-10 bg-white shadow flex items-center justify-center">
                <ZoomIn className="w-5 h-5" />
              </button>
              
              {discount > 0 && (
                <Badge className="absolute top-4 left-4 bg-red-500 text-white rounded-none px-3 py-1">
                  -{discount}% OFF
                </Badge>
              )}
            </div>

            {/* Thumbnails */}
            {product.images && product.images.length > 1 && (
              <div className="flex gap-3 overflow-x-auto pb-2">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`w-20 h-20 flex-shrink-0 border-2 transition-colors ${
                      selectedImage === idx ? "border-[#d4a853]" : "border-transparent"
                    }`}
                  >
                    <img 
                      src={img} 
                      alt={`${product.name} ${idx + 1}`}
                      loading="lazy"
                      decoding="async"
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            {/* Title & Price */}
            <div>
              <span className="text-sm text-[#d4a853] tracking-wider uppercase font-body">
                {product.fabric_type?.replace(/_/g, " ")}
              </span>
              <h1 className="font-display text-3xl md:text-4xl mt-2 text-[#0a0a0a]">
                {product.name}
              </h1>
              
              {/* Rating */}
              {product.review_count > 0 && (
                <div className="flex items-center gap-2 mt-3">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`w-4 h-4 ${
                          i < Math.round(product.average_rating || 0) 
                            ? "fill-[#d4a853] text-[#d4a853]" 
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-500 font-body">
                    ({product.review_count} reviews)
                  </span>
                </div>
              )}
              
              {/* Price */}
              <div className="flex items-center gap-4 mt-4">
                {product.sale_price ? (
                  <>
                    <span className="font-body text-2xl font-bold text-[#0a0a0a]">
                      ৳{product.sale_price.toLocaleString()}
                    </span>
                    <span className="text-lg text-gray-400 line-through font-body">
                      ৳{product.price.toLocaleString()}
                    </span>
                    <Badge className="bg-red-500 text-white rounded-none">
                      Save ৳{(product.price - product.sale_price).toLocaleString()}
                    </Badge>
                  </>
                ) : (
                  <span className="font-body text-2xl font-bold text-[#0a0a0a]">
                    ৳{product.price?.toLocaleString()}
                  </span>
                )}
              </div>
            </div>

            {/* Description */}
            <p className="text-gray-600 font-body leading-relaxed">
              {product.description}
            </p>

            {/* Sizes */}
            {product.sizes && product.sizes.length > 0 && (
              <div>
                <label className="block text-sm font-medium mb-3 font-body">Size</label>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map(size => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`min-w-[60px] h-10 px-4 border text-sm font-body ${
                        selectedSize === size 
                          ? "bg-[#0a0a0a] text-white border-[#0a0a0a]" 
                          : "border-gray-200 hover:border-[#0a0a0a]"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Colors */}
            {product.colors && product.colors.length > 0 && (
              <div>
                <label className="block text-sm font-medium mb-3 font-body">
                  Color: {selectedColor}
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.colors.map(color => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`w-10 h-10 rounded-full border-2 ${
                        selectedColor === color 
                          ? "border-[#0a0a0a] scale-105" 
                          : "border-transparent"
                      }`}
                      style={{ backgroundColor: color }}
                    >
                      {selectedColor === color && (
                        <Check className="w-4 h-4 mx-auto text-white drop-shadow" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity */}
            <div>
              <label className="block text-sm font-medium mb-3 font-body">Quantity</label>
              <div className="flex items-center gap-4">
                <div className="flex border border-gray-200">
                  <button 
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-12 h-12 flex items-center justify-center hover:bg-gray-100"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-16 h-12 flex items-center justify-center border-x border-gray-200 font-body">
                    {quantity}
                  </span>
                  <button 
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-12 h-12 flex items-center justify-center hover:bg-gray-100"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                
                {product.stock_quantity > 0 && product.stock_quantity < 10 && (
                  <span className="text-sm text-red-500 font-body">
                    Only {product.stock_quantity} left!
                  </span>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button 
                onClick={handleAddToCart}
                size="lg"
                className="flex-1 bg-[#0a0a0a] hover:bg-[#d4a853] hover:text-black text-white rounded-none py-6 text-sm tracking-wider"
                disabled={product.stock_quantity === 0}
              >
                <ShoppingBag className="w-5 h-5 mr-2" />
                ADD TO CART
              </Button>
              <Button 
                onClick={handleBuyNow}
                size="lg"
                className="flex-1 bg-[#d4a853] hover:bg-[#c49743] text-black rounded-none py-6 text-sm tracking-wider"
                disabled={product.stock_quantity === 0}
              >
                BUY NOW
              </Button>
            </div>

            {/* Secondary Actions */}
            <div className="flex gap-4 pt-2">
              <button 
                onClick={handleWishlist}
                className={`flex items-center gap-2 text-sm font-body ${
                  isWishlisted ? "text-red-500" : "text-gray-600 hover:text-[#0a0a0a]"
                }`}
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? "fill-current" : ""}`} />
                {isWishlisted ? "Wishlisted" : "Add to Wishlist"}
              </button>
              <button 
                onClick={handleShare}
                className="flex items-center gap-2 text-sm font-body text-gray-600 hover:text-[#0a0a0a]"
              >
                <Share2 className="w-5 h-5" />
                Share
              </button>
            </div>

            {/* Features */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 border-t">
              <div className="flex items-center gap-3">
                <Truck className="w-6 h-6 text-[#d4a853]" />
                <div>
                  <p className="text-sm font-medium font-body">Free Delivery</p>
                  <p className="text-xs text-gray-500">On orders above ৳2000</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Shield className="w-6 h-6 text-[#d4a853]" />
                <div>
                  <p className="text-sm font-medium font-body">100% Authentic</p>
                  <p className="text-xs text-gray-500">Guaranteed quality</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <RefreshCw className="w-6 h-6 text-[#d4a853]" />
                <div>
                  <p className="text-sm font-medium font-body">Easy Returns</p>
                  <p className="text-xs text-gray-500">7-day return policy</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-16">
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="w-full justify-start border-b rounded-none bg-transparent h-auto p-0">
              <TabsTrigger 
                value="description" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#d4a853] data-[state=active]:shadow-none pb-4"
              >
                Description
              </TabsTrigger>
              <TabsTrigger 
                value="specifications" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#d4a853] data-[state=active]:shadow-none pb-4"
              >
                Specifications
              </TabsTrigger>
              <TabsTrigger 
                value="care" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#d4a853] data-[state=active]:shadow-none pb-4"
              >
                Care Instructions
              </TabsTrigger>
              <TabsTrigger 
                value="reviews" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#d4a853] data-[state=active]:shadow-none pb-4"
              >
                Reviews ({reviews.length})
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="description" className="pt-8">
              <div className="prose max-w-none font-body">
                <p className="text-gray-600 leading-relaxed">
                  {product.description || "No description available."}
                </p>
              </div>
            </TabsContent>
            
            <TabsContent value="specifications" className="pt-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex justify-between py-3 border-b">
                    <span className="text-gray-500 font-body">Material</span>
                    <span className="font-medium font-body">{product.material_composition || "N/A"}</span>
                  </div>
                  <div className="flex justify-between py-3 border-b">
                    <span className="text-gray-500 font-body">Fabric Type</span>
                    <span className="font-medium font-body">{product.fabric_type?.replace(/_/g, " ") || "N/A"}</span>
                  </div>
                  <div className="flex justify-between py-3 border-b">
                    <span className="text-gray-500 font-body">SKU</span>
                    <span className="font-medium font-body">{product.sku || "N/A"}</span>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between py-3 border-b">
                    <span className="text-gray-500 font-body">Available Sizes</span>
                    <span className="font-medium font-body">{product.sizes?.join(", ") || "N/A"}</span>
                  </div>
                  <div className="flex justify-between py-3 border-b">
                    <span className="text-gray-500 font-body">Collection</span>
                    <span className="font-medium font-body">{product.collection || "N/A"}</span>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="care" className="pt-8">
              <div className="prose max-w-none font-body">
                <p className="text-gray-600 leading-relaxed">
                  {product.care_instructions || "• Wash with mild detergent\n• Do not bleach\n• Iron on low heat\n• Dry in shade"}
                </p>
              </div>
            </TabsContent>
            
            <TabsContent value="reviews" className="pt-8">
              {reviews.length > 0 ? (
                <div className="space-y-6">
                  {reviews.map(review => (
                    <div key={review.id} className="border-b pb-6">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 bg-[#d4a853] rounded-full flex items-center justify-center text-white font-display">
                          {review.user_name?.[0] || "U"}
                        </div>
                        <div>
                          <p className="font-medium font-body">{review.user_name || "Anonymous"}</p>
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i} 
                                className={`w-3 h-3 ${
                                  i < review.rating 
                                    ? "fill-[#d4a853] text-[#d4a853]" 
                                    : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                      <p className="text-gray-600 font-body">{review.comment}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 font-body">No reviews yet. Be the first to review this product!</p>
              )}
            </TabsContent>
          </Tabs>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-20">
            <h2 className="font-display text-3xl text-center mb-10">You May Also Like</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {relatedProducts.map(prod => (
                <ProductCard key={prod.id} product={prod} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Zoom Modal */}
        {zoomOpen && (
          <div
            className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
            onClick={() => setZoomOpen(false)}
          >
            <button 
              className="absolute top-4 right-4 text-white"
              onClick={() => setZoomOpen(false)}
            >
              <X className="w-8 h-8" />
            </button>
            <img 
              src={product.images?.[selectedImage]}
              alt={product.name}
              loading="lazy"
              decoding="async"
              className="max-w-full max-h-full object-contain"
            />
          </div>
        )}
    </div>
  );
}