import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Heart, ShoppingBag, X, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";


export default function Wishlist() {
  const [wishlist, setWishlist] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadWishlist();
  }, []);

  const loadWishlist = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      
      const user = await base44.auth.me();
      const items = await base44.entities.Wishlist.filter({ user_email: user.email });
      setWishlist(items);
    } catch (e) {
      console.error("Error loading wishlist:", e);
    }
    setLoading(false);
  };

  const removeItem = async (itemId) => {
    try {
      await base44.entities.Wishlist.delete(itemId);
      setWishlist(prev => prev.filter(i => i.id !== itemId));
      toast({ title: "Removed from wishlist" });
    } catch (e) {
      toast({ title: "Error removing item", variant: "destructive" });
    }
  };

  const addToCart = async (item) => {
    try {
      const user = await base44.auth.me();
      await base44.entities.CartItem.create({
        user_email: user.email,
        product_id: item.product_id,
        product_name: item.product_name,
        product_image: item.product_image,
        price: item.product_price,
        quantity: 1
      });
      
      await base44.entities.Wishlist.delete(item.id);
      setWishlist(prev => prev.filter(i => i.id !== item.id));
      
      toast({ title: "Moved to cart!" });
      window.location.reload();
    } catch (e) {
      toast({ title: "Error adding to cart", variant: "destructive" });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#fafafa]">
      {/* Header */}
      <div className="bg-[#0a0a0a] py-16 px-4">
        <div className="max-w-7xl mx-auto text-center text-white">
          <h1 className="font-display text-4xl md:text-5xl mb-4">My Wishlist</h1>
          <p className="text-gray-400 font-body">
            {wishlist.length} {wishlist.length === 1 ? "item" : "items"} saved
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {wishlist.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {wishlist.map((item) => (
                <div
                  key={item.id}
                  className="bg-white group"
                >
                  <div className="relative aspect-[3/4] overflow-hidden">
                    <Link to={createPageUrl("ProductDetail") + `?id=${item.product_id}`}>
                      <img 
                        src={item.product_image || "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=400"}
                        alt={item.product_name}
                        loading="lazy"
                        decoding="async"
                        className="w-full h-full object-cover"
                      />
                    </Link>
                    <button 
                      onClick={() => removeItem(item.id)}
                      className="absolute top-3 right-3 w-8 h-8 bg-white shadow flex items-center justify-center hover:bg-red-500 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <div className="p-4">
                    <Link 
                      to={createPageUrl("ProductDetail") + `?id=${item.product_id}`}
                      className="font-display text-sm hover:text-[#d4a853] line-clamp-2"
                    >
                      {item.product_name}
                    </Link>
                    <p className="font-body font-medium mt-2">
                      ৳{item.product_price?.toLocaleString()}
                    </p>
                    <Button 
                      onClick={() => addToCart(item)}
                      size="sm"
                      className="w-full mt-3 bg-[#0a0a0a] hover:bg-[#d4a853] hover:text-black rounded-none text-xs"
                    >
                      <ShoppingBag className="w-3 h-3 mr-1" />
                      Add to Cart
                    </Button>
                  </div>
                </div>
              ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white">
            <Heart className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h2 className="font-display text-2xl mb-2">Your wishlist is empty</h2>
            <p className="text-gray-500 font-body mb-8">
              Save items you love for later!
            </p>
            <Link to={createPageUrl("Shop")}>
              <Button className="bg-[#0a0a0a] hover:bg-[#d4a853] hover:text-black rounded-none px-8">
                Browse Products
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}