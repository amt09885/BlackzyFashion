import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Package, Plus, Search, Edit, Trash2, 
  Menu, Loader2, Upload, X, Copy, Settings2
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useToast } from "@/components/ui/use-toast";

import AdminSidebar from "../components/admin/AdminSidebar";

const defaultFabricTypes = [
  "ac_cotton", "block_print", "gojkapor", "silk", 
  "muslin", "cotton", "jamdani", "tant", "katan", "other"
];

export default function AdminProducts() {
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [showDialog, setShowDialog] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [showFabricDialog, setShowFabricDialog] = useState(false);
  const [fabricTypes, setFabricTypes] = useState(defaultFabricTypes);
  const [newFabricType, setNewFabricType] = useState("");
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: "",
    name_bn: "",
    slug: "",
    sku: "",
    description: "",
    description_bn: "",
    category_id: "",
    images: [],
    price: 0,
    sale_price: null,
    fabric_type: "",
    colors: [],
    sizes: [],
    material_composition: "",
    care_instructions: "",
    stock_quantity: 0,
    is_featured: false,
    is_new_arrival: false,
    is_bestseller: false,
    is_active: true,
    tags: [],
    collection: ""
  });

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      
      const userData = await base44.auth.me();
      if (userData.role !== "admin") {
        window.location.href = createPageUrl("Home");
        return;
      }
      
      await loadData();
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const loadData = async () => {
    try {
      const [prods, cats] = await Promise.all([
        base44.entities.Product.list("-created_date", 500),
        base44.entities.Category.filter({ is_active: true })
      ]);
      setProducts(prods);
      setCategories(cats);
      
      // Load custom fabric types from settings
      const settings = await base44.entities.SiteSettings.filter({ key: "main" });
      if (settings[0]?.custom_fabric_types) {
        setFabricTypes([...defaultFabricTypes, ...settings[0].custom_fabric_types]);
      }
    } catch (e) {
      console.error("Error loading products:", e);
    }
  };

  const duplicateProduct = async (product) => {
    try {
      const newProduct = {
        ...product,
        name: `${product.name} (Copy)`,
        slug: `${product.slug}-copy-${Date.now()}`,
        sku: product.sku ? `${product.sku}-COPY` : ""
      };
      delete newProduct.id;
      delete newProduct.created_date;
      delete newProduct.updated_date;
      delete newProduct.created_by;
      
      await base44.entities.Product.create(newProduct);
      toast({ title: "Product duplicated successfully!" });
      await loadData();
    } catch (e) {
      toast({ title: "Error duplicating product", variant: "destructive" });
    }
  };

  const addFabricType = async () => {
    if (!newFabricType.trim()) return;
    
    const fabricKey = newFabricType.toLowerCase().replace(/\s+/g, "_");
    if (fabricTypes.includes(fabricKey)) {
      toast({ title: "Fabric type already exists", variant: "destructive" });
      return;
    }
    
    try {
      const settings = await base44.entities.SiteSettings.filter({ key: "main" });
      const customFabrics = settings[0]?.custom_fabric_types || [];
      const updatedFabrics = [...customFabrics, fabricKey];
      
      if (settings[0]) {
        await base44.entities.SiteSettings.update(settings[0].id, { custom_fabric_types: updatedFabrics });
      } else {
        // Create new settings if none exist
        await base44.entities.SiteSettings.create({ key: "main", custom_fabric_types: updatedFabrics });
      }
      
      setFabricTypes([...defaultFabricTypes, ...updatedFabrics]);
      setNewFabricType("");
      toast({ title: "Fabric type added!" });
    } catch (e) {
      console.error("Error adding fabric type:", e);
      toast({ title: "Error adding fabric type", variant: "destructive" });
    }
  };

  const removeFabricType = async (fabricType) => {
    try {
      setFabricTypes(fabricTypes.filter(f => f !== fabricType));
      toast({ title: "Fabric type removed!" });
    } catch (e) {
      console.error("Error removing fabric type:", e);
      toast({ title: "Error removing fabric type", variant: "destructive" });
    }
  };

  const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files);
    setUploading(true);
    
    try {
      const uploadedUrls = [];
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        uploadedUrls.push(file_url);
      }
      setFormData(prev => ({
        ...prev,
        images: [...prev.images, ...uploadedUrls]
      }));
    } catch (e) {
      toast({ title: "Error uploading images", variant: "destructive" });
    }
    setUploading(false);
  };

  const removeImage = (index) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const openAddDialog = () => {
    setEditingProduct(null);
    setFormData({
      name: "",
      name_bn: "",
      slug: "",
      sku: "",
      description: "",
      description_bn: "",
      category_id: "",
      images: [],
      price: 0,
      sale_price: null,
      fabric_type: "",
      colors: [],
      sizes: [],
      material_composition: "",
      care_instructions: "",
      stock_quantity: 0,
      is_featured: false,
      is_new_arrival: false,
      is_bestseller: false,
      is_active: true,
      tags: [],
      collection: ""
    });
    setShowDialog(true);
  };

  const openEditDialog = (product) => {
    setEditingProduct(product);
    setFormData({
      ...product,
      sale_price: product.sale_price || null,
      colors: product.colors || [],
      sizes: product.sizes || [],
      images: product.images || [],
      tags: product.tags || []
    });
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!formData.name || !formData.price) {
      toast({ title: "Please fill in required fields", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      const slug = formData.slug || formData.name.toLowerCase().replace(/\s+/g, "-");
      const dataToSave = {
        ...formData,
        slug,
        price: Number(formData.price),
        sale_price: formData.sale_price ? Number(formData.sale_price) : null,
        stock_quantity: Number(formData.stock_quantity)
      };

      if (editingProduct) {
        await base44.entities.Product.update(editingProduct.id, dataToSave);
        toast({ title: "Product updated successfully!" });
      } else {
        await base44.entities.Product.create(dataToSave);
        toast({ title: "Product created successfully!" });
      }

      // Invalidate products cache to update frontend immediately
      queryClient.invalidateQueries({ queryKey: ['all-products'] });
      queryClient.invalidateQueries({ queryKey: ['featured-products'] });
      setShowDialog(false);
      await loadData();
    } catch (e) {
      toast({ title: "Error saving product", variant: "destructive" });
    }
    setSaving(false);
  };

  const handleDelete = async (product) => {
    if (!confirm(`Are you sure you want to delete "${product.name}"?`)) return;
    
    try {
      await base44.entities.Product.delete(product.id);
      toast({ title: "Product deleted" });
      queryClient.invalidateQueries({ queryKey: ['all-products'] });
      queryClient.invalidateQueries({ queryKey: ['featured-products'] });
      await loadData();
    } catch (e) {
      toast({ title: "Error deleting product", variant: "destructive" });
    }
  };

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === "all" || p.category_id === filterCategory;
    return matchesSearch && matchesCategory;
  });



  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar currentPage="AdminProducts" />
      
      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b px-4 md:px-8 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <AdminSidebar mobile currentPage="AdminProducts" />
                </SheetContent>
              </Sheet>
              <h1 className="text-xl font-bold">Products</h1>
            </div>
            
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowFabricDialog(true)}>
                <Settings2 className="w-4 h-4 mr-2" />
                Fabric Types
              </Button>
              <Button onClick={openAddDialog} className="bg-[#d4a853] hover:bg-[#c49743] text-black">
                <Plus className="w-4 h-4 mr-2" />
                Add Product
              </Button>
            </div>
          </div>
        </header>

        <main className="p-4 md:p-8">
          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map(cat => (
                  <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Products Table */}
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Stock</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProducts.map(product => {
                    const category = categories.find(c => c.id === product.category_id);
                    return (
                      <TableRow key={product.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 bg-gray-100 rounded overflow-hidden">
                              <img 
                                src={product.images?.[0] || "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=100"}
                                alt={product.name}
                                loading="lazy"
                                decoding="async"
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div>
                              <p className="font-medium">{product.name}</p>
                              <p className="text-xs text-gray-500">{product.sku}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{category?.name || "-"}</TableCell>
                        <TableCell>
                          {product.sale_price ? (
                            <div>
                              <span className="font-medium">৳{product.sale_price.toLocaleString()}</span>
                              <span className="text-xs text-gray-400 line-through ml-2">
                                ৳{product.price.toLocaleString()}
                              </span>
                            </div>
                          ) : (
                            <span className="font-medium">৳{product.price?.toLocaleString()}</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge className={product.stock_quantity > 0 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                            {product.stock_quantity || 0}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={product.is_active ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                            {product.is_active ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" onClick={() => duplicateProduct(product)} title="Duplicate">
                            <Copy className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => openEditDialog(product)} title="Edit">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDelete(product)} title="Delete">
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              
              {filteredProducts.length === 0 && (
                <div className="text-center py-12">
                  <Package className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500">No products found</p>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>

      {/* Add/Edit Product Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingProduct ? "Edit Product" : "Add New Product"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Images */}
            <div>
              <Label>Product Images</Label>
              <div className="flex flex-wrap gap-3 mt-2">
                {formData.images.map((img, i) => (
                  <div key={i} className="relative w-20 h-20">
                    <img src={img} alt="" loading="lazy" decoding="async" className="w-full h-full object-cover rounded" />
                    <button
                      onClick={() => removeImage(i)}
                      className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
                <label className="w-20 h-20 border-2 border-dashed rounded flex items-center justify-center cursor-pointer hover:border-[#d4a853]">
                  {uploading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <Upload className="w-5 h-5 text-gray-400" />
                  )}
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Name *</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Product name"
                />
              </div>
              <div>
                <Label>SKU</Label>
                <Input
                  value={formData.sku}
                  onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                  placeholder="SKU-001"
                />
              </div>
            </div>

            <div>
              <Label>Description</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Product description"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label>Category</Label>
                <Select 
                  value={formData.category_id} 
                  onValueChange={(v) => setFormData({ ...formData, category_id: v })}
                >
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Fabric Type</Label>
                <Select 
                  value={formData.fabric_type} 
                  onValueChange={(v) => setFormData({ ...formData, fabric_type: v })}
                >
                  <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    {fabricTypes.map(ft => (
                      <SelectItem key={ft} value={ft}>{ft.replace(/_/g, " ")}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Collection</Label>
                <Input
                  value={formData.collection}
                  onChange={(e) => setFormData({ ...formData, collection: e.target.value })}
                  placeholder="Summer, Eid, etc."
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label>Price *</Label>
                <Input
                  type="number"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  placeholder="0"
                />
              </div>
              <div>
                <Label>Sale Price</Label>
                <Input
                  type="number"
                  value={formData.sale_price || ""}
                  onChange={(e) => setFormData({ ...formData, sale_price: e.target.value || null })}
                  placeholder="Optional"
                />
              </div>
              <div>
                <Label>Stock</Label>
                <Input
                  type="number"
                  value={formData.stock_quantity}
                  onChange={(e) => setFormData({ ...formData, stock_quantity: e.target.value })}
                  placeholder="0"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Sizes (comma separated)</Label>
                <Input
                  value={formData.sizes.join(", ")}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    sizes: e.target.value.split(",").map(s => s.trim()).filter(Boolean)
                  })}
                  placeholder="2.5m, 3m, 4.5m"
                />
              </div>
              <div>
                <Label>Material</Label>
                <Input
                  value={formData.material_composition}
                  onChange={(e) => setFormData({ ...formData, material_composition: e.target.value })}
                  placeholder="100% Cotton"
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-6">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(v) => setFormData({ ...formData, is_active: v })}
                />
                <Label htmlFor="is_active">Active</Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="is_featured"
                  checked={formData.is_featured}
                  onCheckedChange={(v) => setFormData({ ...formData, is_featured: v })}
                />
                <Label htmlFor="is_featured">Featured</Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="is_new_arrival"
                  checked={formData.is_new_arrival}
                  onCheckedChange={(v) => setFormData({ ...formData, is_new_arrival: v })}
                />
                <Label htmlFor="is_new_arrival">New Arrival</Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="is_bestseller"
                  checked={formData.is_bestseller}
                  onCheckedChange={(v) => setFormData({ ...formData, is_bestseller: v })}
                />
                <Label htmlFor="is_bestseller">Bestseller</Label>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancel</Button>
            <Button 
              onClick={handleSave} 
              disabled={saving}
              className="bg-[#d4a853] hover:bg-[#c49743] text-black"
            >
              {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              {editingProduct ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Fabric Types Dialog */}
      <Dialog open={showFabricDialog} onOpenChange={setShowFabricDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Manage Fabric Types</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="flex gap-2">
              <Input
                value={newFabricType}
                onChange={(e) => setNewFabricType(e.target.value)}
                placeholder="New fabric type name"
                onKeyDown={(e) => e.key === "Enter" && addFabricType()}
              />
              <Button onClick={addFabricType} className="bg-[#d4a853] hover:bg-[#c49743] text-black">
                <Plus className="w-4 h-4" />
              </Button>
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto">
              {fabricTypes.map(fabric => (
                <div key={fabric} className="flex items-center justify-between p-2 bg-gray-50 rounded group">
                  <span className="capitalize">{fabric.replace(/_/g, " ")}</span>
                  <Button variant="ghost" size="icon" onClick={() => removeFabricType(fabric)} className="opacity-0 group-hover:opacity-100 transition-opacity">
                    <X className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowFabricDialog(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}