import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Search, Package, Clock, CheckCircle, Truck, 
  XCircle, Loader2, MapPin, FileText
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { format } from "date-fns";


const statusSteps = [
  { key: "pending", label: "Order Placed", icon: Clock },
  { key: "confirmed", label: "Confirmed", icon: CheckCircle },
  { key: "processing", label: "Processing", icon: Package },
  { key: "shipped", label: "Shipped", icon: Truck },
  { key: "delivered", label: "Delivered", icon: CheckCircle }
];

export default function TrackOrder() {
  const [searchQuery, setSearchQuery] = useState("");
  const [orders, setOrders] = useState([]);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [loading, setLoading] = useState(false);
  const [notFound, setNotFound] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const search = params.get("search");
    if (search) {
      setSearchQuery(search);
      searchOrders(search);
    }
  }, []);

  const searchOrders = async (query) => {
    const searchTerm = query || searchQuery;
    if (!searchTerm.trim()) {
      toast({ title: "Please enter order number, phone, or email", variant: "destructive" });
      return;
    }

    setLoading(true);
    setNotFound(false);
    setOrders([]);
    setSelectedOrder(null);

    try {
      let foundOrders = [];
      const term = searchTerm.trim();

      // Try order number first
      const byOrderNumber = await base44.entities.Order.filter({ 
        order_number: term.toUpperCase() 
      });
      if (byOrderNumber.length > 0) {
        foundOrders = byOrderNumber;
      }

      // Try phone number
      if (foundOrders.length === 0 && /^01[3-9]\d{8}$/.test(term)) {
        const byPhone = await base44.entities.Order.filter({ 
          customer_phone: term 
        });
        foundOrders = byPhone;
      }

      // Try email
      if (foundOrders.length === 0 && term.includes("@")) {
        const byEmail = await base44.entities.Order.filter({ 
          customer_email: term.toLowerCase() 
        });
        foundOrders = byEmail;
      }

      if (foundOrders.length > 0) {
        // Sort by date descending
        foundOrders.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
        setOrders(foundOrders);
        if (foundOrders.length === 1) {
          setSelectedOrder(foundOrders[0]);
        }
      } else {
        setNotFound(true);
      }
    } catch (e) {
      toast({ title: "Error searching orders", variant: "destructive" });
    }
    setLoading(false);
  };

  const downloadInvoice = (order) => {
    const LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69258a473b6708fb6e444528/864e69bb5_Blackzyfashion.png";
    
    const invoiceHTML = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Invoice - ${order.order_number}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@400;500;600&display=swap');
    * { margin: 0; padding: 0; box-sizing: border-box; }
    @page { size: A4; margin: 0; }
    body { font-family: 'Inter', sans-serif; background: #f5f5f5; color: #1a1a1a; font-size: 12px; line-height: 1.5; }
    .invoice-container { width: 210mm; min-height: 297mm; margin: 0 auto; background: white; padding: 40px; position: relative; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; padding-bottom: 30px; border-bottom: 3px solid #d4a853; margin-bottom: 30px; }
    .logo-section img { height: 60px; margin-bottom: 10px; }
    .company-info { font-size: 11px; color: #666; }
    .invoice-title { text-align: right; }
    .invoice-title h1 { font-family: 'Cormorant Garamond', serif; font-size: 42px; font-weight: 600; color: #0a0a0a; letter-spacing: 4px; }
    .invoice-meta { margin-top: 10px; font-size: 12px; }
    .invoice-meta p { margin: 4px 0; }
    .invoice-meta strong { color: #d4a853; }
    .addresses { display: flex; justify-content: space-between; margin-bottom: 40px; }
    .address-box { width: 48%; }
    .address-box h3 { font-size: 11px; text-transform: uppercase; letter-spacing: 2px; color: #d4a853; margin-bottom: 12px; font-weight: 600; }
    .address-box p { margin: 4px 0; color: #333; }
    .items-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
    .items-table th { background: #0a0a0a; color: white; padding: 14px 16px; text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; font-weight: 600; }
    .items-table th:last-child, .items-table td:last-child { text-align: right; }
    .items-table td { padding: 16px; border-bottom: 1px solid #eee; vertical-align: top; }
    .items-table tr:nth-child(even) { background: #fafafa; }
    .product-name { font-weight: 600; color: #0a0a0a; }
    .product-details { font-size: 11px; color: #888; margin-top: 4px; }
    .summary-section { display: flex; justify-content: flex-end; }
    .summary-box { width: 300px; background: #fafafa; padding: 24px; border-radius: 4px; }
    .summary-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #eee; }
    .summary-row:last-child { border-bottom: none; }
    .summary-row.total { border-top: 2px solid #0a0a0a; border-bottom: none; margin-top: 10px; padding-top: 16px; font-size: 18px; font-weight: 700; }
    .summary-row.total .amount { color: #d4a853; }
    .payment-info { display: flex; gap: 40px; margin-top: 40px; padding: 20px; background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%); color: white; border-radius: 4px; }
    .payment-info-item h4 { font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: #d4a853; margin-bottom: 6px; }
    .payment-info-item p { font-weight: 600; text-transform: capitalize; }
    .footer { position: absolute; bottom: 40px; left: 40px; right: 40px; text-align: center; padding-top: 20px; border-top: 1px solid #eee; }
    .footer p { color: #888; font-size: 11px; margin: 4px 0; }
    .footer .thank-you { font-family: 'Cormorant Garamond', serif; font-size: 20px; color: #0a0a0a; margin-bottom: 10px; }
    .gold-accent { color: #d4a853; }
    @media print { body { background: white; } .invoice-container { box-shadow: none; } }
  </style>
</head>
<body>
  <div class="invoice-container">
    <div class="header">
      <div class="logo-section">
        <img src="${LOGO_URL}" alt="Blackzy Fashion" />
        <div class="company-info"><p>Premium Bengali Traditional Fabrics</p><p>Dhaka, Bangladesh</p></div>
      </div>
      <div class="invoice-title">
        <h1>INVOICE</h1>
        <div class="invoice-meta">
          <p><strong>Invoice #:</strong> ${order.order_number}</p>
          <p><strong>Date:</strong> ${format(new Date(order.created_date), "MMMM d, yyyy")}</p>
        </div>
      </div>
    </div>
    <div class="addresses">
      <div class="address-box"><h3>Bill To</h3><p><strong>${order.customer_name}</strong></p><p>${order.customer_phone}</p>${order.customer_email ? `<p>${order.customer_email}</p>` : ""}</div>
      <div class="address-box"><h3>Ship To</h3><p><strong>${order.shipping_address?.full_name || order.customer_name}</strong></p><p>${order.shipping_address?.address_line1 || ""}</p><p>${order.shipping_address?.city || ""}, ${order.shipping_address?.district || ""}</p></div>
    </div>
    <table class="items-table">
      <thead><tr><th style="width: 50%">Product</th><th style="width: 15%">Price</th><th style="width: 15%">Qty</th><th style="width: 20%">Total</th></tr></thead>
      <tbody>${order.items?.map(item => `<tr><td><div class="product-name">${item.product_name}</div><div class="product-details">${item.size ? `Size: ${item.size}` : ""}</div></td><td>৳${item.price?.toLocaleString()}</td><td>${item.quantity}</td><td>৳${(item.price * item.quantity).toLocaleString()}</td></tr>`).join("")}</tbody>
    </table>
    <div class="summary-section">
      <div class="summary-box">
        <div class="summary-row"><span>Subtotal</span><span>৳${order.subtotal?.toLocaleString()}</span></div>
        <div class="summary-row"><span>Shipping</span><span>${order.shipping_cost === 0 ? "FREE" : `৳${order.shipping_cost?.toLocaleString()}`}</span></div>
        <div class="summary-row total"><span>Total</span><span class="amount">৳${order.total?.toLocaleString()}</span></div>
      </div>
    </div>
    <div class="payment-info">
      <div class="payment-info-item"><h4>Payment Method</h4><p>${order.payment_method}</p></div>
      <div class="payment-info-item"><h4>Payment Status</h4><p>${order.payment_status}</p></div>
      <div class="payment-info-item"><h4>Order Status</h4><p>${order.order_status}</p></div>
    </div>
    <div class="footer">
      <p class="thank-you">Thank you for shopping with <span class="gold-accent">Blackzy Fashion!</span></p>
      <p>© ${new Date().getFullYear()} Blackzy Fashion. All rights reserved.</p>
    </div>
  </div>
  <script>window.onload = function() { window.print(); }</script>
</body>
</html>`;
    const printWindow = window.open("", "_blank");
    printWindow.document.write(invoiceHTML);
    printWindow.document.close();
  };

  const getStatusIndex = (status) => {
    if (status === "cancelled") return -1;
    return statusSteps.findIndex(s => s.key === status);
  };

  const order = selectedOrder;
  const currentStatusIndex = order ? getStatusIndex(order.order_status) : -1;

  return (
    <div className="min-h-screen bg-[#fafafa]">
      {/* Header */}
      <div className="bg-[#0a0a0a] py-16 px-4">
        <div className="max-w-7xl mx-auto text-center text-white">
          <span className="text-[#d4a853] text-sm tracking-[0.3em] uppercase font-body">
            Track Your Order
          </span>
          <h1 className="font-display text-4xl md:text-5xl mt-3 mb-4">Order Tracking</h1>
          <p className="text-gray-400 font-body max-w-xl mx-auto">
            Enter your order number, phone number, or email to track your orders
          </p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-12">
        {/* Search Form */}
        <div className="bg-white p-6 md:p-8 shadow-sm mb-8">
          <div className="flex gap-3">
            <Input
              placeholder="Order number, phone, or email"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && searchOrders()}
              className="rounded-none text-lg h-12"
            />
            <Button 
              onClick={() => searchOrders()}
              disabled={loading}
              className="bg-[#d4a853] hover:bg-[#c49743] text-black rounded-none px-8 h-12"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Search className="w-5 h-5" />
              )}
            </Button>
          </div>
          <p className="text-xs text-gray-500 mt-3 font-body">
            You can search by order number (e.g., BF12345678), phone number (01XXXXXXXXX), or email
          </p>
        </div>

        {/* Not Found */}
        {notFound && (
          <div className="bg-white p-8 text-center shadow-sm">
            <XCircle className="w-16 h-16 mx-auto text-red-400 mb-4" />
            <h2 className="font-display text-xl mb-2">No Orders Found</h2>
            <p className="text-gray-500 font-body">
              We couldn't find any orders matching "{searchQuery}". Please check and try again.
            </p>
          </div>
        )}

        {/* Multiple Orders List */}
        {orders.length > 1 && !selectedOrder && (
          <div className="space-y-4 mb-8">
            <h2 className="font-display text-xl">Found {orders.length} Orders</h2>
            <p className="text-sm text-gray-500 font-body mb-4">Select an order to view details:</p>
            {orders.map((o) => (
              <div
                key={o.id}
                onClick={() => setSelectedOrder(o)}
                className="bg-white p-4 shadow-sm cursor-pointer hover:shadow-md flex items-center justify-between"
              >
                <div>
                  <p className="font-display text-lg">#{o.order_number}</p>
                  <p className="text-sm text-gray-500 font-body">
                    {format(new Date(o.created_date), "MMM d, yyyy")} • ৳{o.total?.toLocaleString()}
                  </p>
                </div>
                <Badge className={`${
                  o.order_status === "delivered" ? "bg-green-100 text-green-800" :
                  o.order_status === "cancelled" ? "bg-red-100 text-red-800" :
                  "bg-yellow-100 text-yellow-800"
                }`}>
                  {o.order_status}
                </Badge>
              </div>
            ))}
          </div>
        )}

        {/* Back button when viewing single order from multiple */}
        {orders.length > 1 && selectedOrder && (
          <button
            onClick={() => setSelectedOrder(null)}
            className="mb-4 text-sm text-[#d4a853] font-body hover:underline"
          >
            ← Back to all orders
          </button>
        )}

        {/* Order Found */}
        {order && (
          <div className="space-y-6">
            {/* Order Info */}
            <div className="bg-white p-6 shadow-sm">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                  <h2 className="font-display text-xl">Order #{order.order_number}</h2>
                  <p className="text-sm text-gray-500 font-body">
                    Placed on {format(new Date(order.created_date), "MMMM d, yyyy 'at' h:mm a")}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => downloadInvoice(order)}
                    className="rounded-none"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Invoice
                  </Button>
                  <Badge className={`text-sm px-4 py-2 ${
                    order.order_status === "delivered" ? "bg-green-100 text-green-800" :
                    order.order_status === "cancelled" ? "bg-red-100 text-red-800" :
                    "bg-yellow-100 text-yellow-800"
                  }`}>
                    {order.order_status?.charAt(0).toUpperCase() + order.order_status?.slice(1)}
                  </Badge>
                </div>
              </div>

              {/* Progress Steps */}
              {order.order_status !== "cancelled" && (
                <div className="relative">
                  <div className="absolute top-5 left-0 right-0 h-1 bg-gray-200">
                  <div 
                    className="h-full bg-[#d4a853]"
                    style={{ width: `${(currentStatusIndex / (statusSteps.length - 1)) * 100}%` }}
                  />
                  </div>
                  <div className="flex justify-between relative">
                    {statusSteps.map((step, index) => {
                      const isCompleted = index <= currentStatusIndex;
                      const isCurrent = index === currentStatusIndex;
                      return (
                        <div key={step.key} className="flex flex-col items-center">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center z-10 ${
                            isCompleted 
                              ? "bg-[#d4a853] text-black" 
                              : "bg-gray-200 text-gray-400"
                          } ${isCurrent ? "ring-4 ring-[#d4a853]/30" : ""}`}>
                            <step.icon className="w-5 h-5" />
                          </div>
                          <span className={`text-xs mt-2 font-body ${
                            isCompleted ? "text-[#0a0a0a]" : "text-gray-400"
                          }`}>
                            {step.label}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {order.order_status === "cancelled" && (
                <div className="flex items-center gap-3 p-4 bg-red-50 rounded">
                  <XCircle className="w-6 h-6 text-red-500" />
                  <div>
                    <p className="font-medium text-red-700">Order Cancelled</p>
                    <p className="text-sm text-red-600">This order has been cancelled.</p>
                  </div>
                </div>
              )}
            </div>

            {/* Shipping Address */}
            <div className="bg-white p-6 shadow-sm">
              <h3 className="font-display text-lg mb-4 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-[#d4a853]" />
                Shipping Address
              </h3>
              <div className="text-sm font-body text-gray-600">
                <p className="font-medium text-[#0a0a0a]">{order.shipping_address?.full_name}</p>
                <p>{order.shipping_address?.phone}</p>
                <p>{order.shipping_address?.address_line1}</p>
                <p>{order.shipping_address?.city}, {order.shipping_address?.district}</p>
              </div>
            </div>

            {/* Order Items */}
            <div className="bg-white p-6 shadow-sm">
              <h3 className="font-display text-lg mb-4 flex items-center gap-2">
                <Package className="w-5 h-5 text-[#d4a853]" />
                Order Items
              </h3>
              <div className="space-y-4">
                {order.items?.map((item, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="w-16 h-16 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                      <img 
                        src={item.product_image || "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=100"}
                        alt={item.product_name}
                        loading="lazy"
                        decoding="async"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <p className="font-body font-medium">{item.product_name}</p>
                      <p className="text-sm text-gray-500">
                        {item.size && `Size: ${item.size}`} × {item.quantity}
                      </p>
                    </div>
                    <p className="font-body font-medium">
                      ৳{(item.price * item.quantity).toLocaleString()}
                    </p>
                  </div>
                ))}
              </div>
              
              <div className="border-t mt-6 pt-4 space-y-2">
                <div className="flex justify-between text-sm font-body">
                  <span>Subtotal</span>
                  <span>৳{order.subtotal?.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm font-body">
                  <span>Shipping</span>
                  <span>{order.shipping_cost === 0 ? "FREE" : `৳${order.shipping_cost}`}</span>
                </div>
                <div className="flex justify-between font-display text-lg border-t pt-2">
                  <span>Total</span>
                  <span>৳{order.total?.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}