import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Loader2, Save, Menu, Truck, RotateCcw, Shield, FileText
} from "lucide-react";
import AdminSidebar from "../components/admin/AdminSidebar";

const pageConfigs = [
  { key: "shipping_policy", label: "Shipping Policy", icon: Truck },
  { key: "return_policy", label: "Return Policy", icon: RotateCcw },
  { key: "privacy_policy", label: "Privacy Policy", icon: Shield },
  { key: "terms_conditions", label: "Terms & Conditions", icon: FileText },
];

export default function AdminPages() {
  const [pages, setPages] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState("shipping_policy");
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) { base44.auth.redirectToLogin(); return; }
      const user = await base44.auth.me();
      if (user.role !== "admin") { window.location.href = createPageUrl("Home"); return; }

      const allPages = await base44.entities.PageContent.list();
      const pagesMap = {};
      allPages.forEach(page => {
        pagesMap[page.page_key] = page;
      });
      
      // Initialize empty pages
      pageConfigs.forEach(config => {
        if (!pagesMap[config.key]) {
          pagesMap[config.key] = {
            page_key: config.key,
            title: config.label,
            subtitle: "",
            content: "",
            last_updated: new Date().toISOString().split('T')[0]
          };
        }
      });
      
      setPages(pagesMap);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const updatePage = (key, field, value) => {
    setPages(prev => ({
      ...prev,
      [key]: { ...prev[key], [field]: value }
    }));
  };

  const handleSave = async (key) => {
    setSaving(true);
    try {
      const pageData = pages[key];
      if (pageData.id) {
        await base44.entities.PageContent.update(pageData.id, {
          title: pageData.title,
          subtitle: pageData.subtitle,
          content: pageData.content,
          last_updated: new Date().toISOString().split('T')[0]
        });
      } else {
        const created = await base44.entities.PageContent.create({
          ...pageData,
          last_updated: new Date().toISOString().split('T')[0]
        });
        setPages(prev => ({
          ...prev,
          [key]: { ...prev[key], id: created.id }
        }));
      }
      toast({ title: "Page saved successfully!" });
    } catch (err) {
      toast({ title: "Error saving page", variant: "destructive" });
    }
    setSaving(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar currentPage="AdminPages" />

      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b px-4 md:px-8 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <AdminSidebar mobile currentPage="AdminPages" />
                </SheetContent>
              </Sheet>
              <h1 className="text-xl font-bold">Page Content</h1>
            </div>
          </div>
        </header>

        <main className="p-4 md:p-8">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-white p-1 mb-6 flex-wrap">
              {pageConfigs.map(config => (
                <TabsTrigger key={config.key} value={config.key} className="flex items-center gap-2">
                  <config.icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{config.label}</span>
                </TabsTrigger>
              ))}
            </TabsList>

            {pageConfigs.map(config => (
              <TabsContent key={config.key} value={config.key}>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <config.icon className="w-5 h-5 text-[#d4a853]" />
                        {config.label}
                      </CardTitle>
                      <p className="text-sm text-gray-500 mt-1">
                        Edit the content for your {config.label.toLowerCase()} page
                      </p>
                    </div>
                    <Button 
                      onClick={() => handleSave(config.key)} 
                      disabled={saving}
                      className="bg-[#d4a853] hover:bg-[#c49743] text-black"
                    >
                      {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                      Save
                    </Button>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Page Title</Label>
                        <Input 
                          value={pages[config.key]?.title || ""} 
                          onChange={(e) => updatePage(config.key, "title", e.target.value)}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label>Subtitle</Label>
                        <Input 
                          value={pages[config.key]?.subtitle || ""} 
                          onChange={(e) => updatePage(config.key, "subtitle", e.target.value)}
                          className="mt-1"
                          placeholder="Shown below the title"
                        />
                      </div>
                    </div>

                    <div>
                      <Label>Page Content (Markdown supported)</Label>
                      <Textarea 
                        value={pages[config.key]?.content || ""} 
                        onChange={(e) => updatePage(config.key, "content", e.target.value)}
                        className="mt-1 font-mono text-sm"
                        rows={15}
                        placeholder={`Write your ${config.label.toLowerCase()} content here...

You can use Markdown formatting:
## Heading
### Subheading
- Bullet point
1. Numbered list
**Bold text**
*Italic text*`}
                      />
                    </div>

                    <div className="bg-amber-50 border border-amber-200 p-4 rounded">
                      <p className="text-amber-800 text-sm">
                        <strong>Tip:</strong> You can use Markdown for formatting. Leave empty to use the default template content.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </main>
      </div>
    </div>
  );
}