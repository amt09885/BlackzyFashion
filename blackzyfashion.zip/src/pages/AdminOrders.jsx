import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Package, Search, Eye, Edit, Trash2,
  ShoppingCart, Menu, Loader2, Clock, CheckCircle,
  Truck, XCircle, FileText
} from "lucide-react";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useToast } from "@/components/ui/use-toast";
import { format } from "date-fns";

import AdminSidebar from "../components/admin/AdminSidebar";

const statusOptions = [
  { value: "pending", label: "Pending", color: "bg-yellow-100 text-yellow-800", icon: Clock },
  { value: "confirmed", label: "Confirmed", color: "bg-blue-100 text-blue-800", icon: CheckCircle },
  { value: "processing", label: "Processing", color: "bg-indigo-100 text-indigo-800", icon: Package },
  { value: "shipped", label: "Shipped", color: "bg-purple-100 text-purple-800", icon: Truck },
  { value: "delivered", label: "Delivered", color: "bg-green-100 text-green-800", icon: CheckCircle },
  { value: "cancelled", label: "Cancelled", color: "bg-red-100 text-red-800", icon: XCircle }
];

export default function AdminOrders() {
  const [loading, setLoading] = useState(true);
  const [orders, setOrders] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [showDialog, setShowDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingOrder, setEditingOrder] = useState(null);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      
      const userData = await base44.auth.me();
      if (userData.role !== "admin") {
        window.location.href = createPageUrl("Home");
        return;
      }
      
      await loadOrders();
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const loadOrders = async () => {
    try {
      const data = await base44.entities.Order.list("-created_date", 500);
      setOrders(data);
    } catch (e) {
      console.error("Error loading orders:", e);
    }
  };

  const updateOrderStatus = async (orderId, newStatus) => {
    try {
      await base44.entities.Order.update(orderId, { order_status: newStatus });
      toast({ title: `Order status updated to ${newStatus}` });
      await loadOrders();
    } catch (e) {
      toast({ title: "Error updating order", variant: "destructive" });
    }
  };

  const deleteOrder = async (order) => {
    if (!confirm(`Are you sure you want to delete order #${order.order_number}? This cannot be undone.`)) return;
    
    try {
      await base44.entities.Order.delete(order.id);
      toast({ title: "Order deleted successfully" });
      await loadOrders();
    } catch (e) {
      toast({ title: "Error deleting order", variant: "destructive" });
    }
  };

  const viewOrder = (order) => {
    setSelectedOrder(order);
    setShowDialog(true);
  };

  const openEditOrder = (order) => {
    setEditingOrder({
      ...order,
      shipping_address: order.shipping_address || {}
    });
    setShowEditDialog(true);
  };

  const saveOrder = async () => {
    if (!editingOrder) return;
    setSaving(true);
    try {
      await base44.entities.Order.update(editingOrder.id, {
        customer_name: editingOrder.customer_name,
        customer_phone: editingOrder.customer_phone,
        customer_email: editingOrder.customer_email,
        shipping_address: editingOrder.shipping_address,
        order_status: editingOrder.order_status,
        payment_method: editingOrder.payment_method,
        payment_status: editingOrder.payment_status,
        transaction_id: editingOrder.transaction_id,
        tracking_number: editingOrder.tracking_number,
        notes: editingOrder.notes,
        admin_notes: editingOrder.admin_notes,
        coupon_code: editingOrder.coupon_code,
        subtotal: Number(editingOrder.subtotal) || 0,
        shipping_cost: Number(editingOrder.shipping_cost) || 0,
        discount_amount: Number(editingOrder.discount_amount) || 0,
        total: Number(editingOrder.total)
      });
      toast({ title: "Order updated successfully!" });
      setShowEditDialog(false);
      await loadOrders();
    } catch (e) {
      toast({ title: "Error updating order", variant: "destructive" });
    }
    setSaving(false);
  };

  const downloadInvoice = (order) => {
    const LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69258a473b6708fb6e444528/864e69bb5_Blackzyfashion.png";
    
    const invoiceHTML = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Invoice - ${order.order_number}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@400;500;600&display=swap');
    
    * { margin: 0; padding: 0; box-sizing: border-box; }
    
    @page { size: A4; margin: 0; }
    
    body {
      font-family: 'Inter', sans-serif;
      background: #f5f5f5;
      color: #1a1a1a;
      font-size: 12px;
      line-height: 1.5;
    }
    
    .invoice-container {
      width: 210mm;
      min-height: 297mm;
      margin: 0 auto;
      background: white;
      padding: 40px;
      position: relative;
    }
    
    .header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      padding-bottom: 30px;
      border-bottom: 3px solid #d4a853;
      margin-bottom: 30px;
    }
    
    .logo-section img {
      height: 60px;
      margin-bottom: 10px;
    }
    
    .company-info {
      font-size: 11px;
      color: #666;
    }
    
    .invoice-title {
      text-align: right;
    }
    
    .invoice-title h1 {
      font-family: 'Cormorant Garamond', serif;
      font-size: 42px;
      font-weight: 600;
      color: #0a0a0a;
      letter-spacing: 4px;
    }
    
    .invoice-meta {
      margin-top: 10px;
      font-size: 12px;
    }
    
    .invoice-meta p {
      margin: 4px 0;
    }
    
    .invoice-meta strong {
      color: #d4a853;
    }
    
    .addresses {
      display: flex;
      justify-content: space-between;
      margin-bottom: 40px;
    }
    
    .address-box {
      width: 48%;
    }
    
    .address-box h3 {
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 2px;
      color: #d4a853;
      margin-bottom: 12px;
      font-weight: 600;
    }
    
    .address-box p {
      margin: 4px 0;
      color: #333;
    }
    
    .items-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 30px;
    }
    
    .items-table th {
      background: #0a0a0a;
      color: white;
      padding: 14px 16px;
      text-align: left;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 1px;
      font-weight: 600;
    }
    
    .items-table th:last-child,
    .items-table td:last-child {
      text-align: right;
    }
    
    .items-table td {
      padding: 16px;
      border-bottom: 1px solid #eee;
      vertical-align: top;
    }
    
    .items-table tr:nth-child(even) {
      background: #fafafa;
    }
    
    .product-name {
      font-weight: 600;
      color: #0a0a0a;
    }
    
    .product-details {
      font-size: 11px;
      color: #888;
      margin-top: 4px;
    }
    
    .summary-section {
      display: flex;
      justify-content: flex-end;
    }
    
    .summary-box {
      width: 300px;
      background: #fafafa;
      padding: 24px;
      border-radius: 4px;
    }
    
    .summary-row {
      display: flex;
      justify-content: space-between;
      padding: 8px 0;
      border-bottom: 1px solid #eee;
    }
    
    .summary-row:last-child {
      border-bottom: none;
    }
    
    .summary-row.total {
      border-top: 2px solid #0a0a0a;
      border-bottom: none;
      margin-top: 10px;
      padding-top: 16px;
      font-size: 18px;
      font-weight: 700;
    }
    
    .summary-row.total .amount {
      color: #d4a853;
    }
    
    .discount {
      color: #22c55e;
    }
    
    .payment-info {
      display: flex;
      gap: 40px;
      margin-top: 40px;
      padding: 20px;
      background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
      color: white;
      border-radius: 4px;
    }
    
    .payment-info-item h4 {
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: #d4a853;
      margin-bottom: 6px;
    }
    
    .payment-info-item p {
      font-weight: 600;
      text-transform: capitalize;
    }
    
    .footer {
      position: absolute;
      bottom: 40px;
      left: 40px;
      right: 40px;
      text-align: center;
      padding-top: 20px;
      border-top: 1px solid #eee;
    }
    
    .footer p {
      color: #888;
      font-size: 11px;
      margin: 4px 0;
    }
    
    .footer .thank-you {
      font-family: 'Cormorant Garamond', serif;
      font-size: 20px;
      color: #0a0a0a;
      margin-bottom: 10px;
    }
    
    .gold-accent {
      color: #d4a853;
    }
    
    @media print {
      body { background: white; }
      .invoice-container { box-shadow: none; }
    }
  </style>
</head>
<body>
  <div class="invoice-container">
    <div class="header">
      <div class="logo-section">
        <img src="${LOGO_URL}" alt="Blackzy Fashion" />
        <div class="company-info">
          <p>Premium Bengali Traditional Fabrics</p>
          <p>Dhaka, Bangladesh</p>
        </div>
      </div>
      <div class="invoice-title">
        <h1>INVOICE</h1>
        <div class="invoice-meta">
          <p><strong>Invoice #:</strong> ${order.order_number}</p>
          <p><strong>Date:</strong> ${format(new Date(order.created_date), "MMMM d, yyyy")}</p>
          <p><strong>Time:</strong> ${format(new Date(order.created_date), "h:mm a")}</p>
        </div>
      </div>
    </div>
    
    <div class="addresses">
      <div class="address-box">
        <h3>Bill To</h3>
        <p><strong>${order.customer_name}</strong></p>
        <p>${order.customer_phone}</p>
        ${order.customer_email ? `<p>${order.customer_email}</p>` : ""}
      </div>
      <div class="address-box">
        <h3>Ship To</h3>
        <p><strong>${order.shipping_address?.full_name || order.customer_name}</strong></p>
        <p>${order.shipping_address?.address_line1 || ""}</p>
        ${order.shipping_address?.address_line2 ? `<p>${order.shipping_address.address_line2}</p>` : ""}
        <p>${order.shipping_address?.city || ""}, ${order.shipping_address?.district || ""}</p>
        ${order.shipping_address?.postal_code ? `<p>${order.shipping_address.postal_code}</p>` : ""}
      </div>
    </div>
    
    <table class="items-table">
      <thead>
        <tr>
          <th style="width: 50%">Product</th>
          <th style="width: 15%">Price</th>
          <th style="width: 15%">Qty</th>
          <th style="width: 20%">Total</th>
        </tr>
      </thead>
      <tbody>
        ${order.items?.map(item => `
          <tr>
            <td>
              <div class="product-name">${item.product_name}</div>
              <div class="product-details">
                ${item.size ? `Size: ${item.size}` : ""} 
                ${item.color ? `${item.size ? " • " : ""}Color: ${item.color}` : ""}
              </div>
            </td>
            <td>৳${item.price?.toLocaleString()}</td>
            <td>${item.quantity}</td>
            <td>৳${(item.price * item.quantity).toLocaleString()}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
    
    <div class="summary-section">
      <div class="summary-box">
        <div class="summary-row">
          <span>Subtotal</span>
          <span>৳${order.subtotal?.toLocaleString()}</span>
        </div>
        <div class="summary-row">
          <span>Shipping</span>
          <span>${order.shipping_cost === 0 ? "FREE" : `৳${order.shipping_cost?.toLocaleString()}`}</span>
        </div>
        ${order.discount_amount > 0 ? `
          <div class="summary-row">
            <span>Discount</span>
            <span class="discount">-৳${order.discount_amount?.toLocaleString()}</span>
          </div>
        ` : ""}
        <div class="summary-row total">
          <span>Total</span>
          <span class="amount">৳${order.total?.toLocaleString()}</span>
        </div>
      </div>
    </div>
    
    <div class="payment-info">
      <div class="payment-info-item">
        <h4>Payment Method</h4>
        <p>${order.payment_method}</p>
      </div>
      <div class="payment-info-item">
        <h4>Payment Status</h4>
        <p>${order.payment_status}</p>
      </div>
      <div class="payment-info-item">
        <h4>Order Status</h4>
        <p>${order.order_status}</p>
      </div>
    </div>
    
    <div class="footer">
      <p class="thank-you">Thank you for shopping with <span class="gold-accent">Blackzy Fashion!</span></p>
      <p>For any queries, please contact us at support@blackzy.com</p>
      <p>© ${new Date().getFullYear()} Blackzy Fashion. All rights reserved.</p>
    </div>
  </div>
  
  <script>
    window.onload = function() { window.print(); }
  </script>
</body>
</html>
    `;

    const printWindow = window.open("", "_blank");
    printWindow.document.write(invoiceHTML);
    printWindow.document.close();
  };

  const filteredOrders = orders.filter(o => {
    const matchesSearch = 
      o.order_number?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customer_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customer_phone?.includes(searchQuery);
    const matchesStatus = filterStatus === "all" || o.order_status === filterStatus;
    return matchesSearch && matchesStatus;
  });



  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar currentPage="AdminOrders" />
      
      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b px-4 md:px-8 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <AdminSidebar mobile currentPage="AdminOrders" />
                </SheetContent>
              </Sheet>
              <h1 className="text-xl font-bold">Orders</h1>
            </div>
          </div>
        </header>

        <main className="p-4 md:p-8">
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
            {statusOptions.slice(0, 5).map(status => {
              const count = orders.filter(o => o.order_status === status.value).length;
              return (
                <Card key={status.value} className="cursor-pointer hover:shadow-md" onClick={() => setFilterStatus(status.value)}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <status.icon className="w-5 h-5 text-gray-400" />
                      <Badge className={status.color}>{count}</Badge>
                    </div>
                    <p className="text-sm font-medium mt-2">{status.label}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search by order #, customer name, or phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                {statusOptions.map(s => (
                  <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Orders Table */}
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Payment</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOrders.map(order => {
                    const status = statusOptions.find(s => s.value === order.order_status) || statusOptions[0];
                    return (
                      <TableRow key={order.id}>
                        <TableCell>
                          <p className="font-medium">#{order.order_number}</p>
                          <p className="text-xs text-gray-500">{order.items?.length} items</p>
                        </TableCell>
                        <TableCell>
                          <p className="font-medium">{order.customer_name}</p>
                          <p className="text-xs text-gray-500">{order.customer_phone}</p>
                        </TableCell>
                        <TableCell>
                          <p className="text-sm">{format(new Date(order.created_date), "MMM d, yyyy")}</p>
                          <p className="text-xs text-gray-500">{format(new Date(order.created_date), "h:mm a")}</p>
                        </TableCell>
                        <TableCell>
                          <p className="font-medium">৳{order.total?.toLocaleString()}</p>
                        </TableCell>
                        <TableCell>
                          <Badge className={order.payment_status === "paid" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}>
                            {order.payment_status}
                          </Badge>
                          <p className="text-xs text-gray-500 mt-1 capitalize">{order.payment_method}</p>
                        </TableCell>
                        <TableCell>
                          <Select 
                            value={order.order_status} 
                            onValueChange={(v) => updateOrderStatus(order.id, v)}
                          >
                            <SelectTrigger className={`w-32 h-8 text-xs ${status.color}`}>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {statusOptions.map(s => (
                                <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" onClick={() => downloadInvoice(order)} title="Download Invoice">
                            <FileText className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => openEditOrder(order)} title="Edit Order">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => viewOrder(order)} title="View Details">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => deleteOrder(order)} title="Delete Order">
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              
              {filteredOrders.length === 0 && (
                <div className="text-center py-12">
                  <ShoppingCart className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500">No orders found</p>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>

      {/* Order Details Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Order #{selectedOrder?.order_number}</DialogTitle>
          </DialogHeader>

          {selectedOrder && (
            <div className="space-y-6">
              {/* Customer Info */}
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-2">Customer</h4>
                  <p className="text-sm">{selectedOrder.customer_name}</p>
                  <p className="text-sm text-gray-500">{selectedOrder.customer_email || "No email"}</p>
                  <p className="text-sm text-gray-500">{selectedOrder.customer_phone}</p>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Shipping Address</h4>
                  <p className="text-sm">{selectedOrder.shipping_address?.full_name}</p>
                  <p className="text-sm text-gray-500">{selectedOrder.shipping_address?.phone}</p>
                  <p className="text-sm text-gray-500">{selectedOrder.shipping_address?.address_line1}</p>
                  {selectedOrder.shipping_address?.address_line2 && (
                    <p className="text-sm text-gray-500">{selectedOrder.shipping_address?.address_line2}</p>
                  )}
                  <p className="text-sm text-gray-500">
                    {selectedOrder.shipping_address?.city}, {selectedOrder.shipping_address?.district}
                  </p>
                </div>
              </div>

              {/* Payment Info */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded">
                <div>
                  <p className="text-xs text-gray-500 uppercase">Payment Method</p>
                  <p className="font-medium capitalize">{selectedOrder.payment_method}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase">Payment Status</p>
                  <Badge className={selectedOrder.payment_status === "paid" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}>
                    {selectedOrder.payment_status}
                  </Badge>
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase">Order Status</p>
                  <Badge className={
                    selectedOrder.order_status === "delivered" ? "bg-green-100 text-green-800" :
                    selectedOrder.order_status === "cancelled" ? "bg-red-100 text-red-800" :
                    "bg-blue-100 text-blue-800"
                  }>
                    {selectedOrder.order_status}
                  </Badge>
                </div>
                {selectedOrder.tracking_number && (
                  <div>
                    <p className="text-xs text-gray-500 uppercase">Tracking #</p>
                    <p className="font-medium">{selectedOrder.tracking_number}</p>
                  </div>
                )}
              </div>

              {/* Transaction ID - Important for bKash/Nagad */}
              {selectedOrder.transaction_id && (
                <div className="p-4 bg-blue-50 rounded border border-blue-200">
                  <p className="text-xs text-blue-600 uppercase font-medium">Transaction ID</p>
                  <p className="font-mono text-lg">{selectedOrder.transaction_id}</p>
                </div>
              )}

              {/* Coupon Code */}
              {selectedOrder.coupon_code && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-500">Coupon Applied:</span>
                  <Badge variant="outline" className="text-green-600 border-green-600">
                    {selectedOrder.coupon_code}
                  </Badge>
                </div>
              )}

              {/* Order Items */}
              <div>
                <h4 className="font-medium mb-3">Order Items</h4>
                <div className="space-y-3">
                  {selectedOrder.items?.map((item, i) => (
                    <div key={i} className="flex gap-4 p-3 bg-gray-50 rounded">
                      <div className="w-16 h-16 bg-white rounded overflow-hidden">
                        <img 
                          src={item.product_image || "https://images.unsplash.com/photo-1558171813-4c088753af8f?w=100"}
                          alt={item.product_name}
                          loading="lazy"
                          decoding="async"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">{item.product_name}</p>
                        <p className="text-sm text-gray-500">
                          {item.size && `Size: ${item.size}`} {item.color && `• Color: ${item.color}`}
                        </p>
                        <p className="text-sm">৳{item.price?.toLocaleString()} × {item.quantity}</p>
                      </div>
                      <p className="font-medium">৳{(item.price * item.quantity).toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Order Summary */}
              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subtotal</span>
                  <span>৳{selectedOrder.subtotal?.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Shipping</span>
                  <span>{selectedOrder.shipping_cost === 0 ? "FREE" : `৳${selectedOrder.shipping_cost}`}</span>
                </div>
                {selectedOrder.discount_amount > 0 && (
                  <div className="flex justify-between text-sm text-green-600">
                    <span>Discount {selectedOrder.coupon_code && `(${selectedOrder.coupon_code})`}</span>
                    <span>-৳{selectedOrder.discount_amount.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg border-t pt-2">
                  <span>Total</span>
                  <span>৳{selectedOrder.total?.toLocaleString()}</span>
                </div>
              </div>

              {/* Customer Notes */}
              {selectedOrder.notes && (
                <div>
                  <h4 className="font-medium mb-2">Customer Notes</h4>
                  <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded">{selectedOrder.notes}</p>
                </div>
              )}

              {/* Admin Notes */}
              {selectedOrder.admin_notes && (
                <div>
                  <h4 className="font-medium mb-2">Admin Notes</h4>
                  <p className="text-sm text-gray-600 bg-yellow-50 p-3 rounded border border-yellow-200">{selectedOrder.admin_notes}</p>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => downloadInvoice(selectedOrder)}>
              <FileText className="w-4 h-4 mr-2" />
              Download Invoice
            </Button>
            <Button variant="outline" onClick={() => setShowDialog(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Order Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Order #{editingOrder?.order_number}</DialogTitle>
          </DialogHeader>

          {editingOrder && (
            <div className="space-y-6">
              {/* Customer Info */}
              <div className="p-4 bg-gray-50 rounded">
                <h4 className="font-medium mb-3">Customer Information</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Customer Name</Label>
                    <Input
                      value={editingOrder.customer_name}
                      onChange={(e) => setEditingOrder({ ...editingOrder, customer_name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>Phone</Label>
                    <Input
                      value={editingOrder.customer_phone}
                      onChange={(e) => setEditingOrder({ ...editingOrder, customer_phone: e.target.value })}
                    />
                  </div>
                  <div className="col-span-2">
                    <Label>Email</Label>
                    <Input
                      value={editingOrder.customer_email || ""}
                      onChange={(e) => setEditingOrder({ ...editingOrder, customer_email: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              {/* Shipping Address */}
              <div className="p-4 bg-gray-50 rounded">
                <h4 className="font-medium mb-3">Shipping Address</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Full Name</Label>
                    <Input
                      value={editingOrder.shipping_address?.full_name || ""}
                      onChange={(e) => setEditingOrder({ 
                        ...editingOrder, 
                        shipping_address: { ...editingOrder.shipping_address, full_name: e.target.value }
                      })}
                    />
                  </div>
                  <div>
                    <Label>Phone</Label>
                    <Input
                      value={editingOrder.shipping_address?.phone || ""}
                      onChange={(e) => setEditingOrder({ 
                        ...editingOrder, 
                        shipping_address: { ...editingOrder.shipping_address, phone: e.target.value }
                      })}
                    />
                  </div>
                  <div className="col-span-2">
                    <Label>Address Line 1</Label>
                    <Input
                      value={editingOrder.shipping_address?.address_line1 || ""}
                      onChange={(e) => setEditingOrder({ 
                        ...editingOrder, 
                        shipping_address: { ...editingOrder.shipping_address, address_line1: e.target.value }
                      })}
                    />
                  </div>
                  <div className="col-span-2">
                    <Label>Address Line 2</Label>
                    <Input
                      value={editingOrder.shipping_address?.address_line2 || ""}
                      onChange={(e) => setEditingOrder({ 
                        ...editingOrder, 
                        shipping_address: { ...editingOrder.shipping_address, address_line2: e.target.value }
                      })}
                      placeholder="Optional"
                    />
                  </div>
                  <div>
                    <Label>City</Label>
                    <Input
                      value={editingOrder.shipping_address?.city || ""}
                      onChange={(e) => setEditingOrder({ 
                        ...editingOrder, 
                        shipping_address: { ...editingOrder.shipping_address, city: e.target.value }
                      })}
                    />
                  </div>
                  <div>
                    <Label>District</Label>
                    <Input
                      value={editingOrder.shipping_address?.district || ""}
                      onChange={(e) => setEditingOrder({ 
                        ...editingOrder, 
                        shipping_address: { ...editingOrder.shipping_address, district: e.target.value }
                      })}
                    />
                  </div>
                </div>
              </div>

              {/* Payment & Status */}
              <div className="p-4 bg-gray-50 rounded">
                <h4 className="font-medium mb-3">Payment & Status</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Payment Method</Label>
                    <Select 
                      value={editingOrder.payment_method} 
                      onValueChange={(v) => setEditingOrder({ ...editingOrder, payment_method: v })}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cod">Cash on Delivery</SelectItem>
                        <SelectItem value="bkash">bKash</SelectItem>
                        <SelectItem value="nagad">Nagad</SelectItem>
                        <SelectItem value="rocket">Rocket</SelectItem>
                        <SelectItem value="card">Card</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Payment Status</Label>
                    <Select 
                      value={editingOrder.payment_status} 
                      onValueChange={(v) => setEditingOrder({ ...editingOrder, payment_status: v })}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="paid">Paid</SelectItem>
                        <SelectItem value="failed">Failed</SelectItem>
                        <SelectItem value="refunded">Refunded</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Order Status</Label>
                    <Select 
                      value={editingOrder.order_status} 
                      onValueChange={(v) => setEditingOrder({ ...editingOrder, order_status: v })}
                    >
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {statusOptions.map(s => (
                          <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Transaction ID (bKash/Nagad)</Label>
                    <Input
                      value={editingOrder.transaction_id || ""}
                      onChange={(e) => setEditingOrder({ ...editingOrder, transaction_id: e.target.value })}
                      placeholder="Enter transaction ID"
                    />
                  </div>
                </div>
              </div>

              {/* Order Amounts */}
              <div className="p-4 bg-gray-50 rounded">
                <h4 className="font-medium mb-3">Order Amounts</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <Label>Subtotal</Label>
                    <Input
                      type="number"
                      value={editingOrder.subtotal || 0}
                      onChange={(e) => setEditingOrder({ ...editingOrder, subtotal: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>Shipping Cost</Label>
                    <Input
                      type="number"
                      value={editingOrder.shipping_cost || 0}
                      onChange={(e) => setEditingOrder({ ...editingOrder, shipping_cost: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>Discount</Label>
                    <Input
                      type="number"
                      value={editingOrder.discount_amount || 0}
                      onChange={(e) => setEditingOrder({ ...editingOrder, discount_amount: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>Total</Label>
                    <Input
                      type="number"
                      value={editingOrder.total}
                      onChange={(e) => setEditingOrder({ ...editingOrder, total: e.target.value })}
                    />
                  </div>
                </div>
                {editingOrder.coupon_code && (
                  <div className="mt-3">
                    <Label>Coupon Code</Label>
                    <Input
                      value={editingOrder.coupon_code || ""}
                      onChange={(e) => setEditingOrder({ ...editingOrder, coupon_code: e.target.value })}
                    />
                  </div>
                )}
              </div>

              {/* Tracking & Notes */}
              <div className="p-4 bg-gray-50 rounded">
                <h4 className="font-medium mb-3">Tracking & Notes</h4>
                <div className="space-y-4">
                  <div>
                    <Label>Tracking Number</Label>
                    <Input
                      value={editingOrder.tracking_number || ""}
                      onChange={(e) => setEditingOrder({ ...editingOrder, tracking_number: e.target.value })}
                      placeholder="Enter tracking number"
                    />
                  </div>
                  <div>
                    <Label>Customer Notes</Label>
                    <Textarea
                      value={editingOrder.notes || ""}
                      onChange={(e) => setEditingOrder({ ...editingOrder, notes: e.target.value })}
                      placeholder="Notes from customer"
                      rows={2}
                    />
                  </div>
                  <div>
                    <Label>Admin Notes (Internal)</Label>
                    <Textarea
                      value={editingOrder.admin_notes || ""}
                      onChange={(e) => setEditingOrder({ ...editingOrder, admin_notes: e.target.value })}
                      placeholder="Internal notes about this order"
                      rows={2}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>Cancel</Button>
            <Button 
              onClick={saveOrder} 
              disabled={saving}
              className="bg-[#d4a853] hover:bg-[#c49743] text-black"
            >
              {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}