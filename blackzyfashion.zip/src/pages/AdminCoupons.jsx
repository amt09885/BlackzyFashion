import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Percent, Plus, Edit, Trash2, Copy,
  Menu, Loader2, Calendar
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import AdminSidebar from "../components/admin/AdminSidebar";
import { useToast } from "@/components/ui/use-toast";
import { format } from "date-fns";

export default function AdminCoupons() {
  const [loading, setLoading] = useState(true);
  const [coupons, setCoupons] = useState([]);
  const [showDialog, setShowDialog] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState(null);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    code: "",
    description: "",
    discount_type: "percentage",
    discount_value: 10,
    minimum_order_amount: 0,
    max_discount_amount: null,
    usage_limit: null,
    valid_from: "",
    valid_until: "",
    is_active: true,
    first_order_only: false
  });

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const isAuth = await base44.auth.isAuthenticated();
      if (!isAuth) {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      
      const userData = await base44.auth.me();
      if (userData.role !== "admin") {
        window.location.href = createPageUrl("Home");
        return;
      }
      
      await loadCoupons();
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const loadCoupons = async () => {
    try {
      const data = await base44.entities.Coupon.list("-created_date", 100);
      setCoupons(data);
    } catch (e) {
      console.error("Error loading coupons:", e);
    }
  };

  const generateCode = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let code = "BF";
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setFormData(prev => ({ ...prev, code }));
  };

  const openAddDialog = () => {
    setEditingCoupon(null);
    setFormData({
      code: "",
      description: "",
      discount_type: "percentage",
      discount_value: 10,
      minimum_order_amount: 0,
      max_discount_amount: null,
      usage_limit: null,
      valid_from: "",
      valid_until: "",
      is_active: true,
      first_order_only: false
    });
    setShowDialog(true);
  };

  const openEditDialog = (coupon) => {
    setEditingCoupon(coupon);
    setFormData({
      code: coupon.code || "",
      description: coupon.description || "",
      discount_type: coupon.discount_type || "percentage",
      discount_value: coupon.discount_value || 10,
      minimum_order_amount: coupon.minimum_order_amount || 0,
      max_discount_amount: coupon.max_discount_amount || null,
      usage_limit: coupon.usage_limit || null,
      valid_from: coupon.valid_from || "",
      valid_until: coupon.valid_until || "",
      is_active: coupon.is_active !== false,
      first_order_only: coupon.first_order_only || false
    });
    setShowDialog(true);
  };

  const handleSave = async () => {
    if (!formData.code || !formData.discount_value) {
      toast({ title: "Please fill in required fields", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      const dataToSave = {
        ...formData,
        code: formData.code.toUpperCase(),
        discount_value: Number(formData.discount_value),
        minimum_order_amount: Number(formData.minimum_order_amount) || 0,
        max_discount_amount: formData.max_discount_amount ? Number(formData.max_discount_amount) : null,
        usage_limit: formData.usage_limit ? Number(formData.usage_limit) : null
      };

      if (editingCoupon) {
        await base44.entities.Coupon.update(editingCoupon.id, dataToSave);
        toast({ title: "Coupon updated!" });
      } else {
        await base44.entities.Coupon.create(dataToSave);
        toast({ title: "Coupon created!" });
      }

      setShowDialog(false);
      await loadCoupons();
    } catch (e) {
      toast({ title: "Error saving coupon", variant: "destructive" });
    }
    setSaving(false);
  };

  const handleDelete = async (coupon) => {
    if (!confirm(`Delete coupon "${coupon.code}"?`)) return;
    
    try {
      await base44.entities.Coupon.delete(coupon.id);
      toast({ title: "Coupon deleted" });
      await loadCoupons();
    } catch (e) {
      toast({ title: "Error deleting coupon", variant: "destructive" });
    }
  };

  const copyCode = (code) => {
    navigator.clipboard.writeText(code);
    toast({ title: "Code copied to clipboard!" });
  };

  const isExpired = (coupon) => {
    if (!coupon.valid_until) return false;
    return new Date(coupon.valid_until) < new Date();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-[#d4a853]" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar currentPage="AdminCoupons" />
      
      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b px-4 md:px-8 py-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild className="md:hidden">
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-64">
                  <AdminSidebar mobile currentPage="AdminCoupons" />
                </SheetContent>
              </Sheet>
              <h1 className="text-xl font-bold">Coupons</h1>
            </div>
            
            <Button onClick={openAddDialog} className="bg-[#d4a853] hover:bg-[#c49743] text-black">
              <Plus className="w-4 h-4 mr-2" />
              Add Coupon
            </Button>
          </div>
        </header>

        <main className="p-4 md:p-8">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Total Coupons</p>
                    <p className="text-2xl font-bold">{coupons.length}</p>
                  </div>
                  <Percent className="w-8 h-8 text-[#d4a853]" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Active Coupons</p>
                    <p className="text-2xl font-bold">{coupons.filter(c => c.is_active && !isExpired(c)).length}</p>
                  </div>
                  <Badge className="bg-green-100 text-green-800">Active</Badge>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Total Uses</p>
                    <p className="text-2xl font-bold">{coupons.reduce((sum, c) => sum + (c.used_count || 0), 0)}</p>
                  </div>
                  <Badge className="bg-blue-100 text-blue-800">Uses</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Coupons Table */}
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Code</TableHead>
                    <TableHead>Discount</TableHead>
                    <TableHead>Min. Order</TableHead>
                    <TableHead>Usage</TableHead>
                    <TableHead>Valid Until</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {coupons.map(coupon => (
                    <TableRow key={coupon.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-lg">{coupon.code}</span>
                          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => copyCode(coupon.code)}>
                            <Copy className="w-3 h-3" />
                          </Button>
                        </div>
                        {coupon.description && (
                          <p className="text-xs text-gray-500">{coupon.description}</p>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-[#d4a853]/20 text-[#d4a853]">
                          {coupon.discount_type === "percentage" 
                            ? `${coupon.discount_value}% OFF`
                            : `৳${coupon.discount_value} OFF`
                          }
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {coupon.minimum_order_amount > 0 
                          ? `৳${coupon.minimum_order_amount.toLocaleString()}`
                          : "-"
                        }
                      </TableCell>
                      <TableCell>
                        {coupon.usage_limit 
                          ? `${coupon.used_count || 0}/${coupon.usage_limit}`
                          : `${coupon.used_count || 0} used`
                        }
                      </TableCell>
                      <TableCell>
                        {coupon.valid_until 
                          ? format(new Date(coupon.valid_until), "MMM d, yyyy")
                          : "No expiry"
                        }
                      </TableCell>
                      <TableCell>
                        {isExpired(coupon) ? (
                          <Badge className="bg-red-100 text-red-800">Expired</Badge>
                        ) : coupon.is_active ? (
                          <Badge className="bg-green-100 text-green-800">Active</Badge>
                        ) : (
                          <Badge className="bg-gray-100 text-gray-800">Inactive</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => openEditDialog(coupon)}>
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(coupon)}>
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              
              {coupons.length === 0 && (
                <div className="text-center py-12">
                  <Percent className="w-12 h-12 mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500">No coupons yet</p>
                  <Button onClick={openAddDialog} className="mt-4 bg-[#d4a853] hover:bg-[#c49743] text-black">
                    <Plus className="w-4 h-4 mr-2" />
                    Create First Coupon
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>

      {/* Add/Edit Coupon Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingCoupon ? "Edit Coupon" : "Create Coupon"}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>Coupon Code *</Label>
              <div className="flex gap-2 mt-1">
                <Input
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                  placeholder="SUMMER20"
                  className="font-mono"
                />
                <Button type="button" variant="outline" onClick={generateCode}>
                  Generate
                </Button>
              </div>
            </div>

            <div>
              <Label>Description</Label>
              <Input
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Summer sale discount"
                className="mt-1"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Discount Type</Label>
                <Select 
                  value={formData.discount_type} 
                  onValueChange={(v) => setFormData({ ...formData, discount_type: v })}
                >
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage (%)</SelectItem>
                    <SelectItem value="fixed">Fixed Amount (৳)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Discount Value *</Label>
                <Input
                  type="number"
                  value={formData.discount_value}
                  onChange={(e) => setFormData({ ...formData, discount_value: e.target.value })}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Min. Order Amount (৳)</Label>
                <Input
                  type="number"
                  value={formData.minimum_order_amount}
                  onChange={(e) => setFormData({ ...formData, minimum_order_amount: e.target.value })}
                  className="mt-1"
                  placeholder="0"
                />
              </div>
              <div>
                <Label>Max Discount (৳)</Label>
                <Input
                  type="number"
                  value={formData.max_discount_amount || ""}
                  onChange={(e) => setFormData({ ...formData, max_discount_amount: e.target.value || null })}
                  className="mt-1"
                  placeholder="No limit"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Valid From</Label>
                <Input
                  type="date"
                  value={formData.valid_from}
                  onChange={(e) => setFormData({ ...formData, valid_from: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label>Valid Until</Label>
                <Input
                  type="date"
                  value={formData.valid_until}
                  onChange={(e) => setFormData({ ...formData, valid_until: e.target.value })}
                  className="mt-1"
                />
              </div>
            </div>

            <div>
              <Label>Usage Limit</Label>
              <Input
                type="number"
                value={formData.usage_limit || ""}
                onChange={(e) => setFormData({ ...formData, usage_limit: e.target.value || null })}
                className="mt-1"
                placeholder="Unlimited"
              />
            </div>

            <div className="flex gap-6">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(v) => setFormData({ ...formData, is_active: v })}
                />
                <Label htmlFor="is_active">Active</Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="first_order_only"
                  checked={formData.first_order_only}
                  onCheckedChange={(v) => setFormData({ ...formData, first_order_only: v })}
                />
                <Label htmlFor="first_order_only">First Order Only</Label>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>Cancel</Button>
            <Button 
              onClick={handleSave} 
              disabled={saving}
              className="bg-[#d4a853] hover:bg-[#c49743] text-black"
            >
              {saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              {editingCoupon ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}