import React, { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "./utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { 
  Search, ShoppingBag, Heart, User, Menu, X, 
  ChevronDown, Phone, Mail, Facebook, Instagram, 
  MapPin, Clock
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import NewsletterSection from "./components/NewsletterSection";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_68efc8686692d4a66165643e/68ce1934a_500199112_122159999006541940_8065689141022182336_n.jpg";
const HEADER_LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69258a473b6708fb6e444528/864e69bb5_Blackzyfashion.png";

export default function Layout({ children, currentPageName }) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: async () => {
      const isAuth = await base44.auth.isAuthenticated();
      if (isAuth) return base44.auth.me();
      return null;
    },
    staleTime: 30 * 60 * 1000,
    cacheTime: 2 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const getSessionId = () => localStorage.getItem('guest_session_id');

  const { data: cartItems = [] } = useQuery({
    queryKey: ['cart-items', user?.email || getSessionId()],
    queryFn: async () => {
      if (user?.email) {
        return base44.entities.CartItem.filter({ user_email: user.email });
      }
      const sessionId = getSessionId();
      if (sessionId) {
        return base44.entities.CartItem.filter({ session_id: sessionId });
      }
      return [];
    },
    staleTime: 5 * 60 * 1000,
    cacheTime: 30 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
  });

  const { data: wishlistItems = [] } = useQuery({
    queryKey: ['wishlist-items', user?.email],
    queryFn: () => base44.entities.Wishlist.filter({ user_email: user.email }),
    enabled: !!user?.email,
    staleTime: 10 * 60 * 1000,
    cacheTime: 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: () => base44.entities.Category.filter({ is_active: true }, "sort_order", 50),
    staleTime: 2 * 60 * 60 * 1000,
    cacheTime: 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
  });

  const { data: siteSettings } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const settings = await base44.entities.SiteSettings.filter({ key: "main" });
      return settings[0] || null;
    },
    staleTime: 24 * 60 * 60 * 1000,
    cacheTime: 7 * 24 * 60 * 60 * 1000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
  });

  const settings = siteSettings || {
    phone: "+880 1XXX-XXXXXX",
    email: "info@blackzy.com",
    address: "Dhaka, Bangladesh",
    working_hours: "Sat-Thu: 10AM - 8PM",
    whatsapp_number: "8801XXXXXXXXX",
    facebook_url: "",
    instagram_url: "",
    footer_description: "Premium Bengali traditional fabrics and clothing. Authentic AC Cotton, Block Prints, and Gojkapor sarees.",
    free_shipping_threshold: 2000,
    copyright_text: "© 2024 Blackzy Fashion. All rights reserved."
  };

  // Meta Pixel Integration
  useEffect(() => {
    if (!settings.meta_pixel_enabled || !settings.meta_pixel_id) return;

    // Initialize Meta Pixel
    const initPixel = () => {
      window.fbq = function() {
        window.fbq.callMethod 
          ? window.fbq.callMethod.apply(window.fbq, arguments) 
          : window.fbq.queue.push(arguments);
      };
      if (!window._fbq) window._fbq = window.fbq;
      window.fbq.push = window.fbq;
      window.fbq.loaded = true;
      window.fbq.version = '2.0';
      window.fbq.queue = [];

      const script = document.createElement('script');
      script.async = true;
      script.src = 'https://connect.facebook.net/en_US/fbevents.js';
      document.head.appendChild(script);

      script.onload = () => {
        window.fbq('init', settings.meta_pixel_id, {}, {
          ...(settings.meta_pixel_test_id && { eventID: settings.meta_pixel_test_id })
        });
        window.fbq('track', 'PageView');
      };
    };

    if (!window.fbq) {
      initPixel();
    }
  }, [settings.meta_pixel_enabled, settings.meta_pixel_id, settings.meta_pixel_test_id]);

  const cartCount = useMemo(() => 
    cartItems.reduce((sum, item) => sum + (item.quantity || 1), 0), 
    [cartItems]
  );
  const wishlistCount = wishlistItems.length;

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const isAdminPage = currentPageName?.toLowerCase().includes("admin");

  if (isAdminPage) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen bg-[#fafafa]">
      <link rel="preconnect" href="https://qtrypzzcjebvfcihiynt.supabase.co" />
      <link rel="dns-prefetch" href="https://qtrypzzcjebvfcihiynt.supabase.co" />
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600&family=Inter:wght@400;600&display=swap" />
      <link rel="manifest" href="/manifest.json" />
      <meta name="theme-color" content="#d4a853" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      <style>{`

        :root {
          --primary-black: #0a0a0a;
          --silver: #c0c0c0;
          --gold: #d4a853;
          --off-white: #fafafa;
        }

        html {
          text-rendering: optimizeSpeed;
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }

        body {
          overflow-x: hidden;
        }

        img {
          content-visibility: auto;
          will-change: auto;
        }

        @media (prefers-reduced-motion: reduce) {
          *, *::before, *::after {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
          }
        }

        .font-display {
          font-family: 'Cormorant Garamond', serif;
        }

        .font-body {
          font-family: 'Inter', sans-serif;
        }



        * {
          -webkit-tap-highlight-color: transparent;
        }
      `}</style>

      {/* Top Bar */}
      <div className="bg-[#0a0a0a] text-white py-2 px-4 text-xs font-body">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="hidden md:flex items-center gap-6">
                <span className="flex items-center gap-1.5">
                  <Phone className="w-3 h-3" />
                  {settings.phone}
                </span>
                <span className="flex items-center gap-1.5">
                  <Mail className="w-3 h-3" />
                  {settings.email}
                </span>
              </div>
              <div className="flex-1 text-center md:flex-none">
                <span className="text-[#d4a853]">✨ Free Delivery on Orders Above ৳{settings.free_shipping_threshold?.toLocaleString()}</span>
              </div>
          <div className="hidden md:flex items-center gap-4">
            <a href="#" className="hover:text-[#d4a853] transition-colors">
              <Facebook className="w-4 h-4" />
            </a>
            <a href="#" className="hover:text-[#d4a853] transition-colors">
              <Instagram className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header 
        className={`sticky top-0 z-50 transition-all duration-500 ${
          isScrolled 
            ? "bg-white/95 backdrop-blur-md shadow-lg" 
            : "bg-white"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-20">
            {/* Mobile Menu */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80 bg-[#0a0a0a] text-white border-none">
                <SheetHeader>
                  <SheetTitle className="text-white">
                    <img src={LOGO_URL} alt="Blackzy" className="h-12 object-contain" />
                  </SheetTitle>
                </SheetHeader>
                <nav className="mt-8 flex flex-col gap-4">
                  <Link 
                    to={createPageUrl("Home")} 
                    className="text-lg hover:text-[#d4a853] py-2 border-b border-white/10"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Home
                  </Link>
                  <Link 
                      to={createPageUrl("Shop")} 
                      className="text-lg hover:text-[#d4a853] py-2 border-b border-white/10"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                    Shop All
                  </Link>
                  {categories.slice(0, 6).map(cat => (
                    <Link 
                      key={cat.id}
                      to={createPageUrl("Shop") + `?category=${cat.id}`}
                      className="text-sm hover:text-[#d4a853] py-2 border-b border-white/10 pl-4"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {cat.name}
                    </Link>
                  ))}
                  <Link 
                    to={createPageUrl("About")} 
                    className="text-lg hover:text-[#d4a853] py-2 border-b border-white/10"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    About Us
                  </Link>
                  <Link 
                    to={createPageUrl("Contact")} 
                    className="text-lg hover:text-[#d4a853] py-2 border-b border-white/10"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Contact
                  </Link>
                </nav>
              </SheetContent>
            </Sheet>

            {/* Logo */}
            <Link to={createPageUrl("Home")} className="flex-shrink-0">
              <img 
                src={HEADER_LOGO_URL} 
                alt="Blackzy Fashion" 
                width="150"
                height="48"
                fetchpriority="high"
                className="h-10 md:h-12 object-contain"
              />
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8 font-body">
              <Link 
                to={createPageUrl("Home")}
                className="text-sm font-medium text-[#0a0a0a] hover:text-[#d4a853] relative group"
              >
                HOME
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#d4a853] group-hover:w-full" />
              </Link>
              
              <DropdownMenu>
                <DropdownMenuTrigger className="text-sm font-medium text-[#0a0a0a] hover:text-[#d4a853] flex items-center gap-1">
                  COLLECTIONS <ChevronDown className="w-3 h-3" />
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 bg-white shadow-xl border-none rounded-none p-4">
                  <DropdownMenuItem asChild>
                    <Link to={createPageUrl("Shop")} className="cursor-pointer font-medium">
                      Shop All
                    </Link>
                  </DropdownMenuItem>
                  {categories.map(cat => (
                    <DropdownMenuItem key={cat.id} asChild>
                      <Link 
                        to={createPageUrl("Shop") + `?category=${cat.id}`}
                        className="cursor-pointer"
                      >
                        {cat.name}
                      </Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              <Link 
                to={createPageUrl("Shop") + "?collection=new"}
                className="text-sm font-medium text-[#0a0a0a] hover:text-[#d4a853] relative group"
              >
                NEW ARRIVALS
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#d4a853] group-hover:w-full" />
              </Link>

              <Link 
                to={createPageUrl("About")}
                className="text-sm font-medium text-[#0a0a0a] hover:text-[#d4a853] relative group"
              >
                ABOUT
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#d4a853] group-hover:w-full" />
              </Link>

              <Link 
                to={createPageUrl("Contact")}
                className="text-sm font-medium text-[#0a0a0a] hover:text-[#d4a853] relative group"
              >
                CONTACT
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#d4a853] group-hover:w-full" />
              </Link>

              {user?.role === 'admin' && (
                <Link 
                  to={createPageUrl("AdminDashboard")}
                  className="text-sm font-medium text-[#d4a853] hover:text-[#c49743] relative group"
                >
                  ADMIN
                  <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#d4a853] group-hover:w-full" />
                </Link>
              )}
            </nav>

            {/* Right Icons */}
            <div className="flex items-center gap-3 md:gap-5">
              <Link 
                to={createPageUrl("Shop")}
                className="text-[#0a0a0a] hover:text-[#d4a853]"
              >
                <Search className="w-5 h-5" />
              </Link>

              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger className="text-[#0a0a0a] hover:text-[#d4a853]">
                    <User className="w-5 h-5" />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48 bg-white shadow-xl border-none rounded-none p-2">
                    <DropdownMenuItem asChild>
                      <Link to={createPageUrl("Account")} className="cursor-pointer">
                        My Account
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link to={createPageUrl("Orders")} className="cursor-pointer">
                        My Orders
                      </Link>
                    </DropdownMenuItem>
                    {user.role === 'admin' && (
                      <DropdownMenuItem asChild>
                        <Link to={createPageUrl("AdminDashboard")} className="cursor-pointer text-[#d4a853]">
                          Admin Panel
                        </Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem 
                      onClick={() => base44.auth.logout()}
                      className="cursor-pointer text-red-500"
                    >
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <button 
                  onClick={() => base44.auth.redirectToLogin()}
                  className="text-[#0a0a0a] hover:text-[#d4a853]"
                >
                  <User className="w-5 h-5" />
                </button>
              )}

              <Link 
                to={createPageUrl("Wishlist")}
                className="text-[#0a0a0a] hover:text-[#d4a853] relative"
              >
                <Heart className="w-5 h-5" />
                {wishlistCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 w-4 h-4 p-0 flex items-center justify-center bg-[#d4a853] text-[10px]">
                    {wishlistCount}
                  </Badge>
                )}
              </Link>

              <Link 
                to={createPageUrl("Cart")}
                className="text-[#0a0a0a] hover:text-[#d4a853] relative"
              >
                <ShoppingBag className="w-5 h-5" />
                {cartCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 w-4 h-4 p-0 flex items-center justify-center bg-[#d4a853] text-[10px]">
                    {cartCount}
                  </Badge>
                )}
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="min-h-[60vh]">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-[#0a0a0a] text-white mt-20">
        {/* Newsletter */}
        <NewsletterSection />

        {/* Sister Concern - Ultra Premium Design */}
        <div className="border-b border-[#d4a853]/20 bg-gradient-to-b from-transparent to-black/50">
          <div className="max-w-7xl mx-auto px-4 py-12">
            <div className="flex flex-col items-center justify-center gap-6 relative">

              <div className="relative z-10">
                <p className="text-[#d4a853] text-base md:text-lg font-display tracking-[0.3em] uppercase text-center mb-2">
                  ✦ Our Sister Concern ✦
                </p>
                <div className="h-px w-32 mx-auto bg-[#d4a853]"></div>
              </div>

              <a 
                href="https://tonsiyafashion.shop" 
                target="_blank" 
                rel="noopener noreferrer"
                className="relative group z-10"
                >
                <div className="relative bg-[#d4a853]/10 px-12 py-6 rounded-2xl border-2 border-[#d4a853]/30 hover:border-[#d4a853] transform hover:scale-105">

                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69258a473b6708fb6e444528/5e14c3bf8_555898600_122101823823038787_597959877539282917_n.jpg"
                    alt="Tonsiya Fashion" 
                    loading="lazy"
                    decoding="async"
                    className="h-20 md:h-28 object-contain group-hover:brightness-110"
                  />
                </div>

                <div className="text-center mt-5">
                  <p className="text-sm md:text-base text-gray-400 font-body group-hover:text-[#d4a853] flex items-center justify-center gap-2">
                    <span>Explore</span>
                    <span className="font-display text-lg md:text-xl text-white group-hover:text-[#d4a853] font-semibold tracking-wide">Tonsiya Fashion</span>
                    <span className="text-[#d4a853]">→</span>
                  </p>
                  <p className="text-xs text-gray-600 mt-1 font-body italic">Where Tradition Meets Elegance</p>
                </div>
              </a>
            </div>
          </div>
        </div>

        {/* Main Footer */}
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
            {/* Brand */}
            <div className="md:col-span-1">
              <img src={LOGO_URL} alt="Blackzy Fashion" loading="lazy" decoding="async" className="h-16 mb-4" />
              <p className="text-gray-400 text-sm mb-4 font-body leading-relaxed">
                {settings.footer_description}
              </p>
              <div className="flex gap-3">
                <a href={settings.facebook_url || "#"} target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/10 flex items-center justify-center hover:bg-[#d4a853]">
                  <Facebook className="w-4 h-4" />
                </a>
                <a href={settings.instagram_url || "#"} target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/10 flex items-center justify-center hover:bg-[#d4a853]">
                  <Instagram className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-display text-xl mb-6">Quick Links</h4>
              <ul className="space-y-3 font-body text-sm">
                <li><Link to={createPageUrl("Shop")} className="text-gray-400 hover:text-[#d4a853]">Shop All</Link></li>
                <li><Link to={createPageUrl("About")} className="text-gray-400 hover:text-[#d4a853]">About Us</Link></li>
                <li><Link to={createPageUrl("Contact")} className="text-gray-400 hover:text-[#d4a853]">Contact</Link></li>
                <li><Link to={createPageUrl("TrackOrder")} className="text-gray-400 hover:text-[#d4a853]">Track Order</Link></li>
                
              </ul>
            </div>

            {/* Customer Service */}
            <div>
              <h4 className="font-display text-xl mb-6">Customer Service</h4>
              <ul className="space-y-3 font-body text-sm">
                <li><Link to={createPageUrl("FAQ")} className="text-gray-400 hover:text-[#d4a853]">FAQ</Link></li>
                <li><Link to={createPageUrl("ShippingPolicy")} className="text-gray-400 hover:text-[#d4a853]">Shipping Policy</Link></li>
                <li><Link to={createPageUrl("ReturnPolicy")} className="text-gray-400 hover:text-[#d4a853]">Return Policy</Link></li>
                <li><Link to={createPageUrl("PrivacyPolicy")} className="text-gray-400 hover:text-[#d4a853]">Privacy Policy</Link></li>
                <li><Link to={createPageUrl("Terms")} className="text-gray-400 hover:text-[#d4a853]">Terms & Conditions</Link></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-display text-xl mb-6">Contact Us</h4>
              <ul className="space-y-4 font-body text-sm">
                  <li className="flex items-start gap-3 text-gray-400">
                    <MapPin className="w-4 h-4 mt-1 flex-shrink-0 text-[#d4a853]" />
                    <span>{settings.address}</span>
                  </li>
                  <li className="flex items-center gap-3 text-gray-400">
                    <Phone className="w-4 h-4 flex-shrink-0 text-[#d4a853]" />
                    <span>{settings.phone}</span>
                  </li>
                  <li className="flex items-center gap-3 text-gray-400">
                    <Mail className="w-4 h-4 flex-shrink-0 text-[#d4a853]" />
                    <span>{settings.email}</span>
                  </li>
                  <li className="flex items-center gap-3 text-gray-400">
                    <Clock className="w-4 h-4 flex-shrink-0 text-[#d4a853]" />
                    <span>{settings.working_hours}</span>
                  </li>
                </ul>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4 py-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-gray-400 text-sm font-body text-center md:text-left">
                © 2025 Blackzy Fashion. All rights reserved. Developed by{" "}
                <a 
                  href="https://digitalnexusacademy.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[#d4a853] font-semibold hover:text-white underline decoration-[#d4a853] underline-offset-2"
                >
                  Digital Nexus Academy
                </a>
              </p>
              <div className="flex items-center gap-6">
                <img src="https://www.logo.wine/a/logo/BKash/BKash-Icon-Logo.wine.svg" alt="bKash" loading="lazy" decoding="async" className="h-8 object-contain" />
                <img src="https://download.logo.wine/logo/Nagad/Nagad-Logo.wine.png" alt="Nagad" loading="lazy" decoding="async" className="h-8 object-contain" />
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* WhatsApp Float Button */}
      <a 
        href={`https://wa.me/${settings.whatsapp_number}`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-lg z-50"
        >
        <svg viewBox="0 0 24 24" className="w-7 h-7 fill-white">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
      </a>
    </div>
  );
}